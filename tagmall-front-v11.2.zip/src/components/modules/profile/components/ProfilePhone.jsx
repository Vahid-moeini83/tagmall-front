"use client";

import { useState } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { ProfilePhoneContent, ProfilePhoneOtpContent } from "..";

function ProfilePhone({ isOpen, setIsOpen, onVerifyOtp }) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const [step, setStep] = useState(1);

  const [phone, setPhone] = useState("");
  const [otpExpire, setOtpExpire] = useState(5);

  const close = () => {
    setIsOpen(false);
    setStep(1);
    setPhone("");
  };

  const backStep = () => {
    setStep(1);
  };

  const renderStep = () => {
    if (step === 1)
      return (
        <ProfilePhoneContent
          phone={phone}
          setPhone={setPhone}
          onNext={() => setStep(2)}
        />
      );

    return (
      <ProfilePhoneOtpContent
        phone={phone}
        onBack={backStep}
        otpExpire={otpExpire}
        onVerify={onVerifyOtp}
      />
    );
  };

  return isDesktop ? (
    <DialogWrapper
      hasOutsideClose
      onBack={step === 2 && backStep}
      isOpen={isOpen}
      onClose={close}
    >
      {renderStep()}
    </DialogWrapper>
  ) : (
    <Drawer open={isOpen} onOpenChange={close}>
      <DrawerContent className="z-100! px-[10px]" overlayClassName="z-100">
        {renderStep()}
      </DrawerContent>
    </Drawer>
  );
}

export default ProfilePhone;
