"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { HintIcon, StrokeArrowLeftIcon } from "@/icons";
import { formatPrice, toEnglishNumber } from "@/lib/client/utils";

function ProfileWalletAmountContent({
  type,
  walletBalance = 0,
  onBack,
  onNext,
}) {
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");

  const numericAmount = Number(toEnglishNumber(amount).replace(/[٬,]/g, ""));

  const handleChange = (e) => {
    const rawValue = e.target.value.replace(/[^\d۰-۹]/g, "");

    if (rawValue === "") {
      setAmount("");
    } else {
      setAmount(formatPrice(rawValue));
    }

    if (error) setError("");
  };

  const handleSubmit = () => {
    if (!amount) {
      setError("لطفا مبلغ مورد نظر را وارد نمایید");
      return;
    }

    if (type === "withdraw" && numericAmount > walletBalance) {
      setError("مبلغ درخواستی بیشتر از موجودی شما است");
      return;
    }

    if (numericAmount < 1000) {
      setError("حداقل مبلغ 1,000 تومان می‌باشد");
      return;
    }

    onNext(numericAmount);
  };

  return (
    <div className="mt-2 lg:mt-0">
      {/* Input with back button */}
      <div className="relative">
        <Input
          label="مبلغ:"
          type="text"
          value={amount}
          onChange={handleChange}
          className={`text-center text-gray-600 bg-gray-200 ${error ? "" : "border-0!"}`}
          placeholder={
            type === "withdraw"
              ? "چه مبلغی از کیف پول اعتباری به حساب شما واریز شود؟"
              : "چه مبلغی به کیف پول اعتباری شما واریز شود؟"
          }
          error={error}
        />
        {amount && (
          <span className="absolute left-4 top-10 text-gray-600 pointer-events-none">
            تومان
          </span>
        )}
        <StrokeArrowLeftIcon
          size={20}
          className="absolute left-3 top-2 cursor-pointer lg:hidden"
          onClick={onBack}
        />
      </div>

      {/* Hint for withdraw */}
      {type === "withdraw" && (
        <div className="mt-4 flex items-center gap-2 text-gray-600">
          <HintIcon size={16} />
          <span className="text-sm">
            موجودی شما {formatPrice(walletBalance)} تومان می‌باشد
          </span>
        </div>
      )}

      {/* Submit button */}
      <button
        onClick={handleSubmit}
        className="mb-4 mt-6 w-full text-primary text-base cursor-pointer hover:opacity-80 transition-opacity"
      >
        {type === "increase" ? "افزایش اعتبار" : "درخواست وجه"}
      </button>
    </div>
  );
}

export default ProfileWalletAmountContent;
