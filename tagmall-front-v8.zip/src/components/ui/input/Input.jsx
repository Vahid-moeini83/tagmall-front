"use client";
import { cn } from "@/lib/client/utils";

function Input({
  containerClassName,
  label,
  labelClassName,
  id,
  disabled,
  className,
  error,
  ...props
}) {
  return (
    <div className={cn("flex flex-col gap-2", containerClassName)}>
      {label && label.length > 0 && (
        <label
          htmlFor={id}
          className={cn(
            "text-lg text-gray-800",
            error && "text-error-medium!",
            labelClassName,
          )}
        >
          {label}
        </label>
      )}

      <input
        {...props}
        id={id}
        className={cn(
          "outline-none border-2 h-11 lg:h-12 rounded-md px-2 transition-colors duration-200",
          error ? "border-error-medium" : "border-gray-300",
          disabled && "opacity-40",
          className,
        )}
      />

      {error && <p className={cn("text-xs text-error-medium mt-1")}>{error}</p>}
    </div>
  );
}

export default Input;
