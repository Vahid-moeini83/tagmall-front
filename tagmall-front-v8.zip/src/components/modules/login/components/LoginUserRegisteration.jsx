"use client";
import { Input } from "@/components/ui/input";
import { isValidIranianNationalCode } from "@/lib/client/validations";
import { checkAuthValidation } from "@/lib/server/actions/auth";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";

function LoginUserRegisteration({ phoneNumber, enteredOtp }) {
  const router = useRouter();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [nationalCode, setNationalCode] = useState("");
  const [isConfirming, setIsConfirming] = useState(false);
  const [errors, setErrors] = useState({
    firstName: "",
    lastName: "",
    nationalCode: "",
  });

  const handleConfirm = async () => {
    const newErrors = { firstName: "", lastName: "", nationalCode: "" };
    let hasError = false;

    if (!firstName) {
      newErrors.firstName = "لطفا نام را وارد نمایید";
      hasError = true;
    }
    if (!lastName) {
      newErrors.lastName = "لطفا نام خانوادگی را وارد نمایید";
      hasError = true;
    }
    if (!isValidIranianNationalCode(nationalCode)) {
      newErrors.nationalCode = "کد ملی وارد شده نامعتبر است";
      hasError = true;
    }

    if (hasError) {
      setErrors(newErrors);
      return;
    }

    setIsConfirming(true);
    const { checkRes, checkErr } = await checkAuthValidation({
      mobile: phoneNumber,
      otp: enteredOtp,
      name: firstName,
      family: lastName,
      national_code: nationalCode,
    });
    if (checkRes) {
      toast.success("ورود با موفقیت انجام شد");
      router.push("/");
    } else if (checkErr) {
      console.log("ERROR: ", checkErr);
    }
    setIsConfirming(false);
  };

  return (
    <div className="h-full flex flex-col justify-between overflow-y-auto scroll-hidden">
      <div>
        <div className="flex flex-col gap-2">
          <h1 className="text-2xl font-bold">تکمیل ثبت‌نام</h1>
          <span className="text-gray-600 text-base">
            لطفا اطلاعات زیر را وارد نمایید.
          </span>
        </div>
        <div className="mt-10 space-y-8">
          <Input
            label={"نام"}
            type="text"
            id="firstname"
            value={firstName}
            onChange={(e) => {
              setFirstName(e.target.value);
              if (errors.firstName) setErrors({ ...errors, firstName: "" });
            }}
            disabled={isConfirming}
            error={errors.firstName}
          />
          <Input
            label={"نام خانوادگی"}
            type="text"
            id="lastname"
            value={lastName}
            onChange={(e) => {
              setLastName(e.target.value);
              if (errors.lastName) setErrors({ ...errors, lastName: "" });
            }}
            disabled={isConfirming}
            error={errors.lastName}
          />
          <Input
            label={"کد ملی"}
            type="text"
            id="nationalCode"
            value={nationalCode}
            onChange={(e) => {
              setNationalCode(e.target.value);
              if (errors.nationalCode)
                setErrors({ ...errors, nationalCode: "" });
            }}
            disabled={isConfirming}
            error={errors.nationalCode}
          />
        </div>
      </div>
      <div className="flex flex-col gap-4 mt-10">
        <span className="text-sm text-gray-600">
          ثبت نام به منزله پذیرش{" "}
          <span className="text-primary underline underline-offset-4 cursor-pointer">
            قوانین و مقررات Tagmall
          </span>{" "}
          است.
        </span>
        <button
          disabled={isConfirming}
          onClick={handleConfirm}
          className="bg-primary text-white rounded-md w-full h-12 flex items-center justify-center gap-2 transition-all hover:bg-primary/90 hover:gap-3 cursor-pointer"
        >
          تکمیل ثبت‌نام
        </button>
      </div>
    </div>
  );
}
export default LoginUserRegisteration;
