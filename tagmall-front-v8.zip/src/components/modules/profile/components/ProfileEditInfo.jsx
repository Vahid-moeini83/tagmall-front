"use client";
import DialogWrapper from "@/components/ui/dialog";
import { DragHandler } from "@/components/ui/drag-handler";
import { Input } from "@/components/ui/input";
import { Radio } from "@/components/ui/radio";
import { PlusIcon, StrokeArrowLeftIcon } from "@/icons";
import { Check, Edit, Trash2 } from "lucide-react";
import Image from "next/image";
import React, { useState } from "react";

const ProfileEditInfo = ({ setIsEditingProfile }) => {
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [nationalCode, setNationalCode] = useState("");
  const [profileImage, setProfileImage] = useState(null);

  // Address States
  const [addresses, setAddresses] = useState([
    {
      text: "تهران، خیابان ولیعصر، کوچه سوم، پلاک ۱۲۳",
      postalCode: "۱۲۳۴۵۶۷۸۹۰",
    },
    {
      text: "اصفهان، خیابان چهارباغ، نبش خیابان شعا، پلاک ۴۵",
      postalCode: "۰۹۸۷۶۵۴۳۲۱",
    },
  ]);
  const [selectedAddress, setSelectedAddress] = useState(addresses[0] || null);
  const [showAddAddressInput, setShowAddAddressInput] = useState(false);
  const [newAddressText, setNewAddressText] = useState("");
  const [newAddressPostalCode, setNewAddressPostalCode] = useState("");
  const [editingAddressIndex, setEditingAddressIndex] = useState(null);

  // Active Sessions States
  const [sessions, setSessions] = useState([
    {
      number: "۰۹۱۲۳۴۵۶۷۸۹",
      devices: ["Windows - Chrome", "iPhone - Safari", "MacBook - Firefox"],
    },
  ]);
  const [selectedSession, setSelectedSession] = useState(sessions[0] || null);
  const [showAddSessionInput, setShowAddSessionInput] = useState(false);
  const [newSessionNumber, setNewSessionNumber] = useState("");
  const [editingSessionIndex, setEditingSessionIndex] = useState(null);

  // Dialog State for Edit Session
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Image Handler
  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setProfileImage(e.target.files[0]);
    }
  };

  // Address Handlers
  const handleOpenAddNewAddress = () => {
    setShowAddAddressInput(true);
    setEditingAddressIndex(null);
    setNewAddressText("");
    setNewAddressPostalCode("");
  };

  const handleSaveAddress = (e) => {
    e.preventDefault();
    const addressValue = newAddressText.trim();
    const postalCodeValue = newAddressPostalCode.trim();
    if (!addressValue) return;

    if (editingAddressIndex !== null) {
      const updatedAddresses = [...addresses];
      updatedAddresses[editingAddressIndex] = {
        text: addressValue,
        postalCode: postalCodeValue,
      };
      setAddresses(updatedAddresses);
      setEditingAddressIndex(null);
    } else {
      const newAddressObj = {
        text: addressValue,
        postalCode: postalCodeValue,
      };
      setAddresses([newAddressObj, ...addresses]);
      setShowAddAddressInput(false);
    }
    setNewAddressText("");
    setNewAddressPostalCode("");
  };

  const handleDeleteAddress = (indexToDelete) => {
    const updatedAddresses = addresses.filter(
      (_, index) => index !== indexToDelete,
    );
    setAddresses(updatedAddresses);
    if (
      selectedAddress &&
      selectedAddress.text === addresses[indexToDelete].text
    ) {
      setSelectedAddress(updatedAddresses[0] || null);
    }
  };

  const handleEditClick = (index, addressObj) => {
    setEditingAddressIndex(index);
    setNewAddressText(addressObj.text);
    setNewAddressPostalCode(addressObj.postalCode);
    setShowAddAddressInput(false);
  };

  // Session Handlers
  const handleOpenAddNewSession = () => {
    setShowAddSessionInput(true);
    setEditingSessionIndex(null);
    setNewSessionNumber("");
  };

  const handleSaveSession = (e) => {
    e.preventDefault();
    const sessionNumberValue = newSessionNumber.trim();
    if (!sessionNumberValue) return;

    if (editingSessionIndex !== null) {
      const updatedSessions = [...sessions];
      updatedSessions[editingSessionIndex] = {
        number: sessionNumberValue,
        devices: updatedSessions[editingSessionIndex].devices,
      };
      setSessions(updatedSessions);
      setEditingSessionIndex(null);
    } else {
      const newSessionObj = {
        number: sessionNumberValue,
        devices: ["دستگاه جدید"],
      };
      setSessions([newSessionObj, ...sessions]);
      setShowAddSessionInput(false);
    }
    setNewSessionNumber("");
  };

  const handleDeleteSession = (indexToDelete) => {
    const updatedSessions = sessions.filter(
      (_, index) => index !== indexToDelete,
    );
    setSessions(updatedSessions);
    if (
      selectedSession &&
      selectedSession.number === sessions[indexToDelete].number
    ) {
      setSelectedSession(updatedSessions[0] || null);
    }
  };

  const handleEditSessionClick = (index, sessionObj) => {
    // Open the dialog instead of inline edit
    setIsEditDialogOpen(true);
  };

  const handleProfileSubmit = (e) => {
    e.preventDefault();
    setIsEditingProfile(false);
  };

  return (
    <div className="h-full select-none flex flex-col">
      <div className="absolute top-2 right-1/2 translate-x-1/2 z-50">
        <DragHandler
          hasCloseEvent={true}
          onClose={() => setIsEditingProfile(false)}
        />
      </div>
      {/* Scrollable Content Area */}
      <div className="flex-1 h-full overflow-y-auto bg-white px-6 pb-6 pt-10">
        {/* Header Section */}
        <div className="flex items-center justify-between mb-10">
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl font-bold text-gray-900 leading-tight">
              ویرایش مشخصات
            </h1>
            <span className="text-base text-gray-500 font-medium">
              مشخصات خود را مدیریت کنید
            </span>
          </div>
          <div className="relative group">
            <label
              htmlFor="modalProfileImage"
              className="relative w-16 h-16 rounded-md border border-gray-200 overflow-hidden flex items-center justify-center cursor-pointer bg-white shadow-sm"
            >
              {profileImage ? (
                <Image
                  src={URL.createObjectURL(profileImage)}
                  fill
                  alt="پروفایل"
                  className="object-cover"
                />
              ) : (
                <span className="text-xs text-center text-gray-400 px-1">
                  انتخاب عکس
                </span>
              )}
            </label>
            <input
              type="file"
              id="modalProfileImage"
              name="modalProfileImage"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
          </div>
        </div>

        {/* Inputs Section */}
        <div className="space-y-6 mb-8">
          <Input
            label={"نام و نام خانوادگی"}
            type="text"
            id="m_fullName"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />
          <Input
            label={"تلفن همراه"}
            type="number"
            id="m_phone"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
          />
          <Input
            label={"کد ملی"}
            type="number"
            id="m_nationalCode"
            value={nationalCode}
            onChange={(e) => setNationalCode(e.target.value)}
          />
        </div>

        {/* Address Section */}
        <div className="bg-gray-50 rounded-md p-4 border border-gray-100 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-1 h-6 bg-primary rounded-full"></div>
              <label className="text-lg font-bold text-gray-800">
                آدرس‌های من
              </label>
            </div>
            <button
              type="button"
              onClick={() => handleOpenAddNewAddress()}
              className="flex items-center gap-1 text-primary text-sm font-bold cursor-pointer"
            >
              <PlusIcon size={14} />
              ثبت آدرس جدید
            </button>
          </div>
          {showAddAddressInput && (
            <div className="flex flex-col gap-3 mb-4 p-3 bg-white rounded-md border border-gray-200 shadow-sm">
              <Input
                type="text"
                placeholder="آدرس جدید..."
                value={newAddressText}
                onChange={(e) => setNewAddressText(e.target.value)}
                containerClassName="w-full"
              />
              <Input
                type="number"
                placeholder="کد پستی..."
                value={newAddressPostalCode}
                onChange={(e) => setNewAddressPostalCode(e.target.value)}
                containerClassName="w-full"
              />
              <div className="self-end flex items-center gap-2">
                <button
                  onClick={handleSaveAddress}
                  className="bg-primary text-white px-4 h-9 rounded-md text-xs cursor-pointer hover:bg-opacity-90 transition-all"
                >
                  ذخیره آدرس
                </button>
                <button
                  onClick={() => setShowAddAddressInput(false)}
                  className="text-gray-500 px-4 h-9 rounded-md text-xs cursor-pointer hover:bg-gray-100 transition-all"
                >
                  لغو
                </button>
              </div>
            </div>
          )}
          <div className="flex flex-col gap-2">
            {addresses.map((addressObj, index) => (
              <div
                key={index}
                className={`flex items-start gap-3 p-3 rounded-md border-2 transition-all bg-white ${
                  selectedAddress && selectedAddress.text === addressObj.text
                    ? "border-primary ring-1 ring-primary/20"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div
                  className="mt-1"
                  onClick={() => setSelectedAddress(addressObj)}
                >
                  <Radio
                    checked={
                      selectedAddress &&
                      selectedAddress.text === addressObj.text
                    }
                    onChange={() => setSelectedAddress(addressObj)}
                  />
                </div>
                <div className="flex-1 flex flex-col justify-center">
                  {editingAddressIndex === index ? (
                    <div className="flex flex-col gap-2 w-full">
                      <Input
                        type="text"
                        placeholder="آدرس..."
                        value={newAddressText}
                        onChange={(e) => setNewAddressText(e.target.value)}
                        autoFocus
                        containerClassName="w-full"
                      />
                      <Input
                        type="text"
                        placeholder="کد پستی..."
                        value={newAddressPostalCode}
                        onChange={(e) =>
                          setNewAddressPostalCode(e.target.value)
                        }
                        containerClassName="w-full"
                      />
                      <button
                        onClick={handleSaveAddress}
                        className="bg-primary text-white px-4 py-2 rounded-md text-xs cursor-pointer self-end"
                      >
                        بروزرسانی
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between w-full group">
                      <div
                        className="flex flex-col cursor-pointer"
                        onClick={() => setSelectedAddress(addressObj)}
                      >
                        <span className="text-sm text-gray-800 font-medium leading-6">
                          {addressObj.text}
                        </span>
                        <span className="text-xs text-gray-400 mt-1">
                          کد پستی: {addressObj.postalCode || "ثبت نشده"}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleEditClick(index, addressObj)}
                          className="text-primary cursor-pointer"
                        >
                          <Edit size={14} />
                        </button>
                        <button
                          onClick={() => handleDeleteAddress(index)}
                          className="text-error-medium cursor-pointer"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Sessions Section */}
        <div className="bg-gray-50 rounded-md p-4 border border-gray-100 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-1 h-6 bg-primary rounded-full"></div>
              <label className="text-lg font-bold text-gray-800">
                نشست‌های فعال
              </label>
            </div>
            <button
              type="button"
              onClick={() => handleOpenAddNewSession()}
              className="flex items-center gap-1 text-primary text-sm font-bold cursor-pointer"
            >
              <PlusIcon size={14} />
              افزودن شماره
            </button>
          </div>
          {showAddSessionInput && (
            <div className="flex flex-col gap-3 mb-4 p-3 bg-white rounded-md border border-gray-200 shadow-sm">
              <Input
                type="number"
                placeholder="شماره تلفن همراه..."
                value={newSessionNumber}
                onChange={(e) => setNewSessionNumber(e.target.value)}
                containerClassName="w-full"
              />
              <div className="self-end flex items-center gap-2">
                <button
                  onClick={handleSaveSession}
                  className="bg-primary text-white px-4 h-9 rounded-md text-xs cursor-pointer hover:bg-opacity-90 transition-all"
                >
                  ذخیره شماره
                </button>
                <button
                  onClick={() => setShowAddSessionInput(false)}
                  className="text-gray-500 px-4 h-9 rounded-md text-xs cursor-pointer hover:bg-gray-100 transition-all"
                >
                  لغو
                </button>
              </div>
            </div>
          )}
          <div className="flex flex-col gap-2">
            {sessions.map((sessionObj, index) => (
              <div
                key={index}
                className={`flex items-start gap-3 p-3 rounded-md border-2 transition-all bg-white ${
                  selectedSession &&
                  selectedSession.number === sessionObj.number
                    ? "border-primary ring-1 ring-primary/20"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div
                  className="mt-1"
                  onClick={() => setSelectedSession(sessionObj)}
                >
                  <Radio
                    checked={
                      selectedSession &&
                      selectedSession.number === sessionObj.number
                    }
                    onChange={() => setSelectedSession(sessionObj)}
                  />
                </div>
                <div className="flex-1 flex flex-col justify-center">
                  {editingSessionIndex === index ? (
                    <div className="flex flex-col gap-2 w-full">
                      <Input
                        type="number"
                        placeholder="شماره تلفن..."
                        value={newSessionNumber}
                        onChange={(e) => setNewSessionNumber(e.target.value)}
                        autoFocus
                        containerClassName="w-full"
                      />
                      <button
                        onClick={handleSaveSession}
                        className="bg-primary text-white px-4 py-2 rounded-md text-xs cursor-pointer self-end"
                      >
                        بروزرسانی
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between w-full group">
                      <div
                        className="flex flex-col cursor-pointer"
                        onClick={() => setSelectedSession(sessionObj)}
                      >
                        <span className="text-sm text-gray-800 font-medium leading-6">
                          {sessionObj.number}
                        </span>
                        <span className="text-xs text-gray-400 mt-1">
                          دستگاه‌ها: {sessionObj.devices.join("، ")}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() =>
                            handleEditSessionClick(index, sessionObj)
                          }
                          className="text-primary cursor-pointer"
                        >
                          <Edit size={16} />
                        </button>
                        {/* Delete button hidden on mobile */}
                        {/* <button
                          onClick={() => handleDeleteSession(index)}
                          className="hidden lg:block text-error-medium cursor-pointer"
                        >
                          <Trash2 size={14} />
                        </button> */}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Save button */}
        <button
          onClick={handleProfileSubmit}
          className="bg-primary text-white rounded-md w-full h-12 mt-12 flex items-center justify-center gap-2 transition-all hover:bg-primary/90 hover:gap-3 cursor-pointer font-medium"
        >
          ذخیره تغییرات
        </button>
      </div>

      {/* Edit Session Dialog */}
      <DialogWrapper
        isOpen={isEditDialogOpen}
        onClose={() => setIsEditDialogOpen(false)}
        title="تغییر شماره"
      >
        <div className="flex flex-col gap-4">
          <p className="text-gray-700 leading-7 text-sm lg:text-base">
            برای تغییر شماره همراه ابتدا باید در سامانه هدی کد ملی و شماره تلفن
            خود را تطبیق دهید
          </p>
          <div className="flex items-center justify-center gap-3 mt-2">
            <button
              onClick={() => setIsEditDialogOpen(false)}
              className="flex-1 h-10 lg:h-12 rounded-md text-primary border-2 border-primary cursor-pointer"
            >
              انصراف
            </button>
            <button
              onClick={() => {
                window.location.href = "https://aut.ncr.ir/";
              }}
              className="flex-1 h-10 lg:h-12 rounded-md text-white bg-primary cursor-pointer"
            >
              ادامه
            </button>
          </div>
        </div>
      </DialogWrapper>
    </div>
  );
};

export default ProfileEditInfo;
