"use client";

import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { ProfileBankAccountContent } from "..";

function ProfileBankAccount({ isOpen, setIsOpen, onSubmit }) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const close = () => {
    setIsOpen(false);
  };

  return isDesktop ? (
    <DialogWrapper isOpen={isOpen} onClose={close}>
      <ProfileBankAccountContent onSubmit={onSubmit} />
    </DialogWrapper>
  ) : (
    <Drawer open={isOpen} onOpenChange={close}>
      <DrawerContent className="z-100! px-[10px]" overlayClassName="z-100">
        <ProfileBankAccountContent onSubmit={onSubmit} />
      </DrawerContent>
    </Drawer>
  );
}

export default ProfileBankAccount;
