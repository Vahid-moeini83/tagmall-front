"use client";

import Image from "next/image";
import { StrokeArrowLeftIcon } from "@/icons";

function ProfileAvatarSourceContent({ user, onBack, onCamera, onGallery }) {
  return (
    <div className="">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="relative w-[50px] h-[50px] rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center bg-white">
            {user?.avatar ? (
              <Image
                src={user.avatar}
                fill
                alt="avatar"
                className="object-cover"
              />
            ) : (
              <span className="text-xs text-gray-400">بدون تصویر</span>
            )}
          </div>

          <h1 className="text-gray-600 text-base">
            {user?.name} {user?.family}
          </h1>
        </div>

        <StrokeArrowLeftIcon onClick={onBack} className="cursor-pointer ml-4" />
      </div>

      <div className="">
        <div
          className="text-primary text-center text-base py-4 cursor-pointer"
          onClick={onCamera}
        >
          تصویر گرفتن با گوشی موبایل
        </div>

        <div className="w-full h-[2px] bg-gray-200" />

        <div
          className="text-primary text-center text-base py-4 cursor-pointer"
          onClick={onGallery}
        >
          انتخاب تصویر از گالری
        </div>
      </div>
    </div>
  );
}

export default ProfileAvatarSourceContent;
