"use client";

import { Input } from "@/components/ui/input";
import { HintIcon } from "@/icons";
import { isValidEmail } from "@/lib/client/validations";
import { useState } from "react";

function ProfileEmailContent({ email, setEmail, onNext }) {
  const [errors, setErrors] = useState({ email: "" });

  const handleSendOtp = () => {
    if (!email) {
      setErrors({ ...errors, email: "ابتدا ایمیل خود را وارد نمایید" });
      return;
    }

    if (!isValidEmail(email)) {
      setErrors({ ...errors, email: "ایمیل معتبر نمی‌باشد" });
      return;
    }

    onNext();
  };

  return (
    <div className="mt-2 lg:mt-0">
      {/* Input */}
      <Input
        label="ایمیل:"
        id="profile_email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className={`text-center text-gray-600 bg-gray-200 ${errors.email ? "" : "border-0!"}`}
        error={errors.email}
      />

      {/* Button */}
      <button
        onClick={handleSendOtp}
        className="mt-3 w-full pb-4 text-primary text-base cursor-pointer"
      >
        ارسال کد تایید
      </button>
    </div>
  );
}

export default ProfileEmailContent;
