"use client";

import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { HintIcon } from "@/icons";
import { formatSheba, toEnglishNumber } from "@/lib/client/utils";
import { getBankBySheba } from "@/lib/client/banks";
import { IranianBank } from "iranian-bank-logo-react";
import { isValidShebaNumber } from "@/lib/client/validations";

function ProfileBankAccountContent({ onSubmit }) {
  const [sheba, setSheba] = useState("");
  const [error, setError] = useState("");
  const [detectedBankName, setDetectedBankName] = useState("");
  const [detectedBankIcon, setDetectedBankIcon] = useState("");

  const handleShebaChange = (e) => {
    const formatted = formatSheba(e.target.value);
    setSheba(formatted);

    if (error) setError("");
  };

  const handleSubmit = () => {
    if (!sheba.trim()) {
      setError("لطفا شماره شبا را وارد کنید");
      return;
    }

    if (!isValidShebaNumber(sheba)) {
      setError("شماره شبا نامعتبر است");
      return;
    }

    onSubmit({
      bankName: detectedBankName,
      sheba: toEnglishNumber(sheba),
    });
  };

  // تشخیص بانک از روی شماره شبا
  useEffect(() => {
    const cleanSheba = toEnglishNumber(sheba).replace(/\s+/g, "").toUpperCase();

    if (cleanSheba.length >= 7) {
      const bankInfo = getBankBySheba(cleanSheba);

      if (bankInfo) {
        setDetectedBankName(bankInfo.name);
        setDetectedBankIcon(bankInfo.icon || "");
      } else {
        setDetectedBankName("");
        setDetectedBankIcon("");
      }
    } else {
      setDetectedBankName("");
      setDetectedBankIcon("");
    }
  }, [sheba]);

  return (
    <div className="mt-2 lg:mt-0">
      <div className="flex flex-col gap-3">
        <span className="text-gray-800 text-base">حساب بانکی:</span>

        <div className="relative">
          <Input
            placeholder="شماره شبا"
            value={sheba}
            onChange={handleShebaChange}
            error={error}
            className={`text-center h-[50px] placeholder:text-gray-400 bg-gray-200 ${error ? "" : "border-0!"}`}
          />

          {detectedBankIcon && (
            <div
              className={`absolute left-3 ${error ? "top-3" : "top-1/2 -translate-y-1/2"} pointer-events-none`}
            >
              <IranianBank name={detectedBankIcon} size={28} />
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 text-gray-600 mt-4 mr-4">
        <HintIcon size={16} />
        حساب بانکی باید به نام شما باشد
      </div>

      <button
        onClick={handleSubmit}
        className="w-full mt-7 pb-4 text-primary text-base cursor-pointer"
      >
        افزودن حساب بانکی
      </button>
    </div>
  );
}

export default ProfileBankAccountContent;
