"use client";

import Image from "next/image";
import { StrokeArrowLeftIcon, UserIcon } from "@/icons";

const ProfileAvatarContent = ({ user, onAdd, onChange, onRemove }) => {
  const hasImage = Boolean(user?.avatar);

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className={`relative w-[50px] h-[50px] rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center ${hasImage ? "bg-white" : "bg-gray-200"}`}
          >
            {hasImage ? (
              <Image
                src={user.avatar}
                fill
                alt="avatar"
                className="object-cover"
              />
            ) : (
              <UserIcon size={20} />
            )}
          </div>

          <h1 className="text-gray-600 text-base">
            {user?.name} {user?.family}
          </h1>
        </div>
      </div>

      <div className="overflow-hidden">
        {!hasImage ? (
          <button
            className="text-primary w-full text-center py-4 flex items-center justify-center gap-2 transition-all cursor-pointer"
            onClick={onAdd}
          >
            افزودن تصویر به حساب کاربری
          </button>
        ) : (
          <>
            <div
              className="text-primary text-base py-4 text-center cursor-pointer"
              onClick={onChange}
            >
              تغییر تصویر حساب کاربری
            </div>

            <div className="w-full h-[2px] bg-gray-200 mr-13" />

            <div
              className="text-error-medium text-center text-base py-4 cursor-pointer"
              onClick={onRemove}
            >
              حذف تصویر حساب کاربری
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ProfileAvatarContent;
