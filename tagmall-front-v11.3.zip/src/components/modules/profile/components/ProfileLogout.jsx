"use client";

import ResponsiveModal from "@/components/ui/responsive-modal";
import ProfileLogoutContent from "./ProfileLogoutContent";

function ProfileLogout({ isOpen, setIsOpen, user, onLogout }) {
  const close = () => setIsOpen(false);

  return (
    <ResponsiveModal isOpen={isOpen} onClose={close}>
      <ProfileLogoutContent
        user={user}
        onLogout={() => {
          onLogout();
          close();
        }}
      />
    </ResponsiveModal>
  );
}

export default ProfileLogout;
