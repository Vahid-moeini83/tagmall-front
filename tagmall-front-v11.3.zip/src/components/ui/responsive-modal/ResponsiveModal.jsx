"use client";

import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";

function ResponsiveModal({ isOpen, onClose, children, title, nested = false }) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  if (isDesktop) {
    return (
      <DialogWrapper
        isOpen={isOpen}
        onClose={onClose}
        title={title}
        className={nested ? "z-300!" : undefined}
        overlayClassName={nested ? "z-250!" : undefined}
      >
        {children}
      </DialogWrapper>
    );
  }

  return (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent className="z-100! px-[10px]" overlayClassName="z-100">
        {title && <h2 className="text-primary text-lg mb-2">{title}</h2>}
        {children}
      </DrawerContent>
    </Drawer>
  );
}

export default ResponsiveModal;
