"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import Image from "next/image";
import { CloseIcon, SupportIcon } from "@/icons";
import { useKeenSlider } from "keen-slider/react";
import "keen-slider/keen-slider.min.css";
import Link from "next/link";
import { useState, useEffect } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { SupportSingleChat } from "..";
import { getConversations } from "@/lib/server/actions/support";
import usePublicStore from "@/app/store/publicStore";
import { getToken } from "@/lib/server/cookies";

function SupportChats({ isMobile = false }) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const [currentSlide, setCurrentSlide] = useState(0);
  const [deleteMode, setDeleteMode] = useState(false);
  const [pendingDeletes, setPendingDeletes] = useState([]);
  const [chatItems, setChatItems] = useState([
    {
      id: 1,
      name: "وحید معینی",
      msg: "سلام، محصول رو دریافت کردم ممنون",
      isSupport: false,
    },
  ]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchConversations = async () => {
    // API call commented out - using test data
    // const token = await getToken();
    // setLoading(true);
    // const { conversationsRes, conversationsErr } =
    //   await getConversations(token);
    // if (conversationsRes) {
    //   console.log("Conversations Response:", conversationsRes);
    //   // TODO: Map the response to chatItems format after seeing the actual response
    //   setChatItems(conversationsRes.data || []);
    // } else if (conversationsErr) {
    //   console.error("Error fetching conversations:", conversationsErr);
    // }
    // setLoading(false);
  };

  const [imagesSliderRef, imagesSlider] = useKeenSlider({
    vertical: isMobile ? false : true,
    loop: true,
    rtl: true,
    slides: {
      origin: "center",
      perView: isMobile ? 1 : 1.25,
      spacing: 24,
    },
    slideChanged(s) {
      setCurrentSlide(s.track.details.rel);
    },
  });

  const handleBulletPointsClick = (index) => {
    setCurrentSlide(index);
    imagesSlider.current?.moveToIdx(index, true);
  };

  const handleDeleteButtonClick = () => {
    if (deleteMode) {
      handleConfirmDeletes();
    } else {
      setDeleteMode(true);
    }
  };

  const handleDeleteItem = (id) => {
    const deletedItem = chatItems.find((item) => item.id === id);

    setChatItems((prev) => prev.filter((item) => item.id !== id));

    setPendingDeletes((prev) => [...prev, deletedItem]);
  };

  const handleConfirmDeletes = () => {
    setPendingDeletes([]);
    setDeleteMode(false);
  };

  const handleOpenChat = (conversation) => {
    setSelectedConversation(conversation);
    setIsOpen(true);
  };

  useEffect(() => {
    // fetchConversations(); // Commented out - using test data
  }, []);

  return (
    <>
      <Accordion type="single" collapsible defaultValue="chats">
        <AccordionItem value="chats">
          <AccordionTrigger className="hidden lg:flex font-bold! font-iransans text-base lg:text-xl text-primary justify-between hover:no-underline cursor-pointer">
            پیام ها
          </AccordionTrigger>

          <AccordionContent className="lg:mt-4 lg:h-[500px] pb-40 lg:pb-0 overflow-hidden">
            <div className="flex flex-col-reverse lg:flex-row gap-2 h-full">
              <div className="flex flex-1 flex-col h-full">
                {loading ? (
                  <div className="flex flex-col gap-1 overflow-y-auto scroll-hidden flex-1 pr-1 mt-2">
                    {/* Skeleton loader for chat items */}
                    {[1, 2, 3, 4].map((item) => (
                      <div key={item}>
                        {item > 1 && (
                          <div className="w-full h-[2px] bg-gray-200 mr-12" />
                        )}
                        <div className="flex items-start gap-[6px] lg:gap-3 pt-2 pb-1 lg:pb-3">
                          <div className="w-10 h-10 rounded-[14px] bg-gray-200 animate-pulse" />
                          <div className="flex flex-col lg:gap-6 lg:pt-2 flex-1">
                            <div className="h-3 lg:h-4 bg-gray-200 rounded animate-pulse w-20 lg:w-24" />
                            <div className="flex items-center gap-1 mt-1 lg:mt-0">
                              <div className="h-3 lg:h-4 bg-gray-200 rounded animate-pulse w-28 lg:w-40" />
                              <div className="h-3 lg:h-4 bg-gray-200 rounded animate-pulse w-24 lg:w-32" />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : chatItems.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <p className="font-iransans text-gray-400 text-sm lg:text-base mt-6 lg:mt-0">
                      هنوز گفت و گویی وجود ندارد
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex flex-col gap-1 overflow-y-auto scroll-hidden flex-1 pr-1 mt-2">
                      {chatItems.length > 0 && chatItems[0]?.isSupport && (
                        <div className="flex items-start gap-[6px] lg:gap-3 pb-1 lg:pb-3">
                          <div className="w-10 h-10 flex items-center justify-center rounded-[14px] border-2 border-gray-200">
                            <SupportIcon size={20} />
                          </div>

                          <div className="flex flex-col lg:gap-6">
                            <div
                              onClick={() => handleOpenChat(chatItems[0])}
                              className="font-bold text-gray-600 text-xs lg:text-base cursor-pointer"
                            >
                              واحد پشتیبانی
                            </div>

                            <div className="flex items-center gap-1">
                              <p className="font-iransans font-semibold text-gray-600 mb-0! max-w-[132px] lg:max-w-[200px] line-clamp-1 text-xs lg:text-base">
                                {chatItems[0].msg}
                              </p>
                              <span className="font-bold text-gray-400 text-xs lg:text-base">
                                2 ساعت پیش دریافت شد
                              </span>
                            </div>
                          </div>
                        </div>
                      )}

                      {chatItems
                        .filter((i) => !i.isSupport)
                        .map((item) => (
                          <div key={item.id}>
                            <div
                              onClick={() => handleOpenChat(item)}
                              className="relative flex items-start gap-[6px] lg:gap-3 not-first:pt-2 pb-1 lg:pb-3 cursor-pointer"
                            >
                              <Image
                                src="/assets/images/fallback/avatar.png"
                                width={40}
                                height={40}
                                alt="عکس پروفایل"
                                className="rounded-[14px] bg-gray-200"
                              />

                              <div className="flex flex-col lg:gap-6 lg:pt-2">
                                <div className="font-bold text-gray-600 text-xs lg:text-base">
                                  {item.name}
                                </div>

                                <div className="flex items-center gap-1">
                                  <p className="font-iransans font-semibold text-gray-600 mb-0! max-w-[132px] lg:max-w-[200px] line-clamp-1 text-xs lg:text-base">
                                    {item.msg}
                                  </p>
                                  <span className="font-bold text-gray-400 text-xs lg:text-base">
                                    2 ساعت پیش دریافت شد
                                  </span>
                                </div>
                              </div>

                              {/* Delete icon */}
                              {deleteMode && (
                                <button
                                  onClick={() => handleDeleteItem(item.id)}
                                  className="absolute left-[6px] top-1/2 -translate-y-1/2 cursor-pointer"
                                >
                                  <CloseIcon />
                                </button>
                              )}
                              {/* Notification */}
                              {!deleteMode && item.id % 3 === 0 && (
                                <div className="absolute left-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-error-medium" />
                              )}
                            </div>
                            {chatItems.length > 1 && (
                              <div className="w-full h-[2px] bg-gray-200 mr-12" />
                            )}
                          </div>
                        ))}
                    </div>

                    <div className="hidden lg:flex sticky bottom-0 bg-white pt-4 pb-2 justify-center">
                      <button
                        className="text-primary cursor-pointer"
                        onClick={handleDeleteButtonClick}
                      >
                        {deleteMode ? "تایید" : "پاک کردن پیام ها"}
                      </button>
                    </div>
                  </>
                )}
              </div>

              <div className="relative flex-1 flex mt-2">
                <div className="keen-slider" ref={imagesSliderRef}>
                  {[0, 1, 2].map((item) => (
                    <div
                      key={item}
                      className={`relative keen-slider__slide h-[120px] ${
                        item !== currentSlide ? "w-[80%]! mx-auto" : "w-full!"
                      }`}
                    >
                      <Image
                        src="/assets/images/home/sampleMap.jpg"
                        fill
                        alt="تبلیغات"
                        className="rounded-lg"
                        objectFit="cover"
                      />
                    </div>
                  ))}
                </div>
                {/* Bullet navigation */}
                <div className="lg:hidden absolute bottom-2 left-1/2 -translate-x-1/2 flex justify-center gap-2 z-10 pointer-events-none">
                  {[0, 1, 2].map((_, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleBulletPointsClick(idx)}
                      className={`h-3 rounded-full transition-all cursor-pointer pointer-events-auto ${
                        currentSlide === idx
                          ? "bg-primary w-5"
                          : "bg-gray-300 w-3 hover:bg-gray-400"
                      }`}
                      aria-label={`اسلاید ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {!loading && chatItems.length > 0 && (
              <div className="lg:hidden fixed bottom-17 right-0 left-0 bg-white py-4 flex justify-center items-center">
                <button
                  className="text-primary cursor-pointer"
                  onClick={handleDeleteButtonClick}
                >
                  {deleteMode ? "تایید" : "پاک کردن پیام ها"}
                </button>
              </div>
            )}
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      {isDesktop ? (
        isOpen &&
        selectedConversation && (
          <div className="fixed inset-0 z-1000 bg-white h-screen">
            <SupportSingleChat
              isOpen={isOpen}
              setIsOpen={setIsOpen}
              conversation={selectedConversation}
            />
          </div>
        )
      ) : (
        <Drawer
          open={isOpen}
          onOpenChange={() => setIsOpen(false)}
          dismissible={true}
          shouldScaleBackground={false}
        >
          <DrawerContent
            className="z-100! px-[10px] h-[96%]! fixed!"
            overlayClassName="z-100 lg:hidden"
          >
            {selectedConversation && (
              <SupportSingleChat
                isOpen={isOpen}
                setIsOpen={setIsOpen}
                conversation={selectedConversation}
              />
            )}
          </DrawerContent>
        </Drawer>
      )}
    </>
  );
}

export default SupportChats;
