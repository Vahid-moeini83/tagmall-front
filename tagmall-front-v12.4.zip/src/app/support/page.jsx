import { SupportContent } from "@/components/modules/support";
import { getConversations } from "@/lib/server/actions/support";
import { getToken } from "@/lib/server/cookies";

async function SupportPage() {
  const token = getToken();

  // const { conversationsRes, conversationsErr } = await getConversations(token);

  // console.log(conversationsRes);

  return <SupportContent />;
}

export default SupportPage;
