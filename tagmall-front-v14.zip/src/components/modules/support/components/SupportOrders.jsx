"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ArrowUpDownIcon, SupportIcon } from "@/icons";
import { useCallback, useEffect, useRef, useState } from "react";
import { FilterOrdersDrawer, OrderStatusFilterDialog } from "..";
import { getToken } from "@/lib/server/cookies";
import { useRouter } from "next/navigation";
import usePublicStore from "@/app/store/publicStore";
import toast from "react-hot-toast";
import { createConversation } from "@/lib/server/actions/support";
import { getUserOrders } from "@/lib/server/actions/cart";
import { OrderItemsSkeleton } from "@/components/ui/loading/cart";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import {
  mockSupportOrders,
  USE_MOCK_SUPPORT_ORDERS,
} from "@/lib/client/mockSupportOrders";
import {
  filterSupportOrders,
  groupFlattenedOrderItems,
  normalizeOrdersFromApi,
} from "@/lib/client/supportOrderUtils";
import SupportOrderCard from "./SupportOrderCard";
import SupportOrderDesktop from "./SupportOrderDesktop";

const sortOptions = [
  { id: "pickup", label: "خرید حضوری" },
  { id: "shipping", label: "خرید آنلاین" },
];

const statusOptions = [
  { id: "delivered", label: "تحویل داده شده" },
  { id: "sending", label: "در حال ارسال" },
];

function SupportOrders({ initialOrders }) {
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);
  const [isFiltersDrawerOpen, setIsFiltersDrawerOpen] = useState(false);
  const [expandedFilter, setExpandedFilter] = useState([]);
  const [orderType, setOrderType] = useState(null);
  const [orderStatus, setOrderStatus] = useState(null);
  const [orders, setOrders] = useState(
    USE_MOCK_SUPPORT_ORDERS ? mockSupportOrders : [],
  );
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(!USE_MOCK_SUPPORT_ORDERS);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  const observer = useRef();

  const router = useRouter();

  const setLoginOpen = usePublicStore((state) => state.setLoginOpen);

  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const handleFilterToggle = (filterId) => {
    setExpandedFilter((prev) =>
      prev.includes(filterId)
        ? prev.filter((id) => id !== filterId)
        : [...prev, filterId],
    );
  };

  const getFilterLabel = () => {
    if (!orderType) return "انتخاب کنید";
    const option = sortOptions.find((o) => o.id === orderType);
    return option?.label || "";
  };

  const getStatusLabel = () => {
    if (!orderStatus) return "انتخاب کنید";
    const option = statusOptions.find((o) => o.id === orderStatus);
    return option?.label || "";
  };

  const filteredOrders = filterSupportOrders(orders, {
    orderType,
    orderStatus,
  });

  const handleSupport = async () => {
    const token = await getToken();

    if (!token) {
      setLoginOpen(true);
      return;
    }

    const bodyData = {
      department: 2,
    };

    const { createConversationRes, createConversationErr } =
      await createConversation(token, bodyData);

    if (createConversationRes) {
      const conversationId = createConversationRes.data?.id;

      if (conversationId) {
        router.push(`/support?conversationId=${conversationId}&tab=chats`);
      } else {
        toast.error("Error connecting to support");
      }
    } else if (createConversationErr) {
      toast.error("Error connecting to support");
    }
  };

  const fetchOrders = useCallback(
    async (pageNumber = 1) => {
      if (USE_MOCK_SUPPORT_ORDERS || isLoadingOrders) return;

      setIsLoadingOrders(true);

      const token = await getToken();

      const { ordersRes, ordersErr } = await getUserOrders(token, pageNumber);

      if (ordersRes) {
        const normalizedOrders = normalizeOrdersFromApi(ordersRes.data || []);

        setOrders((prev) =>
          pageNumber === 1 ? normalizedOrders : [...prev, ...normalizedOrders],
        );

        const currentPage = ordersRes.meta?.current_page || 1;
        const lastPage = ordersRes.meta?.last_page || 1;

        setHasMore(currentPage < lastPage);
      } else if (ordersErr) {
        toast.error("Error fetching user orders");
      }

      setIsLoadingOrders(false);
    },
    [isLoadingOrders],
  );

  const lastOrderElementRef = useCallback(
    (node) => {
      if (isLoadingOrders) return;

      if (observer.current) observer.current.disconnect();

      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          const nextPage = page + 1;

          setPage(nextPage);
          fetchOrders(nextPage);
        }
      });

      if (node) observer.current.observe(node);
    },
    [isLoadingOrders, hasMore, page, fetchOrders],
  );

  useEffect(() => {
    if (USE_MOCK_SUPPORT_ORDERS) return;

    if (initialOrders) {
      const normalizedOrders = normalizeOrdersFromApi(initialOrders.data || []);
      const fallbackOrders = normalizedOrders.length
        ? normalizedOrders
        : groupFlattenedOrderItems(initialOrders.data || []);

      setOrders(fallbackOrders);

      const currentPage = initialOrders.meta?.current_page || 1;
      const lastPage = initialOrders.meta?.last_page || 1;

      setHasMore(currentPage < lastPage);
      setPage(currentPage);
    }
  }, [initialOrders]);

  return (
    <>
      <Accordion type="single" collapsible defaultValue="chats">
        <AccordionItem value="chats">
          <AccordionTrigger className="hidden lg:flex font-bold! text-base lg:text-xl text-primary justify-between hover:no-underline cursor-pointer">
            پیگیری سفارشات
          </AccordionTrigger>
          <AccordionContent className="lg:mt-4">
            {/* Filters (Desktop) */}
            <div className="hidden lg:flex items-center gap-0">
              <div className="flex items-center gap-5 pl-[18px] border-l-2 border-gray-200">
                <span className="text-gray-800 shrink-0">نوع سفارش:</span>

                <div className="flex items-center gap-5">
                  {sortOptions.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => setOrderType(option.id)}
                      className={`transition-all shrink-0 cursor-pointer ${
                        orderType === option.id
                          ? "text-primary"
                          : "text-gray-600 hover:opacity-80"
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="px-4 border-l-2 border-gray-200">
                <button
                  onClick={() => setIsStatusDialogOpen(true)}
                  className="text-primary shrink-0 cursor-pointer"
                >
                  وضعیت سفارش ({getStatusLabel()})
                </button>
              </div>

              <div className="px-4 border-l-2 border-gray-200">
                <button className="text-primary shrink-0 cursor-pointer">
                  جست و جوی سفارش
                </button>
              </div>

              <div className="pr-4">
                <button
                  onClick={handleSupport}
                  className="font-iransans font-semibold! text-primary shrink-0 cursor-pointer"
                >
                  ارتباط با واحد پشتیبانی
                </button>
              </div>
            </div>

            {/* Filters (Mobile) */}
            <div
              className="lg:hidden text-xs flex items-center gap-2 mt-6 mb-8 pr-2 cursor-pointer"
              onClick={() => setIsFiltersDrawerOpen(true)}
            >
              <ArrowUpDownIcon size={20} />
              <span className="text-gray-600 text-sm font-extralight">
                <span className="font-bold">اولویت نمایش</span>:{" "}
                {getFilterLabel()}
              </span>
            </div>

            <div className="space-y-6 lg:space-y-10 lg:mt-10">
              {isLoadingOrders && orders.length === 0 ? (
                <OrderItemsSkeleton isMobile={!isDesktop} />
              ) : filteredOrders.length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  سفارشی با این فیلترها یافت نشد
                </div>
              ) : (
                filteredOrders.map((order, index) => (
                  <div
                    key={order.order_id ?? order.order_number}
                    ref={
                      filteredOrders.length === index + 1
                        ? lastOrderElementRef
                        : null
                    }
                    className={`pb-1 lg:pb-8 lg:mx-4 xl:mx-8 ${filteredOrders.length - 1 === index ? "" : "lg:border-b-2 lg:border-gray-100"}`}
                  >
                    <div className="lg:hidden">
                      <SupportOrderCard order={order} />
                    </div>
                    <div className="hidden lg:block">
                      <SupportOrderDesktop order={order} />
                    </div>
                  </div>
                ))
              )}
            </div>

            {isLoadingOrders && orders.length > 0 && (
              <div className="mt-6">
                <OrderItemsSkeleton isMobile={!isDesktop} />
              </div>
            )}

            <div className="lg:hidden fixed bottom-17 right-0 left-0 bg-white py-4 px-[10px] flex justify-center items-center z-10">
              <button
                type="button"
                onClick={handleSupport}
                className="font-iransans font-semibold text-primary cursor-pointer border-2 border-primary py-2 rounded-full w-full flex items-center justify-center gap-2"
              >
                <SupportIcon size={20} />
                ارتباط با واحد پشتیبانی
              </button>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      <FilterOrdersDrawer
        isOpen={isFiltersDrawerOpen}
        onClose={() => setIsFiltersDrawerOpen(false)}
        expandedFilter={expandedFilter}
        onFilterToggle={handleFilterToggle}
        orderType={orderType}
        onOrderTypeChange={setOrderType}
        orderStatus={orderStatus}
        onStatusChange={setOrderStatus}
      />
      <OrderStatusFilterDialog
        isOpen={isStatusDialogOpen}
        onClose={() => setIsStatusDialogOpen(false)}
        selectedStatus={orderStatus}
        onConfirm={(status) => {
          setOrderStatus(status);
          setIsStatusDialogOpen(false);
        }}
      />
    </>
  );
}

export default SupportOrders;
