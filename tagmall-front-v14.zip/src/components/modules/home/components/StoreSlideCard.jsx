"use client";

import Image from "next/image";
import { useCallback, useEffect, useMemo, useRef } from "react";
import { StarIcon, VerifyIcon } from "@/icons";
import { cn } from "@/lib/client/utils";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import HorizontalProductSlider from "./HorizontalProductSlider";

export default function StoreSlideCard({
  store,
  storeIdx,
  activeIndex,
  isSpecialSale,
  remainingTime,
  onScrollEdge,
}) {
  const scrollContainerRef = useRef(null);
  const purchasedSectionRef = useRef(null);

  const specialProducts = useMemo(
    () => store.products.filter((p) => p.isSpecialSale),
    [store.products],
  );

  const nonSpecialProducts = useMemo(
    () => store.products.filter((p) => !p.isSpecialSale),
    [store.products],
  );

  const scrollToPurchasedSection = useCallback(() => {
    const container = scrollContainerRef.current;
    const section = purchasedSectionRef.current;
    if (!container || !section) return;

    const top =
      section.getBoundingClientRect().top -
      container.getBoundingClientRect().top +
      container.scrollTop;

    container.scrollTo({ top, behavior: "smooth" });
  }, []);

  const handlePurchasedAccordionChange = useCallback(
    (value) => {
      if (value !== "purchased") return;

      requestAnimationFrame(() => {
        setTimeout(scrollToPurchasedSection, 220);
      });
    },
    [scrollToPurchasedSection],
  );

  const isSlideActive = activeIndex === storeIdx;

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer || !isSlideActive || !onScrollEdge) return;

    const handleWheel = (event) => {
      const { scrollTop, scrollHeight, clientHeight } = scrollContainer;
      const edgeTolerance = 1;
      const isAtTop = scrollTop <= edgeTolerance;
      const isAtBottom =
        scrollTop + clientHeight >= scrollHeight - edgeTolerance;

      if (event.deltaY > 0 && isAtBottom) {
        onScrollEdge("down");
        return;
      }

      if (event.deltaY < 0 && isAtTop) {
        onScrollEdge("up");
      }
    };

    scrollContainer.addEventListener("wheel", handleWheel, { passive: true });

    return () => {
      scrollContainer.removeEventListener("wheel", handleWheel);
    };
  }, [isSlideActive, onScrollEdge]);

  return (
    <div
      className={cn(
        "bg-white rounded-2xl border-3 border-gray-200 flex flex-col overflow-hidden transition-all duration-300 origin-center",
        isSlideActive ? "w-full h-full" : "mx-auto w-[80%] h-full",
      )}
    >
      <div
        className={cn(
          "flex flex-col h-full min-h-0 transition-opacity duration-300",
          isSlideActive ? "opacity-100" : "opacity-0 pointer-events-none",
        )}
      >
        <div className="flex items-center justify-between px-[50px] pt-[32px] shrink-0">
          <div className="flex items-center gap-2">
            <div className="relative w-[50px] h-[50px] rounded-lg overflow-hidden">
              <Image
                src={
                  store.seller.profileImage ||
                  "/assets/images/fallback/no-photo.jpg"
                }
                fill
                alt={store.seller.name}
                className="object-cover"
              />
            </div>
            <div className="flex flex-col gap-0.5">
              <div className="flex items-center gap-1">
                <span className="font-bold text-sm text-gray-700">
                  {store.storeName || store.seller.name}
                </span>
                <VerifyIcon size={15} />
              </div>
            </div>
          </div>
          {isSpecialSale && remainingTime && (
            <span className="text-error-medium text-lg font-bold tabular-nums">
              {remainingTime}
            </span>
          )}
        </div>

        <div
          ref={scrollContainerRef}
          data-store-scroll
          className="swiper-no-mousewheel flex-1 overflow-y-auto"
        >
          {specialProducts.length > 0 && (
            <Accordion type="single" collapsible defaultValue="special">
              <AccordionItem value="special">
                <AccordionTrigger className="flex items-center justify-between pr-[50px] pl-[64px]">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-start gap-1">
                      <StarIcon className="text-yellow-600 w-3 h-3 mt-0.5" />
                      <span>
                        {store.seller.rating}
                        <span className="text-gray-400 text-sm">/5</span>
                      </span>
                    </div>
                    <span className="text-gray-400">
                      آرا {store.seller.totalReviews}
                    </span>
                  </div>
                  <span className="font-bold text-error-medium text-lg pl-5">
                    فروش ویژه
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <HorizontalProductSlider
                    products={specialProducts}
                    isSpecialSale={true}
                  />
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          )}

          {nonSpecialProducts.length > 0 && (
            <div className="w-[82%] h-[2.5px] bg-gray-200 mx-auto my-3" />
          )}

          {nonSpecialProducts.length > 0 && (
            <div ref={purchasedSectionRef}>
              <Accordion
                type="single"
                collapsible
                onValueChange={handlePurchasedAccordionChange}
              >
                <AccordionItem value="purchased">
                  <AccordionTrigger className="flex items-center justify-between pr-[50px] pl-[64px] mb-2">
                    <div></div>
                    <span className="font-bold text-base text-primary pr-4">
                      سفارشات{" "}
                      <span className="font-extralight">(خرید حضوری)</span>
                    </span>
                  </AccordionTrigger>
                  <AccordionContent>
                    <HorizontalProductSlider
                      products={nonSpecialProducts}
                      isSpecialSale={false}
                    />
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
