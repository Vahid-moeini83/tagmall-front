"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { Mousewheel } from "swiper/modules";
import "swiper/css";
import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { DialogWrapper } from "@/components/ui/dialog";
import StoreSlideCard from "./StoreSlideCard";

export default function ProductsSlider({
  storeProducts,
  onProductChange,
  activeSellerId,
  purchasedProducts,
  filterMode,
  remainingTime,
}) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isNoteOpen, setIsNoteOpen] = useState(false);
  const verticalSwiperRef = useRef(null);

  const filteredStores = useMemo(() => {
    if (!storeProducts || storeProducts.length === 0) return [];

    if (filterMode === "visit") {
      return storeProducts.filter((store) =>
        purchasedProducts.some((p) => p.storeId === store.storeId),
      );
    }

    if (filterMode === "special") {
      return storeProducts.filter((store) =>
        store.products.some((p) => p.isSpecialSale),
      );
    }

    return storeProducts;
  }, [storeProducts, filterMode, purchasedProducts]);

  const storeCount = filteredStores.length;
  const isSpecialSale = filterMode === "special" || filterMode === "all";

  const filteredStoresRef = useRef(filteredStores);
  useEffect(() => {
    filteredStoresRef.current = filteredStores;
  });

  useEffect(() => {
    if (!verticalSwiperRef.current || !activeSellerId) return;
    const idx = filteredStores.findIndex(
      (store) => store.storeId === activeSellerId,
    );
    if (idx < 0 || verticalSwiperRef.current.realIndex === idx) return;
    verticalSwiperRef.current.slideTo(idx, 300);
  }, [activeSellerId, filteredStores]);

  useEffect(() => {
    if (!verticalSwiperRef.current || filteredStores.length === 0) return;
    const isActiveVisible = filteredStores.some(
      (store) => store.storeId === activeSellerId,
    );
    if (isActiveVisible) return;

    verticalSwiperRef.current.slideTo(0, 0);
    const firstStore = filteredStores[0];
    if (firstStore?.products?.length > 0) {
      onProductChange?.(firstStore.products[0]);
    }
  }, [filterMode, filteredStores, activeSellerId, onProductChange]);

  useEffect(() => {
    if (verticalSwiperRef.current && filteredStores.length > 0) {
      verticalSwiperRef.current.update();
    }
  }, [filteredStores]);

  const handleSlideChange = useCallback(
    (swiper) => {
      const idx = swiper.realIndex;
      setActiveIndex(idx);
      const store = filteredStoresRef.current[idx];
      if (store?.products?.length > 0) {
        onProductChange?.(store.products[0]);
      }
    },
    [onProductChange],
  );

  const handleScrollEdge = useCallback((direction) => {
    const swiper = verticalSwiperRef.current;
    if (!swiper) return;

    if (direction === "down") {
      swiper.slideNext();
      return;
    }

    swiper.slidePrev();
  }, []);

  if (storeCount === 0) return null;

  return (
    <div className="flex flex-col h-full min-h-0 overflow-hidden">
      <Swiper
        direction="vertical"
        modules={[Mousewheel]}
        slidesPerView={1.08}
        spaceBetween={5}
        centeredSlides
        roundLengths
        mousewheel={{
          forceToAxis: true,
          releaseOnEdges: true,
          sensitivity: 1,
          thresholdDelta: 8,
        }}
        onSwiper={(swiper) => {
          verticalSwiperRef.current = swiper;
          setActiveIndex(swiper.realIndex);
          const stores = filteredStoresRef.current;

          if (activeSellerId) {
            const idx = stores.findIndex(
              (store) => store.storeId === activeSellerId,
            );
            if (idx >= 0) {
              swiper.slideTo(idx, 0);
              return;
            }
          }

          const firstStore = stores[0];
          if (firstStore?.products?.length > 0) {
            onProductChange?.(firstStore.products[0]);
          }
        }}
        onSlideChange={handleSlideChange}
        className="w-full h-full min-h-0"
      >
        {filteredStores.map((store, storeIdx) => (
          <SwiperSlide
            key={store.storeId}
            className="flex! h-auto! items-center! justify-center!"
          >
            <StoreSlideCard
              store={store}
              storeIdx={storeIdx}
              activeIndex={activeIndex}
              isSpecialSale={isSpecialSale}
              remainingTime={remainingTime}
              onScrollEdge={handleScrollEdge}
            />
          </SwiperSlide>
        ))}
      </Swiper>

      <DialogWrapper
        title={"اسم محصول"}
        isOpen={isNoteOpen}
        onClose={() => setIsNoteOpen(false)}
      >
        یادداشت کاربر: لطفا محصول را در بسته بندی تیره قرار دهید. ممنون!
      </DialogWrapper>
    </div>
  );
}
