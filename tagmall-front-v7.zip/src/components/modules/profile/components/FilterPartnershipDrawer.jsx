"use client";

import { Drawer, DrawerContent, DrawerTitle } from "@/components/ui/drawer";
import { ChevronDownIcon, ChevronUpIcon } from "@/icons";
import PartnershipFilterContent from "./PartnershipFilterContent.jsx";

function FilterPartnershipDrawer({
  isOpen,
  onClose,
  expandedFilter,
  onFilterToggle,
  selectedFilter,
  onFilterChange,
  options,
}) {
  const mobileFilters = [{ id: "suggestions", label: "پیشنهادات" }];

  const getFilterValue = (filterId) => {
    if (filterId === "suggestions") {
      const option = options.find((o) => o.id === selectedFilter);
      return option ? option.label : "";
    }
    return "";
  };

  return (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent overlayClassName="lg:hidden">
        {/* Title */}
        <DrawerTitle>مشارکت در فروش</DrawerTitle>

        {/* Content */}
        <div className="flex-1 overflow-y-auto my-2">
          {mobileFilters.map((filter, index) => (
            <div
              key={filter.id}
              className={`${
                mobileFilters.length - 1 === index
                  ? ""
                  : "border-b-2 border-gray-200"
              }`}
            >
              <button
                onClick={() => onFilterToggle(filter.id)}
                className={`relative flex items-center justify-between w-full py-4`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-gray-600 font-bold">
                    {filter.label}:
                  </span>
                  {getFilterValue(filter.id) && (
                    <span className="text-sm text-gray-600">
                      {getFilterValue(filter.id)}
                    </span>
                  )}
                </div>
                {expandedFilter.includes(filter.id) ? (
                  <ChevronUpIcon
                    size={20}
                    color="var(--color-gray-800)"
                    className="ml-2"
                  />
                ) : (
                  <ChevronDownIcon
                    size={20}
                    color="var(--color-gray-800)"
                    className="ml-2"
                  />
                )}
              </button>

              {/* Filter Content */}
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  expandedFilter.includes(filter.id)
                    ? "max-h-[1000px] opacity-100"
                    : "max-h-0 opacity-0"
                }`}
              >
                {expandedFilter.includes(filter.id) && (
                  <div className="pb-3">
                    {filter.id === "suggestions" && (
                      <PartnershipFilterContent
                        selectedFilter={selectedFilter}
                        onFilterChange={onFilterChange}
                      />
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        <button className="text-primary cursor-pointer py-4">
          کالای خاصی در نظر دارید؟
        </button>
      </DrawerContent>
    </Drawer>
  );
}

export default FilterPartnershipDrawer;
