import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";

export default function ProductSpecifications() {
  const specifications = [
    {
      title: "ابعاد",
      description: "12 * 32 میلی متر",
    },
    {
      title: "وزن",
      description: "203 گرم",
    },
    {
      title: "توضیحات سیم کارت",
      description: "سایز نانو",
    },
    {
      title: "ساختار بدنه",
      description:
        "فلز و شیشه ( قاب جلو و پشت شیشه‌ای با فریمی از جنس فولاد ضدزنگ ) دارای استاندارد IP۶۸ برای مقاومت در برابر آب ( به مدت ۳۰ دقیقه در عمق ۶ متر ) صفحه نمایش با شیشه مقاوم در برابر خط و خش به همراه محافظ Ceramic Glass دارای پوشش Olephobic برای صفحه نمایش",
    },
  ];

  return (
    <div className="lg:bg-white lg:rounded-lg pt-6 lg:p-16">
      <Accordion type="single" collapsible defaultValue="specifications">
        <AccordionItem value="specifications">
          <AccordionTrigger className="hidden lg:flex text-primary text-[16px] lg:text-[20px] font-semibold hover:no-underline justify-between">
            مشخصات
          </AccordionTrigger>
          <AccordionContent className="lg:mt-8">
            <div className="space-y-4">
              {specifications.map((spec, index) => (
                <div key={index}>
                  <div className="flex flex-col gap-2">
                    <h3 className="text-gray-600 text-sm lg:text-base font-bold">
                      {spec.title}:
                    </h3>
                    <p className="text-gray-600 text-xs/8 lg:text-base/12 mb-2! lg:mb-0!">
                      {spec.description}
                    </p>
                  </div>
                  {index < specifications.length - 1 && (
                    <div className="border-t-2 border-white lg:border-gray-200 lg:mt-1" />
                  )}
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
