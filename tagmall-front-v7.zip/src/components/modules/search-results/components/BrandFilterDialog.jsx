"use client";

import { useState } from "react";
import { DialogWrapper } from "@/components/ui/dialog";
import BrandFilterContent from "./BrandFilterContent";

function BrandFilterDialog({ isOpen, onClose }) {
  const [selectedBrands, setSelectedBrands] = useState([]);

  const handleBrandToggle = (brandId) => {
    setSelectedBrands((prev) =>
      prev.includes(brandId)
        ? prev.filter((id) => id !== brandId)
        : [...prev, brandId],
    );
  };

  const handleConfirm = () => {
    console.log("Selected brands:", selectedBrands);
    onClose();
  };

  return (
    <DialogWrapper
      isOpen={isOpen}
      onClose={onClose}
      showCloseButton={false}
      // title={"انتخاب برند"}
    >
      <div className="mb-6">
        <BrandFilterContent
          selectedBrands={selectedBrands}
          onBrandToggle={handleBrandToggle}
        />
      </div>

      <button
        onClick={handleConfirm}
        className="w-full h-12 bg-primary text-white rounded-md  transition-opacity hover:opacity-90"
      >
        تایید
      </button>
    </DialogWrapper>
  );
}

export default BrandFilterDialog;
