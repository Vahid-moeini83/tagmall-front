"use client";

import { useRouter } from "next/navigation";

function DragHandler({ hasCloseEvent = false, onClose }) {
  const router = useRouter();

  const handleOnMouseDown = () => {
    if (hasCloseEvent) {
      onClose();
      return;
    }

    router.back();
  };

  return (
    <div
      onTouchStart={handleOnMouseDown}
      onMouseDown={handleOnMouseDown}
      className="w-30 h-1 rounded-full bg-gray-300 cursor-pointer"
    />
  );
}

export default DragHandler;
