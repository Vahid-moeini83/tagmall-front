import { ProfileReceivedLinks } from "@/components/modules/profile";

function ProfileReceivedLinksPage() {
  return <ProfileReceivedLinks />;
}

export default ProfileReceivedLinksPage;
