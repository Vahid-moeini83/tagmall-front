import { ProfilePartnership } from "@/components/modules/profile";

function ProfilePartnershipPage() {
  return <ProfilePartnership/>;
}

export default ProfilePartnershipPage;
