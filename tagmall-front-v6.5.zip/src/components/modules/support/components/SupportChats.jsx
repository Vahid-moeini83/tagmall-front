"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import Image from "next/image";
import { CloseIcon, SupportIcon } from "@/icons";
import { useKeenSlider } from "keen-slider/react";
import "keen-slider/keen-slider.min.css";
import Link from "next/link";
import { useState } from "react";

function SupportChats({ isMobile = false }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [deleteMode, setDeleteMode] = useState(false);

  const [imagesSliderRef, imagesSlider] = useKeenSlider({
    vertical: isMobile ? false : true,
    loop: true,
    rtl: true,
    slides: {
      perView: isMobile ? 1 : 1.15,
      spacing: 28,
    },
    slideChanged(s) {
      setCurrentSlide(s.track.details.rel);
    },
  });

  const handleBulletPointsClick = (index) => {
    setCurrentSlide(index);
    imagesSlider.current?.moveToIdx(index, true);
  };

  // Handle delete button
  const handleDeleteButtonClick = () => {
    if (deleteMode) {
      setDeleteMode(false);
      return;
    }

    setDeleteMode(true);
  };

  // Handle delete items
  const handleDeleteItem = (id) => {
    // ...
  }

  return (
    <Accordion type="single" collapsible defaultValue="chats">
      <AccordionItem value="chats">
        <AccordionTrigger className="hidden lg:flex font-bold! font-iransans text-base lg:text-xl text-primary justify-between hover:no-underline cursor-pointer">
          پیام ها
        </AccordionTrigger>
        <AccordionContent className="lg:mt-4 lg:h-[640px] pb-40 lg:pb-0">
          <div className="flex flex-col-reverse lg:flex-row gap-2">
            {/* Chats items */}
            <div className="flex flex-1 flex-col gap-1">
              {/* First suport chat item */}
              <div className="flex items-start gap-[6px] lg:gap-3 pb-3">
                <div className="w-10 h-10 flex items-center justify-center rounded-[14px] border-2 border-gray-200">
                  <SupportIcon size={20} />
                </div>
                <div className="flex flex-col lg:gap-6 pt-2">
                  <Link
                    href="/support/sample"
                    className="font-bold text-gray-600 text-xs lg:text-base"
                  >
                    واحد پشتیبانی
                  </Link>
                  <div className="flex items-center gap-1">
                    <p className="font-iransans font-semibold text-gray-600 mb-0! max-w-[180px] line-clamp-1 text-xs lg:text-base">
                      سلام باشه ممنون از شما خیلی راضی هستم از کیفیت کار شما
                    </p>
                    <span className="font-bold text-gray-400 text-xs lg:text-base">
                      2 ساعت پیش دریافت شد
                    </span>
                  </div>
                </div>
              </div>
              {/* Other chats */}
              {[1, 2, 3, 4, 5, 6].map((item) => (
                <div key={item} className="overflow-hidden">
                  <div className="w-full h-[2px] bg-gray-200 mr-13" />
                  <div className="relative flex items-start gap-[6px] lg:gap-3 pt-1 pb-1 lg:pb-3">
                    <Image
                      src="/assets/images/fallback/avatar.png"
                      width={40}
                      height={40}
                      alt="عکس پروفایل"
                      className="rounded-[14px] bg-gray-200"
                    />
                    <div className="flex flex-col lg:gap-6 lg:pt-2">
                      <Link
                        href="/support/sample"
                        className="font-bold text-gray-600 text-xs lg:text-base"
                      >
                        آرش
                      </Link>
                      <div className="flex items-center">
                        <p className="font-iransans font-semibold text-gray-600 mb-0! max-w-[180px] line-clamp-1 text-xs lg:text-base">
                          سلام باشه ممنون از شما خیلی راضی هستم از کیفیت کار شما
                        </p>
                        <span className="font-bold text-gray-400 text-xs lg:text-base">
                          2 ساعت پیش دریافت شد
                        </span>
                      </div>
                    </div>
                    {/* Red alert point */}
                    {/* {item === 3 && (
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 block w-2 h-2 rounded-full bg-error-medium"></span>
                    )} */}
                    {deleteMode && (
                      <button className="absolute left-[6px] top-1/2 -translate-y-1/2 cursor-pointer">
                        <CloseIcon />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex-1 flex mt-2">
              <div className="keen-slider" ref={imagesSliderRef}>
                {[1, 2, 3].map((item) => (
                  <div
                    key={item}
                    className="relative keen-slider__slide h-[120px]"
                  >
                    <Image
                      src="/assets/images/home/sampleMap.jpg"
                      fill
                      alt="تبلیغات"
                      className="rounded-lg"
                      objectFit="cover"
                    />
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex justify-center gap-2 z-10 pointer-events-none">
                      {[1, 2, 3].map((_, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleBulletPointsClick(idx)}
                          className={`h-3 rounded-full transition-all cursor-pointer pointer-events-auto ${
                            currentSlide === idx
                              ? "bg-primary w-5"
                              : "bg-gray-300 w-3 hover:bg-gray-400"
                          }`}
                          aria-label={`اسلاید ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Mobile delete button */}
          <div className="fixed bottom-17 right-0 left-0 bg-white py-3 flex justify-center items-center">
            <button
              className="text-primary cursor-pointer"
              onClick={handleDeleteButtonClick}
            >
              {deleteMode ? "تایید" : "پاک کردن پیام ها"}
            </button>
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  );
}

export default SupportChats;
