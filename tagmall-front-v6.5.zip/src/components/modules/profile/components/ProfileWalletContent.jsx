"use client";

import { HintIcon } from "@/icons";
import { formatPrice } from "@/lib/client/utils";
import { useState } from "react";

function ProfileWalletContent({ setIsOpen }) {
  const [amount, setAmount] = useState("");

  const handleSuggestedAmount = (value) => {
    setAmount(value.toString());
  };

  return (
    <div className="flex flex-col justify-between h-full space-y-14">
      <div className="space-y-14">
        <p className="text-gray-600">
          لطفا مبلغ مورد نظر برای افزایش موجودی را وارد نمایید.
        </p>
        <div className="space-y-4">
          {/* Amount input */}
          <div className="relative">
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="outline-none border-2 border-gray-300 h-12 rounded-md px-2 w-full text-center"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600 pointer-events-none">
              تومان
            </span>
          </div>

          {/* Default buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => handleSuggestedAmount(500000)}
              className="px-4 flex-1 h-10 border border-gray-300 cursor-pointer rounded-sm hover:bg-gray-50 transition-colors text-sm"
            >
              {formatPrice(500000)} تومان
            </button>
            <button
              onClick={() => handleSuggestedAmount(1000000)}
              className="px-4 h-10 flex-1 border border-gray-300 cursor-pointer rounded-sm hover:bg-gray-50 transition-colors text-sm"
            >
              {formatPrice(1000000)} تومان
            </button>
            <button
              onClick={() => handleSuggestedAmount(2000000)}
              className="px-4 h-10 flex-1 border border-gray-300 cursor-pointer rounded-sm hover:bg-gray-50 transition-colors text-sm"
            >
              {formatPrice(2000000)} تومان
            </button>
          </div>

          {/* Hint text */}
          <div className="text-gray-600 flex items-center gap-1">
            <HintIcon size={16} className="text-gray-600" />
            حداقل مبلغ شارژ {formatPrice(200000)} تومان می‌باشد
          </div>
        </div>
      </div>
      <div className="flex items-center justify-center gap-[10px]">
        <button
          onClick={() => setIsOpen(false)}
          className="rounded-md h-10 flex-1 flex items-center justify-center border-2 border-primary text-primary cursor-pointer transition-all"
        >
          انصراف
        </button>
        <button className="rounded-md h-10 flex-1 flex items-center justify-center bg-primary text-white cursor-pointer transition-all">
          پرداخت
        </button>
      </div>
    </div>
  );
}

export default ProfileWalletContent;
