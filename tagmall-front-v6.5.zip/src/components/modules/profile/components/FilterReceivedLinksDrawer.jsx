"use client";

import { Drawer, DrawerContent, DrawerFooter } from "@/components/ui/drawer";
import { AvailableProductsIcon, ChevronDownIcon, ChevronUpIcon } from "@/icons";
import ReceivedLinksFilterContent from "./ReceivedLinksFilterContent";
import DateRangeFilterContent from "./DateRangeFilterContent";
import { useState } from "react";

function FilterReceivedLinksDrawer({
  isOpen,
  onClose,
  expandedFilter,
  onFilterToggle,
  selectedFilter,
  onFilterChange,
  hasFiltersChanged,
  onResetFilters,
  options,
  showAvailable,
  setShowAvailable,
}) {
  const mobileFilters = [
    { id: "sort", label: "ترتیب نمایش" },
    { id: "dateRange", label: "بازه زمانی" },
  ];

  const getFilterValue = (filterId) => {
    if (filterId === "sort") {
      const option = options.find((o) => o.id === selectedFilter);
      return option ? option.label : "";
    }
    if (filterId === "dateRange") {
      return "۱۴۰۲/۱۰/۰۱ تا ۱۴۰۲/۱۲/۲۹";
    }
    return "";
  };

  return (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent overlayClassName="lg:hidden">
        {/* Header */}
        <div className="relative flex items-center justify-between bg-white rounded-t-2xl px-[10px] pt-6 pb-2">
          <p className="text-center text-base font-bold text-primary">
            لینک های دریافت شده
          </p>
          <AvailableProductsIcon
            onClick={() => setShowAvailable(!showAvailable)}
            active={showAvailable}
            size={20}
            className="cursor-pointer ml-[10px]"
          />
        </div>

        {/* Content */}
        <div className="flex-1 bg-white px-[10px] ">
          {mobileFilters.map((filter, index) => (
            <div
              key={filter.id}
              className={`${
                mobileFilters.length - 1 === index
                  ? ""
                  : "border-b-2 border-gray-200"
              }`}
            >
              <button
                onClick={() => onFilterToggle(filter.id)}
                className={`relative flex items-center justify-between w-full py-4`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-gray-600 font-bold">
                    {filter.label}:
                  </span>
                  {getFilterValue(filter.id) && (
                    <span className="text-sm text-gray-600">
                      {getFilterValue(filter.id)}
                    </span>
                  )}
                </div>
                {expandedFilter.includes(filter.id) ? (
                  <ChevronUpIcon
                    size={20}
                    color="var(--color-gray-800)"
                    className="absolute left-[14px]"
                  />
                ) : (
                  <ChevronDownIcon
                    size={20}
                    color="var(--color-gray-800)"
                    className="absolute left-[14px]"
                  />
                )}
              </button>

              {/* Filter Content */}
              <div
                className={`transition-all duration-300 ${
                  expandedFilter.includes(filter.id)
                    ? "max-h-[1000px] opacity-100"
                    : "max-h-0 opacity-0"
                }`}
              >
                {expandedFilter.includes(filter.id) && (
                  <div className="pb-3">
                    {filter.id === "sort" && (
                      <ReceivedLinksFilterContent
                        selectedFilter={selectedFilter}
                        onFilterChange={onFilterChange}
                      />
                    )}
                    {filter.id === "dateRange" && <DateRangeFilterContent />}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        <button className="text-primary cursor-pointer pt-4 pb-8 bg-white">
          کالای خاصی در نظر دارید؟
        </button>
      </DrawerContent>
    </Drawer>
  );
}

export default FilterReceivedLinksDrawer;
