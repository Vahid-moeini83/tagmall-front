"use client";

import { Radio } from "@/components/ui/radio";
import { PlusIcon, StrokeArrowLeftIcon } from "@/icons";
import { Check, Edit, Trash2 } from "lucide-react";
import Image from "next/image";
import React, { useState } from "react";

const ProfileEditInfo = ({ setIsEditingProfile }) => {
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [addresses, setAddresses] = useState([
    "تهران، خیابان ولیعصر، کوچه سوم، پلاک ۱۲۳",
    "اصفهان، خیابان چهارباغ، نبش خیابان شعا، پلاک ۴۵",
  ]);
  const [selectedAddress, setSelectedAddress] = useState(addresses[0] || "");
  const [showAddAddressInput, setShowAddAddressInput] = useState(false);
  const [newAddress, setNewAddress] = useState("");

  const [editingAddressIndex, setEditingAddressIndex] = useState(null);

  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setProfileImage(e.target.files[0]);
    }
  };

  // Handle save and add
  const handleSaveAddress = (e) => {
    e.preventDefault();
    const addressValue = newAddress.trim();
    if (!addressValue) return;

    if (editingAddressIndex !== null) {
      const updatedAddresses = [...addresses];
      updatedAddresses[editingAddressIndex] = addressValue;
      setAddresses(updatedAddresses);
      setEditingAddressIndex(null);
    } else {
      setAddresses([addressValue, ...addresses]);
      setShowAddAddressInput(false);
    }
    setNewAddress("");
  };

  const handleDeleteAddress = (indexToDelete) => {
    const updatedAddresses = addresses.filter(
      (_, index) => index !== indexToDelete,
    );
    setAddresses(updatedAddresses);

    if (selectedAddress === addresses[indexToDelete]) {
      setSelectedAddress(updatedAddresses[0] || "");
    }
  };

  const handleEditClick = (index, addressText) => {
    setEditingAddressIndex(index);
    setNewAddress(addressText);
    setShowAddAddressInput(false);
  };

  const handleProfileSubmit = (e) => {
    e.preventDefault();
    setIsEditingProfile(false);
  };

  return (
    <div className="h-full flex flex-col animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="flex-1 flex flex-col">
        {/* Fixed Header Background inside Modal */}
        <div className="relative h-36 bg-primary rounded-b-3xl shadow-lg shadow-primary/20 shrink-0 -mb-4">
          <button
            onClick={() => setIsEditingProfile(false)}
            className="absolute top-4 right-4 flex items-center gap-2 text-white cursor-pointer"
          >
            <StrokeArrowLeftIcon size={16} className="rotate-180 text-white" />
            بازگشت
          </button>
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2">
            <label
              htmlFor="modalProfileImage"
              className={`relative w-20 h-20 rounded-lg bg-white overflow-hidden flex items-center justify-center cursor-pointer border-4 border-white shadow-md transition-transform duration-300 active:scale-95`}
            >
              {profileImage ? (
                <Image
                  src={URL.createObjectURL(profileImage)}
                  fill
                  alt="پروفایل"
                  className="object-cover"
                />
              ) : (
                <span className="text-gray-400 text-xs text-center px-2">
                  انتخاب عکس
                </span>
              )}
            </label>
            <input
              type="file"
              id="modalProfileImage"
              name="modalProfileImage"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
          </div>
        </div>

        {/* Scrollable Form Area */}
        <div className="flex flex-col justify-between flex-1 bg-white rounded-t-2xl lg:rounded-t-3xl shadow-[0_-5px_25px_rgba(0,0,0,0.08)] py-4 px-4 lg:px-8 flex flex-col gap-4 z-10">
          <div className="space-y-4">
            {/* Inputs Grid Mobile */}
            <div className="grid grid-cols-1 gap-4 mt-2">
              <div className="flex flex-col gap-1.5">
                <label
                  htmlFor="m_fullName"
                  className="text-xs font-bold text-gray-500"
                >
                  نام و نام خانوادگی
                </label>
                <input
                  type="text"
                  id="m_fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.value)}
                  className="w-full h-11 rounded-md border-2 border-gray-100 bg-white px-4 text-sm outline-none transition-all duration-300 focus:border-primary focus:ring-4 focus:ring-primary/5"
                  placeholder="نام خود را وارد کنید"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label
                  htmlFor="m_phone"
                  className="text-xs font-bold text-gray-500"
                >
                  تلفن همراه
                </label>
                <input
                  type="tel"
                  id="m_phone"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full h-11 rounded-md border-2 border-gray-100 bg-white px-4 text-sm outline-none transition-all duration-300 focus:border-primary focus:ring-4 focus:ring-primary/5"
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label
                  htmlFor="m_postalCode"
                  className="text-xs font-bold text-gray-500"
                >
                  کد پستی
                </label>
                <input
                  type="text"
                  id="m_postalCode"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  className="w-full h-11 rounded-md border-2 border-gray-100 bg-white px-4 text-sm outline-none transition-all duration-300 focus:border-primary focus:ring-4 focus:ring-primary/5"
                  placeholder="کد پستی"
                />
              </div>
            </div>

            {/* Address Section Mobile */}
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-800 flex items-center gap-2">
                  <span className="w-1 h-4 bg-primary rounded-full"></span>
                  آدرس‌ها
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddAddressInput(true);
                    setEditingAddressIndex(null); // ریست کردن حالت ویرایش هنگام افزودن جدید
                    setNewAddress("");
                  }}
                  className="flex items-center gap-1 text-primary text-xs font-bold bg-primary/5 px-2 py-1 rounded-md"
                >
                  <PlusIcon size={12} />
                  افزودن آدرس جدید
                </button>
              </div>

              {/* Input for Adding New Address */}
              {showAddAddressInput && (
                <div className="flex gap-2 items-center bg-gray-50 p-2 rounded-xl border border-primary/20">
                  <input
                    type="text"
                    placeholder="آدرس جدید..."
                    value={newAddress}
                    onChange={(e) => setNewAddress(e.target.value)}
                    className="flex-1 h-10 bg-transparent border-none outline-none px-3 text-sm"
                  />
                  <button
                    onClick={handleSaveAddress}
                    className="bg-primary text-white px-4 h-9 rounded-lg text-xs font-bold shadow-md shadow-primary/20"
                  >
                    ثبت
                  </button>
                </div>
              )}

              {/* Address List */}
              <div className="flex flex-col gap-2">
                {addresses.map((address, index) => (
                  <div
                    key={index}
                    className={`flex items-start gap-3 p-3 rounded-xl border-2 transition-all duration-300 ${
                      selectedAddress === address
                        ? "border-primary bg-primary/5"
                        : "border-gray-100 bg-white hover:border-gray-200"
                    }`}
                  >
                    {/* Radio Button */}
                    <div
                      className="mt-0.5"
                      onClick={() => setSelectedAddress(address)}
                    >
                      <Radio
                        checked={selectedAddress === address}
                        onChange={() => setSelectedAddress(address)}
                      />
                    </div>

                    {/* Address Content or Edit Input */}
                    <div className="flex-1 flex flex-col justify-center">
                      {editingAddressIndex === index ? (
                        <div className="flex gap-2 items-center w-full">
                          <input
                            type="text"
                            value={newAddress}
                            onChange={(e) => setNewAddress(e.target.value)}
                            className="flex-1 h-9 rounded-md border-2 border-primary/30 bg-white px-3 text-sm outline-none focus:border-primary"
                            autoFocus
                          />
                          <button
                            onClick={handleSaveAddress}
                            className="bg-green-600 text-white p-2 rounded-lg shadow-sm hover:bg-success-medium transition-colors"
                            title="ذخیره"
                          >
                            <Check size={16} />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between w-full group">
                          <span
                            className="text-xs text-gray-600 leading-6 cursor-pointer"
                            onClick={() => setSelectedAddress(address)}
                          >
                            {address}
                          </span>

                          {/* Action Buttons (Edit & Delete) */}
                          <div className="flex items-center gap-2 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => handleEditClick(index, address)}
                              className="p-1.5 text-primary hover:bg-blue-50 rounded-md transition-colors"
                              title="ویرایش"
                            >
                              <Edit size={16} />
                            </button>
                            <button
                              onClick={() => handleDeleteAddress(index)}
                              className="p-1.5 text-error-medium hover:bg-red-50 rounded-md transition-colors"
                              title="حذف"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Buttons Mobile */}
          <div className="pt-4">
            <button
              onClick={handleProfileSubmit}
              className="w-full bg-primary text-white h-12 rounded-xl font-bold transition-all duration-300 cursor-pointer"
            >
              ذخیره تغییرات
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileEditInfo;
