"use client";

import { Radio } from "@/components/ui/radio";
import { PlusIcon } from "@/icons";
import Image from "next/image";
import React, { useState } from "react";

const ProfileEditInfo = () => {
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [profileImage, setProfileImage] = useState(null);

  // State های مربوط به آدرس
  const [addresses, setAddresses] = useState([
    "تهران، خیابان ولیعصر، کوچه سوم، پلاک ۱۲۳",
    "اصفهان، خیابان چهارباغ، نبش خیابان شعا، پلاک ۴۵",
  ]);
  const [selectedAddress, setSelectedAddress] = useState(addresses[0] || "");
  const [showAddAddressInput, setShowAddAddressInput] = useState(false);
  const [newAddress, setNewAddress] = useState("");

  // Handle image upload
  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setProfileImage(e.target.files[0]);
    }
  };

  // Handle new address submit
  const handleAddNewAddress = (e) => {
    e.preventDefault();
    if (newAddress.trim()) {
      const newAddressList = [newAddress.trim(), ...addresses];
      setAddresses(newAddressList);
      // setSelectedAddress(newAddress.trim());
      setNewAddress("");
      setShowAddAddressInput(false);
    }
  };

  const handleClearFields = () => {
    setProfileImage(null);
    setFullName("");
    setPhoneNumber("");
    setPostalCode("");
    setAddresses([]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="bg-gray-200 lg:py-10 lg:px-[100px] h-screen">
      <div className="lg:bg-white lg:shadow-md lg:rounded-lg py-4 lg:py-6 px-[10px] lg:px-4 h-full overflow-y-auto">
        <div className="flex items-start justify-between">
          {/* Title */}
          <h1 className="text-lg lg:text-xl font-bold text-primary mb-4">
            ویرایش مشخصات
          </h1>

          {/* Upload image */}
          <div className="flex items-end gap-[10px]">
            <label
              htmlFor="profileImage"
              className={`relative w-24 h-24 rounded-lg bg-gray-200 overflow-hidden flex items-center justify-center cursor-pointer border-2 border-primary ${profileImage ? "" : "border-dashed"}`}
            >
              {profileImage ? (
                <Image
                  src={URL.createObjectURL(profileImage)}
                  fill
                  alt="پروفایل"
                  objectFit="contain"
                />
              ) : (
                <span className="text-primary text-center text-xs">
                  عکس خود را انتخاب نمایید
                </span>
              )}
            </label>
            <input
              type="file"
              id="profileImage"
              name="profileImage"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-[10px]">
            {/* Full name */}
            <div className="flex flex-col flex-1 gap-1">
              <label htmlFor="fullName" className="lg:text-lg">
                نام و نام خانوادگی
              </label>
              <input
                type="text"
                name="fullName"
                id="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="outline-none border-2 border-gray-300 h-12 rounded-md px-2"
              />
            </div>

            {/* Phone number */}
            <div className="flex flex-col flex-1 gap-1">
              <label htmlFor="phone" className="lg:text-lg">
                تلفن همراه
              </label>
              <input
                type="number"
                name="phone"
                id="phone"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="outline-none border-2 border-gray-300 h-12 rounded-md px-2"
              />
            </div>

            {/* Postal code */}
            <div className="flex flex-col flex-1 gap-1">
              <label htmlFor="postalCode" className="lg:text-lg">
                کد پستی
              </label>
              <input
                type="number"
                name="postalCode"
                id="postalCode"
                value={postalCode}
                onChange={(e) => setPostalCode(e.target.value)}
                className="outline-none border-2 border-gray-300 h-12 rounded-md px-2"
              />
            </div>
          </div>

          {/* Address Section */}
          <div className="flex flex-col gap-4 overflow-hidden">
            <label className="lg:text-lg">آدرس</label>

            {/* Radio buttons for existing addresses */}
            <div className="flex flex-col gap-3">
              {addresses.map((address, index) => (
                <div key={index}>
                  <Radio
                    checked={selectedAddress === address}
                    onChange={(checked) => {
                      if (checked) setSelectedAddress(address);
                    }}
                    label={address}
                    className="mb-3"
                  />
                  <div className="w-full h-[2px] bg-gray-200 mr-8" />
                </div>
              ))}
            </div>

            {/* Add new address button or input */}
            {showAddAddressInput ? (
              <div className="flex flex-col gap-3 px-4  rounded-md">
                <input
                  type="text"
                  placeholder="آدرس جدید خود را وارد کنید..."
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  className="outline-none border-2 border-gray-300 h-12 rounded-md px-4"
                />
                <div className="flex items-center justify-start gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddAddressInput(false);
                      setNewAddress("");
                    }}
                    className="border-2 border-gray-300 text-gray-400 px-6 h-12 rounded-md hover:bg-gray-50 transition-colors font-bold cursor-pointer"
                  >
                    انصراف
                  </button>
                  <button
                    onClick={handleAddNewAddress}
                    className="bg-primary text-white px-6 h-12 rounded-md hover:opacity-90 transition-opacity font-bold cursor-pointer"
                  >
                    ثبت آدرس جدید
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setShowAddAddressInput(true)}
                className="font-bold flex items-center gap-2 text-primary text-sm pr-0.5"
              >
                <PlusIcon size={16} />
                افزودن آدرس جدید
              </button>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-center lg:justify-end gap-[10px] flex-wrap">
            <button
              onClick={handleClearFields}
              className="max-w-[200px] flex-1 border-2 border-primary text-primary px-8 h-12 rounded-md hover:opacity-90 transition-opacity font-bold cursor-pointer"
            >
              پاک کردن
            </button>
            <button
              onClick={handleSubmit}
              className="max-w-[200px] bg-primary flex-1 text-white px-8 h-12 rounded-md hover:opacity-90 transition-opacity font-bold cursor-pointer"
            >
              ذخیره تغییرات
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileEditInfo;
