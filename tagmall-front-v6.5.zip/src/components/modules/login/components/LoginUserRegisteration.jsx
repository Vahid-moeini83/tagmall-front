"use client";

import { isValidIranianNationalCode } from "@/lib/client/validations";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";

function LoginUserRegisteration() {
  const router = useRouter();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [nationalCode, setNationalCode] = useState("");

  const handleConfirm = () => {
    if (!firstName) {
      toast.error("لطفا نام را وارد نمایید");
      return;
    }

    if (!lastName) {
      toast.error("لطفا نام خانوادگی را وارد نمایید");
      return;
    }

    if (!isValidIranianNationalCode(nationalCode)) {
      toast.error("کد ملی وارد شده نامعتبر است");
      return;
    }

    toast.success("ورود با موفقیت انجام شد");
    router.push("/");
  };

  return (
    <div className="h-full flex flex-col justify-between">
      <div>
        {/* Title */}
        <div className="flex flex-col gap-1 lg:gap-2">
          <h1 className="text-xl lg:text-2xl font-bold">تکمیل ثبت‌نام</h1>
          <span className="text-gray-600 text-sm lg:text-base">
            لطفا اطلاعات زیر را وارد نمایید.
          </span>
        </div>
        {/* Main content */}
        <div className="mt-6 lg:mt-8 space-y-4 lg:space-y-8">
          <div className="flex flex-col gap-1">
            <label htmlFor="firstname" className="lg:text-lg">
              نام
            </label>
            <input
              type="text"
              name="firstname"
              id="firstname"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="outline-none border-2 border-gray-300 h-11 lg:h-12 rounded-md px-2"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label htmlFor="lastname" className="lg:text-lg">
              نام خانوادگی
            </label>
            <input
              type="text"
              name="lastname"
              id="lastname"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="outline-none border-2 border-gray-300 h-11 lg:h-12 rounded-md px-2"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label htmlFor="nationalCode" className="lg:text-lg">
              کد ملی
            </label>
            <input
              type="text"
              name="nationalCode"
              id="nationalCode"
              value={nationalCode}
              onChange={(e) => setNationalCode(e.target.value)}
              className="outline-none border-2 border-gray-300 h-11 lg:h-12 rounded-md px-2"
            />
          </div>
        </div>
      </div>
      {/* Submit button */}
      <div className="flex flex-col gap-3 mt-8">
        <span className="font-bold text-xs lg:text-sm text-gray-600">
          ثبت نام به منزله پذیرش قوانین و مقررات تگ‌مال است.
        </span>
        <button
          onClick={handleConfirm}
          className="bg-primary text-white rounded-md w-full h-12 flex items-center justify-center gap-2 transition-all hover:bg-primary/90 hover:gap-3 cursor-pointer"
        >
          تکمیل ثبت‌نام
        </button>
      </div>
    </div>
  );
}

export default LoginUserRegisteration;
