"use client";

import { useState } from "react";
import { LoginEnterPhone, LoginOtp, LoginUserRegisteration } from "..";
import Image from "next/image";
import { ArrowRightIcon, HintIcon } from "@/icons";

function LoginContent() {
  const [currentStep, setCurrentStep] = useState(1);

  const handleNextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <>
      {/* Desktop layout */}
      <div className="hidden lg:block bg-gray-100 h-screen py-10 px-12 xl:px-50">
        {/* Main wrapper */}
        <div className="rounded-lg overflow-hidden h-full shadow-lg flex">
          {/* Content */}
          <div className="bg-white w-1/2 py-16 px-16">
            {currentStep === 1 && (
              <LoginEnterPhone handleNextStep={handleNextStep} />
            )}
            {currentStep === 2 && (
              <LoginOtp
                handleNextStep={handleNextStep}
                handlePreviousStep={handlePreviousStep}
              />
            )}
            {currentStep === 3 && <LoginUserRegisteration />}
          </div>
          {/* Background */}
          <div className="bg-primary w-1/2 flex items-center justify-center">
            <Image
              width={200}
              height={80}
              src="/assets/images/logo/white-logo.svg"
              alt="لوگوی تگ‌‌مال"
              className="mx-auto"
            />
          </div>
        </div>
      </div>

      {/* Mobile layout */}
      <div className="lg:hidden h-screen">
        {/* Fixed background */}
        <div className="fixed inset-0 bg-primary"></div>

        {/* Logo */}
        <div className="absolute top-20 left-0 right-0 flex flex-col items-center gap-1">
          <Image
            src="/assets/images/logo/white-logo.svg"
            width={160}
            height={80}
            alt="لوگو تگمال"
          />
        </div>

        {/* Content drawer */}
        <div className="fixed right-0 left-0 bottom-0 h-[70%] overflow-y-auto pt-8 pb-4 px-6 bg-white rounded-t-xl">
          {currentStep === 1 && (
            <LoginEnterPhone handleNextStep={handleNextStep} />
          )}
          {currentStep === 2 && (
            <LoginOtp
              handleNextStep={handleNextStep}
              handlePreviousStep={handlePreviousStep}
            />
          )}
          {currentStep === 3 && <LoginUserRegisteration />}
        </div>
      </div>
    </>
  );
}

export default LoginContent;
