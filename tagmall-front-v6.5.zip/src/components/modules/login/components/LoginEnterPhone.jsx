"use client";

import { ArrowRightIcon, HintIcon } from "@/icons";
import { isValidIranianMobile } from "@/lib/client/validations";
import { useState } from "react";
import toast from "react-hot-toast";

function LoginEnterPhone({ handleNextStep }) {
  const [phoneNumber, setPhoneNumber] = useState("");

  const handleConfirm = () => {
    if (isValidIranianMobile(phoneNumber)) {
      handleNextStep();
    } else {
      toast.error("شماره وارد شده معتبر نمی‌باشد");
    }
  };

  return (
    <div className="h-full flex flex-col justify-between">
      <div>
        {/* Title */}
        <div className="flex flex-col lg:gap-2">
          <h1 className="text-xl lg:text-2xl font-bold">ورود یا ثبت‌نام</h1>
          <span className="text-gray-600 text-sm lg:text-base">
            لطفا شماره موبایل خود را وارد نمایید.
          </span>
        </div>
        {/* Main content */}
        <div className="mt-10">
          <div className="flex flex-col gap-1">
            <label htmlFor="phone" className="lg:text-lg">
              شماره موبایل
            </label>
            <input
              type="text"
              name="phone"
              id="phone"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="outline-none border-2 border-gray-300 h-12 rounded-md px-2"
            />
          </div>
          <div className="flex items-center gap-2 mt-4">
            <HintIcon size={16} className="text-gray-600" />
            <span className="font-bold text-xs lg:text-sm text-gray-600">
              شماره موبایل باید به نام شما باشد.
            </span>
          </div>
        </div>
      </div>
      {/* Submit button */}
      <button
        onClick={handleConfirm}
        className="mt-28 bg-primary text-white rounded-md w-full h-12 flex items-center justify-center gap-2 transition-all hover:bg-primary/90 hover:gap-3 cursor-pointer"
      >
        تایید و ادامه
        <ArrowRightIcon size={20} className="rotate-180" />
      </button>
    </div>
  );
}

export default LoginEnterPhone;
