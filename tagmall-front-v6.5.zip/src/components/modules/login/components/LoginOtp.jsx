"use client";
import React, { useState, useRef, useEffect } from "react";
import { HintIcon } from "@/icons";
import toast from "react-hot-toast";
import { formatTime } from "@/lib/client/utils";

const SAMPLE_OTP = "12345";

function LoginOtp({ handleNextStep, handlePreviousStep }) {
  const [otp, setOtp] = useState("");
  const [timeLeft, setTimeLeft] = useState(10);
  const [isResendActive, setIsResendActive] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    if (timeLeft <= 0) {
      setIsResendActive(true);
      return;
    }
    const timerId = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timerId);
  }, [timeLeft]);

  const handleResend = () => {
    if (isResendActive) {
      toast.success("کد تایید مجدداً ارسال شد");
      setTimeLeft(10);
      setIsResendActive(false);
    }
  };

  // OTP check
  const handleCheckOtp = (e) => {
    const value = e.target.value;
    if (/^\d*$/.test(value) && value.length <= 5) {
      setOtp(value);
    }
  };

  // Handle focus on fake box
  const handleContainerClick = () => {
    inputRef.current?.focus();
  };

  // Confirm OTP
  useEffect(() => {
    if (otp.length === 5) {
      if (otp === SAMPLE_OTP) {
        handleNextStep();
      } else {
        toast.error("کد تایید اشتباه است");
        setOtp("");
      }
    }
  }, [otp]);

  return (
    <div className="h-full flex flex-col justify-between">
      <div>
        {/* Title */}
        <div className="flex flex-col gap-1 lg:gap-2">
          <h1 className="text-xl lg:text-2xl font-bold">کد تایید</h1>
          <span className="text-gray-600 text-sm lg:text-base">
            لطفا کد تایید ارسال شده را وارد نمایید.
          </span>
        </div>
        {/* Main content */}
        <div className="mt-10 flex-1">
          <div className="flex flex-col gap-2">
            <label htmlFor="otp" className="lg:text-lg">
              کد تایید
            </label>
            {/* Here is OTP input ... */}
            <div
              onClick={handleContainerClick}
              className="relative w-full h-12 rounded-md border-2 border-gray-300 flex items-center justify-center cursor-text transition-colors hover:border-gray-400 focus-within:border-primary"
            >
              {/* Hidden input */}
              <input
                ref={inputRef}
                id="otp"
                type="text"
                inputMode="numeric"
                pattern="\d*"
                value={otp}
                onChange={handleCheckOtp}
                maxLength={5}
                className="absolute opacity-0 w-full h-full cursor-text"
                autoComplete="one-time-code"
                autoFocus
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
              />
              {/* Numbers & lines */}
              <div dir="ltr" className="flex items-center gap-2">
                {[0, 1, 2, 3, 4].map((index) => (
                  <div
                    key={index}
                    className="flex flex-col items-center justify-center w-8"
                  >
                    {/* Numbers */}
                    <span className="text-xl font-medium h-6">
                      {otp[index] ? otp[index] : ""}
                    </span>
                    {/* Active cursor */}
                    {isFocused && otp.length === index && (
                      <div
                        className={`absolute bottom-3.5 w-[2px] h-4 bg-gray-800 animate-bounce`}
                      />
                    )}
                    {/* lines */}
                    <div
                      className={`w-4 h-0.5 rounded-full transition-colors duration-200 ${
                        otp[index] ? "bg-primary" : "bg-gray-300"
                      }`}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between gap-2 mt-4">
            <span className="text-gray-600 text-sm" dir="ltr">
              0915 842 7785
            </span>
            <span
              onClick={handlePreviousStep}
              className="flex items-center gap-2 text-xs lg:text-sm text-primary cursor-pointer"
            >
              <HintIcon size={16} className="text-primary" />
              ویرایش شماره موبایل
            </span>
          </div>
        </div>
      </div>
      {/* Resend code */}
      <button
        onClick={handleResend}
        disabled={!isResendActive}
        className={`w-full h-12 rounded-md transition-all duration-300 ${
          isResendActive
            ? "bg-primary text-white cursor-pointer hover:bg-opacity-90"
            : "bg-gray-200 text-gray-500 cursor-not-allowed"
        }`}
      >
        {isResendActive ? (
          "ارسال مجدد کد تایید"
        ) : (
          <span dir="ltr">{formatTime(timeLeft)} تا ارسال مجدد کد</span>
        )}
      </button>
    </div>
  );
}

export default LoginOtp;
