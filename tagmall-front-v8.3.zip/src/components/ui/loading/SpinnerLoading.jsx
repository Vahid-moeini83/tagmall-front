function SpinnerLoading({ className, size = 6, ...props }) {
  return (
    <div
      className={`w-${size} h-${size} border-2 border-white border-t-transparent rounded-full animate-spin ${className}`}
    />
  );
}

export default SpinnerLoading;
