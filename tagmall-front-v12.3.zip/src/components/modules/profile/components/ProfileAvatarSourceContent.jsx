"use client";

import Image from "next/image";
import { StrokeArrowLeftIcon, UserIcon } from "@/icons";

function ProfileAvatarSourceContent({
  user,
  isUpdating,
  onBack,
  onCamera,
  onGallery,
  onRemove,
}) {
  const hasImage = Boolean(user?.avatar);

  return (
    <div className="">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className={`relative w-[50px] h-[50px] rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center ${hasImage ? "bg-white" : "bg-gray-200"}`}
          >
            {user?.avatar ? (
              <Image
                src={user.avatar}
                fill
                alt="avatar"
                className="object-cover"
              />
            ) : (
              <UserIcon />
            )}
          </div>

          <h1 className="text-gray-600 text-base">
            {user?.name} {user?.family}
          </h1>
        </div>

        <StrokeArrowLeftIcon
          onClick={isUpdating ? undefined : onBack}
          className={`ml-4 ${isUpdating ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
        />
      </div>

      <div className="">
        <div
          className={`text-center text-base py-4 ${
            isUpdating
              ? "text-gray-400 cursor-not-allowed"
              : "text-primary cursor-pointer"
          }`}
          onClick={isUpdating ? null : onCamera}
        >
          تصویر گرفتن با گوشی موبایل
        </div>

        <div className="w-full h-[2px] bg-gray-200" />

        <div
          className={`text-center text-base py-4 ${
            isUpdating
              ? "text-gray-400 cursor-not-allowed"
              : "text-primary cursor-pointer"
          }`}
          onClick={isUpdating ? null : onGallery}
        >
          انتخاب تصویر از گالری
        </div>

        {user?.avatar && (
          <>
            <div className="w-full h-[2px] bg-gray-200" />

            <div
              className={`text-center text-base py-4 ${
                isUpdating
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-error-medium cursor-pointer"
              }`}
              onClick={isUpdating ? null : onRemove}
            >
              حذف تصویر حساب کاربری
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default ProfileAvatarSourceContent;
