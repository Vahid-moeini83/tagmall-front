"use client";

import { useMediaQuery } from "@/hooks/useMediaQuery";
import {
  CloseSquareIcon,
  HintIcon,
  MoreSquareIcon,
  StrokeArrowLeftIcon,
  SupportIcon,
  UserIcon,
} from "@/icons";
import { ReplyIcon, ScanLineIcon, Trash2Icon } from "lucide-react";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import MessageContextMenu from "@/components/ui/MessageContextMenu";

const recommendedMessages = [
  {
    id: 1,
    messgae: "زمان تحویل سفارش من حدودا چه قدر است؟",
  },
  {
    id: 2,
    messgae: "چگونه میتوانم سفارشی را بازگردانده یا مرجوع کنم؟",
  },
  {
    id: 3,
    messgae: "شرایط بازگردانی یا مرجوع کردن سفارش چگونه است؟",
  },
];

function SupportSingleChat({ isOpen, setIsOpen }) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const [messages, setMessages] = useState([
    // پنج روز پیش
    {
      id: 7,
      text: "یک سوال درباره محصول داشتم.",
      sender: "user",
      date: new Date("2026-04-11T16:30:00"),
    },
    {
      id: 8,
      text: "بفرمایید در خدمتم.",
      sender: "support",
      date: new Date("2026-04-11T16:32:00"),
    },

    // سه روز پیش
    {
      id: 5,
      text: "سلام پشتیبانی چی شد؟",
      sender: "user",
      date: new Date("2026-04-13T09:40:00"),
    },
    {
      id: 6,
      text: "پاسخ داده شد، ببینید لطفاً.",
      sender: "support",
      date: new Date("2026-04-13T09:45:00"),
    },

    // دیروز
    {
      id: 3,
      text: "ببخشید، میشه آدرس ارسال رو تغییر بدم؟",
      sender: "user",
      date: new Date("2026-04-15T14:22:00"),
    },
    {
      id: 4,
      text: "بله، لطفاً آدرس جدید را ارسال کنید.",
      sender: "support",
      date: new Date("2026-04-15T14:24:00"),
    },

    {
      id: 1,
      text: "سلام، سفارش من کی ارسال میشه؟",
      sender: "user",
      date: new Date("2026-04-16T10:15:00"),
    },
    {
      id: 2,
      text: "سفارش شما امروز بعدازظهر ارسال می‌شود.",
      sender: "support",
      date: new Date("2026-04-16T10:17:00"),
    },
  ]);

  const [message, setMessage] = useState("");
  const [showRecommended, setShowRecommended] = useState(true);
  const [replyTo, setReplyTo] = useState(null);
  const [visibleDate, setVisibleDate] = useState("");
  const [showSticky, setShowSticky] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  const [contextMenuOpen, setContextMenuOpen] = useState(false);
  const [activeMessageId, setActiveMessageId] = useState(null);
  const [activeTriggerElement, setActiveTriggerElement] = useState(null);

  const stickyTimeoutRef = useRef(null);
  const lastMessageRef = useRef(null);
  const messageRefs = useRef({});
  const chatContainerRef = useRef(null);
  const fileInputRef = useRef(null);
  const menuRef = useRef(null);
  const triggerRefs = useRef({});

  const handleSendMessage = (message) => {
    if (!message.trim()) return;

    const newMessage = {
      id: messages.length + 1,
      text: message,
      sender: "user",
      date: new Date(),
      replyTo: replyTo ? { id: replyTo.id, text: replyTo.text } : null,
    };

    setMessages((prev) => [...prev, newMessage]);
    setMessage("");
    setReplyTo(null);
    setShowRecommended(false);
  };

  const isLastOfGroup = (messages, index) => {
    const current = messages[index];
    const next = messages[index + 1];
    return !next || next.sender !== current.sender;
  };

  const isSameSenderAsPrev = (messages, index) => {
    if (index === 0) return false;
    return messages[index].sender === messages[index - 1].sender;
  };

  const scrollToMessage = (id) => {
    const element = messageRefs.current[id];
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  const formatDateLabel = (dateString) => {
    const today = new Date();
    const messageDate = new Date(dateString);

    const diffTime =
      today.setHours(0, 0, 0, 0) - new Date(messageDate).setHours(0, 0, 0, 0);
    const diffDays = diffTime / (1000 * 60 * 60 * 24);

    if (diffDays === 0) return "امروز";
    if (diffDays === 1) return "دیروز";

    return messageDate.toLocaleDateString("fa-IR", {
      day: "numeric",
      month: "long",
    });
  };

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const imageUrl = URL.createObjectURL(file);

    const newMessage = {
      id: messages.length + 1,
      type: "image",
      image: imageUrl,
      sender: "user",
      date: new Date(),
    };

    setMessages((prev) => [...prev, newMessage]);
    setShowRecommended(false);

    e.target.value = "";
  };

  const handleOpenMenu = (e, msg) => {
    e.preventDefault();
    e.stopPropagation();

    // اگر منو باز است و روی همان پیام کلیک شد، منو را ببند
    if (contextMenuOpen && activeMessageId === msg.id) {
      handleCloseMenu();
      return;
    }

    setContextMenuOpen(true);
    setActiveMessageId(msg.id);
    setActiveTriggerElement(triggerRefs.current[msg.id]);
  };

  const handleCloseMenu = () => {
    setContextMenuOpen(false);
    setActiveMessageId(null);
    setActiveTriggerElement(null);
  };

  // بستن منو با کلیک خارج از آن
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        contextMenuOpen &&
        menuRef.current &&
        !menuRef.current.contains(e.target)
      ) {
        handleCloseMenu();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [contextMenuOpen]);

  const lastUserMessageId = messages
    .filter((m) => m.sender === "user")
    .at(-1)?.id;

  useEffect(() => {
    lastMessageRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // For date scroll & auto-hide
  useEffect(() => {
    const handleScroll = () => {
      const container = chatContainerRef.current;
      if (!container) return;

      // پیدا کردن تاریخ‌های یونیک
      const uniqueDates = [];
      const seenDates = new Set();

      messages.forEach((msg) => {
        const dateLabel = formatDateLabel(msg.date);
        if (!seenDates.has(dateLabel)) {
          seenDates.add(dateLabel);
          uniqueDates.push({ date: dateLabel, id: msg.id });
        }
      });

      // پیدا کردن آخرین تاریخی که از بالای viewport رد شده
      let currentVisibleDate = null;
      let hasPassedAnyDate = false;

      for (let i = 0; i < uniqueDates.length; i++) {
        const msgElement = messageRefs.current[uniqueDates[i].id];
        if (msgElement) {
          const rect = msgElement.getBoundingClientRect();
          const containerRect = container.getBoundingClientRect();
          const threshold = window.innerWidth >= 1024 ? 152 : 52;

          // اگر پیام از بالای container رد شده باشه
          if (rect.top <= containerRect.top + threshold) {
            currentVisibleDate = uniqueDates[i].date;
            hasPassedAnyDate = true;
          } else {
            break;
          }
        }
      }

      // اگر از هیچ تاریخی رد نشده، sticky رو مخفی کن
      if (!hasPassedAnyDate) {
        setShowSticky(false);
        return;
      }

      setShowSticky(true);
      setVisibleDate(currentVisibleDate);

      if (stickyTimeoutRef.current) {
        clearTimeout(stickyTimeoutRef.current);
      }

      stickyTimeoutRef.current = setTimeout(() => {
        setShowSticky(false);
      }, 1000);
    };

    const container = chatContainerRef.current;
    container?.addEventListener("scroll", handleScroll);

    handleScroll();

    return () => {
      container?.removeEventListener("scroll", handleScroll);
      if (stickyTimeoutRef.current) clearTimeout(stickyTimeoutRef.current);
    };
  }, [messages]);

  return (
    <div className="pt-2 lg:pt-0 lg:px-[140px] flex flex-col h-full select-none overflow-hidden">
      {/* Context menu overlay */}
      {contextMenuOpen && (
        <div
          className="fixed inset-0 bg-gray-200/20 backdrop-blur-sm z-998"
          onClick={handleCloseMenu}
        />
      )}

      {previewImage && (
        <div
          className="fixed inset-0 bg-gray-200/20 backdrop-blur-sm z-9999 flex items-center justify-center"
          onClick={() => setPreviewImage(null)}
        >
          <div className="relative w-[90%] h-[50%] rounded-lg overflow-hidden">
            <Image
              src={previewImage}
              alt="پیش نمایش"
              fill
              className="shadow-2xl object-contain"
            />
          </div>
        </div>
      )}

      {/* Header */}
      <div className="lg:fixed lg:top-0 lg:right-0 lg:left-0 lg:pt-10 lg:px-[140px] bg-white z-10">
        <div className="flex items-center justify-between border-b-2 border-gray-200 lg:border-0 pb-4 lg:pb-2">
          <div className="flex items-center gap-1">
            <div className="hidden lg:flex items-center justify-center w-10 h-10 rounded-[14px] border-2 border-gray-200">
              <SupportIcon size={20} />
            </div>
            <span className="hidden lg:inline font-iransans font-semibold! text-primary text-lg">
              واحد پشتیبانی
            </span>
            <span className="inline lg:hidden font-iransans font-semibold! text-primary text-lg">
              ارسال پیام به واحد پشتیبانی
            </span>
          </div>
          <span className="hidden lg:block">icon</span>
          <MoreSquareIcon className="block ml-2 lg:hidden" size={20} />
        </div>
      </div>

      {/* Chat content */}
      <div
        ref={chatContainerRef}
        className="lg:pt-24 pb-78 lg:pb-56 overflow-y-auto scroll-hidden flex-1"
      >
        <div
          className={`sticky top-1 z-20 flex justify-center pointer-events-none transition-opacity duration-500 ${
            showSticky ? "opacity-100" : "opacity-0"
          }`}
        >
          {visibleDate && (
            <div className="bg-white/80 backdrop-blur-sm shadow-sm border text-gray-600 text-xs px-4 py-1 rounded-full">
              {visibleDate}
            </div>
          )}
        </div>

        <div className="flex flex-col">
          <div className="flex w-full justify-end">
            <div className="flex items-end gap-2 max-w-[80%] lg:max-w-[40%] flex-row-reverse">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-lg border-2 border-gray-200 flex items-center justify-center">
                  <SupportIcon size={20} />
                </div>
              </div>
              <div className="font-iransans text-justify px-4 py-2 rounded-lg text-xs lg:text-sm leading-10 w-full wrap-break-word text-gray-800 border-2 border-gray-200 rounded-bl-none">
                سلام با افتخار به شما خوش آمد میگویم. در سامانه پشتیبانی، تمرکز
                ما ایجاد تجربه ای بی نظیر برای شماست؛ شما میتوانید از این قسمت
                با ما در تعامل باشید و سوالات خود را مطرح کنید و اطلاعات بیشتری
                در رابطه با محصولات و خدمات مختلف بدست آورید.
              </div>
            </div>
          </div>
          {messages.map((msg, index) => {
            const currentDateLabel = formatDateLabel(msg.date);
            const prevDateLabel =
              index > 0 ? formatDateLabel(messages[index - 1].date) : null;

            const showDateSeparator = currentDateLabel !== prevDateLabel;
            const last = isLastOfGroup(messages, index);

            const bubbleClasses = `
    font-iransans text-justify overflow-hidden rounded-lg text-xs lg:text-sm text-gray-800 
    w-fit cursor-context-menu
    ${
      msg.sender === "user"
        ? last
          ? "border-2 border-gray-400 rounded-br-none"
          : "border-2 border-gray-400 "
        : last
          ? "border-2 border-gray-200 rounded-bl-none"
          : "border-2 border-gray-200"
    }
  `;

            return (
              <div key={msg.id}>
                {showDateSeparator && (
                  <div className="flex justify-center my-6">
                    <div className="bg-gray-200 text-gray-600 text-xs px-4 py-1 rounded-full">
                      {currentDateLabel}
                    </div>
                  </div>
                )}
                <div
                  data-id={msg.id}
                  ref={(el) => (messageRefs.current[msg.id] = el)}
                  className={`flex flex-col w-full ${
                    msg.sender === "user" ? "items-start" : "items-end"
                  } ${isSameSenderAsPrev(messages, index) ? "mt-1" : "mt-6 lg:mt-4"}`}
                >
                  <div
                    className={`${msg.sender === "user" ? "flex-row" : "flex-row-reverse"} flex gap-2 max-w-[80%] lg:max-w-[40%] ${!last ? (msg.sender === "user" ? "mr-[50px]" : "ml-[50px]") : ""} ${contextMenuOpen && activeMessageId === msg.id ? "relative z-999" : ""}`}
                  >
                    {last && (
                      <div
                        className={`flex items-end ${msg.id === lastUserMessageId ? "pb-[18px]" : ""}`}
                      >
                        <div className="w-10 h-10 rounded-lg border-2 border-gray-200 flex items-center justify-center">
                          {msg.sender === "support" ? (
                            <SupportIcon size={20} />
                          ) : (
                            <UserIcon size={20} />
                          )}
                        </div>
                      </div>
                    )}

                    <div className="flex flex-col gap-1">
                      <div
                        ref={(el) => (triggerRefs.current[msg.id] = el)}
                        className={`relative flex items-center gap-2 ${msg.sender === "user" ? "flex-row" : "flex-row-reverse"} ${contextMenuOpen && activeMessageId === msg.id ? "z-999" : ""}`}
                        onClick={(e) => handleOpenMenu(e, msg)}
                        onContextMenu={(e) => handleOpenMenu(e, msg)}
                      >
                        <div className={bubbleClasses} data-bubble>
                          {msg.replyTo && (
                            <div
                              onClick={(e) => {
                                e.stopPropagation();
                                scrollToMessage(msg.replyTo.id);
                              }}
                              className="font-iransans border-r-4 border-gray-600 bg-gray-100 mt-1 mx-1.5 pr-2 pl-1 py-2.5 rounded-md text-xs text-gray-600 overflow-hidden text-ellipsis whitespace-nowrap"
                            >
                              {msg.replyTo.text}
                            </div>
                          )}
                          {msg.type === "image" ? (
                            <Image
                              src={msg.image}
                              alt="عکس"
                              width={120}
                              height={64}
                              onClick={(e) => {
                                e.stopPropagation();
                                setPreviewImage(msg.image);
                              }}
                              className={`object-cover rounded-md ${last ? (msg.sender === "user" ? "rounded-br-none" : "rounded-bl-none") : ""}`}
                            />
                          ) : (
                            <p className="font-iransans px-4 leading-10 text-justify wrap-break-word">
                              {msg.text}
                            </p>
                          )}
                        </div>
                        <span className="font-iransans text-gray-400 text-sm">
                          {msg.date.toLocaleTimeString("fa-IR", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>

                        {/* Custom Context Menu */}
                        {contextMenuOpen &&
                          activeMessageId === msg.id &&
                          activeTriggerElement && (
                            <MessageContextMenu
                              isOpen={true}
                              onReply={() => setReplyTo(msg)}
                              onDelete={() => console.log("Delete:", msg.id)}
                              onReport={() => console.log("Report:", msg.id)}
                              onClose={handleCloseMenu}
                              position={
                                msg.sender === "user" ? "right" : "left"
                              }
                              triggerRef={{ current: activeTriggerElement }}
                            />
                          )}
                      </div>

                      {msg.id === lastUserMessageId && (
                        <div className="w-full flex flex-col gap-1">
                          <p className="text-gray-400 text-xs lg:text-sm">
                            1 ساعت پیش خوانده شد
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div ref={lastMessageRef} />
      </div>

      {/* Chat box */}
      <div className="fixed right-0 left-0 bottom-0 flex items-end gap-4 lg:items-center lg:justify-center px-[10px] lg:px-[140px] pt-2 lg:pt-4 pb-6 lg:pb-12 bg-white">
        <div className="flex items-end gap-1 flex-1">
          <div className="flex flex-col gap-3 flex-1">
            {showRecommended && (
              <div className="space-y-5">
                {recommendedMessages.map((item) => (
                  <p
                    key={item.id}
                    onClick={() => handleSendMessage(item.messgae)}
                    className="font-iransans font-semibold text-primary text-center cursor-pointer text-xs lg:text-sm"
                  >
                    {item.messgae}
                  </p>
                ))}
              </div>
            )}
            <div className="flex items-center justify-center gap-4 lg:gap-1">
              <StrokeArrowLeftIcon
                size={24}
                onClick={() => setIsOpen(false)}
                className="hidden lg:inline absolute bottom-16 right-16 rotate-180 cursor-pointer"
              />

              <div
                className={`relative rounded-t-md rounded-bl-md bg-gray-200 overflow-hidden w-full max-w-[540px] ${contextMenuOpen ? "z-999" : ""}`}
              >
                {replyTo && (
                  <div
                    onClick={() => scrollToMessage(replyTo.id)}
                    className="bg-white border-r-4 border-gray-600 py-2.5 pl-1 pr-2 rounded-md mx-2 mt-1 flex items-center justify-between"
                  >
                    <span className="font-iransans text-gray-600 text-xs max-w-[80%] whitespace-nowrap overflow-hidden text-ellipsis">
                      {replyTo.text}
                    </span>

                    <button onClick={() => setReplyTo(null)}>
                      <CloseSquareIcon size={20} />
                    </button>
                  </div>
                )}
                <input
                  type="text"
                  placeholder="پیام ..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="font-iransans placeholder:text-gray-400 text-gray-600 h-14 lg:h-12 pr-2 pl-14 w-full outline-none select-all"
                />
                {message.length === 0 && (
                  <>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className={`absolute left-2 ${replyTo ? "bottom-4" : "bottom-1/2 translate-y-1/2"} cursor-pointer text-gray-500`}
                    >
                      <ScanLineIcon className="text-gray-800" />
                    </button>
                  </>
                )}
                {message.trim().length > 0 && (
                  <button
                    onClick={() => handleSendMessage(message)}
                    className={`absolute left-2 ${replyTo ? "bottom-4" : "bottom-1/2 translate-y-1/2"} font-iransans text-primary cursor-pointer`}
                  >
                    ارسال
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SupportSingleChat;
