"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  DownloadIcon,
  CopyIcon,
  HintIcon,
  FullScreenIcon,
  SmallScreenIcon,
} from "@/icons";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { PartnershipHintDialog } from "@/components/ui/dialog";

export default function ProductPartnership() {
  const [showLink, setShowLink] = useState(false);
  const [isHintBoxOpen, setIsHintBoxOpen] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const affiliateLink = "tagmall.ir/tagmallaffliate/contract01";

  return (
    <div className="bg-gray-200 lg:bg-white lg:rounded-lg pb-30 lg:py-[50px] lg:px-[100px]">
      <Accordion type="single" collapsible defaultValue="partnership">
        <AccordionItem value="partnership">
          <AccordionTrigger className="hidden lg:flex text-primary text-[16px] lg:text-[20px] font-semibold hover:no-underline justify-between">
            مشارکت در فروش
          </AccordionTrigger>
          <AccordionContent className="lg:mt-4 px-[10px] lg:px-0">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Image Section */}
              <div className="w-full lg:w-1/2">
                <div className="relative w-full h-[460px]">
                  <Image
                    src="/assets/images/fallback/phone.png"
                    fill
                    alt="Partnership"
                    className="object-contain"
                  />
                </div>
                <div className="lg:hidden flex items-center justify-end pl-2 mt-3">
                  <FullScreenIcon
                    size={20}
                    className="cursor-pointer ml-0.5"
                    onClick={() => setIsFullScreen(true)}
                  />
                </div>
              </div>

              {/* Content */}
              <div className="w-full lg:w-1/2 flex flex-col">
                {/* Texts */}
                <div className="hidden lg:block space-y-0 mb-6">
                  <div className="mb-2! lg:mb-3!">
                    <p className="text-gray-600 text-justify text-xs/6 lg:text-base/12">
                      با به اشتراک گذاری لینک فروش محصولات ، یک درصد از فروش هر
                      کالا را بهره مند شوید .
                    </p>
                  </div>

                  <div className="mb-2! lg:mb-3!">
                    <p className="text-gray-600 text-justify text-xs/6 lg:text-base/12">
                      لینک مشارکت در فروش هر کالا برای شما اختصاصی می باشد .
                    </p>
                  </div>

                  <div className="mb-2! lg:mb-3!">
                    <p className="text-gray-600 text-justify text-xs/6 lg:text-base/12 font-bold">
                      بررسی بازدهی لینک های به اشتراک گذاشته شده :
                    </p>
                    <p className="text-gray-600 text-justify text-xs/6 lg:text-base/12">
                      با بررسی بازدهی لینک های به اشتراک گذاشته شده ؛ عملکرد
                      بهتر و سود بیش ترکسب کنید .
                    </p>
                  </div>

                  <div className="mb-2! lg:mb-3!">
                    <p className="text-gray-600 text-justify text-xs/6 lg:text-base/12 font-bold">
                      محاسبه و پرداخت سود مشارکت در فروش :
                    </p>
                    <p className="text-gray-600 text-justify text-xs/6 lg:text-base/12">
                      با توجه به امکان مرجوع شدن کالا توسط خریدار سود مشارکت در
                      فروش پس ازپایان{" "}
                      <Link href="#" className="text-primary">
                        فرصت مرجوع شدن کالا
                      </Link>{" "}
                      به حساب شما واریز می شود .
                    </p>
                  </div>
                </div>

                {/* Button or Link Box */}
                <div className="bg-white rounded-lg p-[10px]">
                  <div className="flex lg:hidden items-center justify-between">
                    <span className="text-primary font-bold">
                      مشارکت در فروش
                    </span>
                    <HintIcon
                      size={20}
                      onClick={() => setIsHintBoxOpen(true)}
                    />
                  </div>
                  <div className="block lg:hidden mt-5 space-y-2">
                    <div className="text-gray-600 text-xs">
                      <span className="font-bold">گوشی موبایل </span>
                      آیفون 15 پرو
                    </div>
                    <div className="text-gray-600 text-xs">
                      <span className="font-bold">سود مشارکت در فروش </span>1
                      درصد به ازای هر کالا
                    </div>
                  </div>
                  {!showLink ? (
                    <button
                      onClick={() => setShowLink(true)}
                      className="text-primary text-lg w-full mt-5 lg:mt-0"
                    >
                      دریافت لینک مشارکت در فروش
                    </button>
                  ) : (
                    <div className="space-y-4 mt-5 lg:mt-0">
                      {/* Link Box */}
                      <div className="bg-gray-200 p-4 rounded-lg flex justify-end items-center lg:gap-6 mx-auto max-w-[540px]">
                        {/* Link */}
                        <span className="text-gray-400 ml-6">
                          {affiliateLink}
                        </span>
                        <div className="flex items-center">
                          {/* Copy Icon */}
                          <CopyIcon size={20} />
                          {/* Border */}
                          <div className="border-r-2 border-white h-6 mx-[14px]" />
                          {/* Download Icon */}
                          <DownloadIcon size={20} />
                        </div>
                      </div>

                      {/* Share Button */}
                      <div className="text-center">
                        <button className="text-primary lg:text-lg cursor-pointer">
                          اشتراک گذاری
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Hint box */}
      {isHintBoxOpen && (
        <PartnershipHintDialog
          open={isHintBoxOpen}
          setIsHintBoxOpen={setIsHintBoxOpen}
        />
      )}

      {/* Fullscreen Image Modal */}
      {isFullScreen && (
        <div
          className="fixed inset-0 z-[200] bg-gray-200/20 backdrop-blur-sm flex items-center justify-center"
          onClick={() => setIsFullScreen(false)}
        >
          <div className="absolute top-4 left-4">
            <SmallScreenIcon
              className="cursor-pointer text-gray-800"
              size={24}
              onClick={() => setIsFullScreen(false)}
            />
          </div>
          <div className="relative w-full h-full flex items-center justify-center p-4">
            <Image
              src="/assets/images/fallback/phone.png"
              fill
              alt="Partnership Fullscreen"
              className="object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
}
