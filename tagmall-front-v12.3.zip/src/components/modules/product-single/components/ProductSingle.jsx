"use client";

import { SearchInput, SearchBox } from "@/components/ui/search";
import MainNavigation from "@/components/layout/navigation-menu/MainNavigation";
import usePublicStore from "@/app/store/publicStore";
import ProductMain from "./ProductMain";
import ProductRelatedAccessories from "./ProductRelatedAccessories";
import ProductSpecifications from "./ProductSpecifications";
import ProductReviews from "./ProductReviews";
import ProductUserComments from "./ProductUserComments";
import ProductPartnership from "./ProductPartnership";
import ProductNavigation from "./ProductNavigation";
import { useState, useRef, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { SupportSingleChat } from "../../support";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { ShoppingBagIcon } from "@/icons";
import Link from "next/link";

function ProductSingle() {
  const router = useRouter();
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const searchBoxOpen = usePublicStore((s) => s.searchBoxOpen);
  const setSearchBoxOpen = usePublicStore((s) => s.setSearchBoxOpen);
  const [activeSection, setActiveSection] = useState("details");
  const [showComments, setShowComments] = useState(false);

  // Refs for desktop sections
  const sectionRefs = useRef({
    details: null,
    specsAndComments: null,
    partnership: null,
  });
  const scrollContainerRef = useRef(null);
  const isScrollingProgrammatically = useRef(false);

  const handleSearchInputClick = () => {
    setSearchBoxOpen(true);
  };

  const handleGoBack = () => {
    router.back();
  };

  // Scroll to section when clicking navigation (Desktop)
  const handleSectionClick = (sectionId) => {
    if (isDesktop && sectionRefs.current[sectionId]) {
      isScrollingProgrammatically.current = true;
      const element = sectionRefs.current[sectionId];
      const container = scrollContainerRef.current;

      if (container && element) {
        const elementTop = element.offsetTop;
        const offset = elementTop - 20; // 20px offset from top

        container.scrollTo({
          top: offset,
          behavior: "smooth",
        });

        // Reset flag after scroll animation completes
        setTimeout(() => {
          isScrollingProgrammatically.current = false;
        }, 1000);
      }
    }
    setActiveSection(sectionId);
  };

  // Detect active section on scroll (Desktop)
  useEffect(() => {
    if (!isDesktop) return;

    const container = scrollContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      // Don't update active section during programmatic scroll
      if (isScrollingProgrammatically.current) return;

      const scrollPosition = container.scrollTop;
      const containerHeight = container.clientHeight;

      // Check which section is in view
      const sections = [
        { id: "details", ref: sectionRefs.current.details },
        { id: "specsAndComments", ref: sectionRefs.current.specsAndComments },
        { id: "partnership", ref: sectionRefs.current.partnership },
      ];

      // Find the section that is most visible in the viewport
      let activeId = "details";

      for (const section of sections) {
        if (section.ref) {
          const sectionTop = section.ref.offsetTop;
          const sectionHeight = section.ref.offsetHeight;
          const sectionBottom = sectionTop + sectionHeight;

          // Check if section is in viewport (with some threshold)
          // A section is considered active if its top is within the upper half of viewport
          if (scrollPosition >= sectionTop - 150) {
            activeId = section.id;
          }
        }
      }

      setActiveSection(activeId);
    };

    // Initial check
    handleScroll();

    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, [isDesktop]);

  return (
    <>
      {/* Desktop Layout */}
      <div className="hidden lg:flex h-screen bg-gray-200 px-10 pt-[25px] pb-[5px] flex-col">
        <div className="flex flex-col gap-[25px] flex-1 min-h-0">
          {/* Top Section - Search Input */}
          <div className="flex items-center justify-between">
            <div className="flex flex-1 items-center gap-[25px] pr-6">
              <Link href={"/"}>
                <Image
                  src="/assets/images/logo/small-logo.svg"
                  width={40}
                  height={40}
                  alt="لوگو"
                  className="z-70"
                />
              </Link>
              <div className="flex-1">
                <SearchInput
                  value=""
                  onChange={() => {}}
                  placeholder="برند، کالا، لوازم جانبی، قطعات"
                  readOnly
                  hasLogo={!isDesktop}
                  bgColor="bg-white"
                  className="max-w-[642px]"
                />
              </div>
            </div>
            <Link
              href={"/cart"}
              className="w-[100px] h-[50px] bg-white rounded-lg flex items-center justify-center gap-[10px]"
            >
              <ShoppingBagIcon size={20} />
              <span className="text-gray-600">5 کالا</span>
            </Link>
          </div>

          {/* Main Content */}
          <div
            ref={scrollContainerRef}
            className="relative rounded-lg overflow-y-auto flex-1 min-h-0 scroll-smooth"
          >
            {/* Main Navigation */}
            <div className="fixed right-[65px] bottom-[55px]">
              <ProductNavigation
                activeSection={activeSection}
                setActiveSection={handleSectionClick}
              />
            </div>

            {/* Content */}
            <div className="space-y-1.5 bg-gray-200">
              {/* Section 1: Details (ProductMain + ProductRelatedAccessories) */}
              <div
                className="space-y-1.5"
                ref={(el) => (sectionRefs.current.details = el)}
              >
                <ProductMain />
                <ProductRelatedAccessories />
              </div>

              {/* Section 2: Specs and Comments (ProductSpecifications + ProductReviews + ProductUserComments) */}
              <div
                className="space-y-1.5"
                ref={(el) => (sectionRefs.current.specsAndComments = el)}
              >
                <ProductSpecifications />
                <ProductReviews />
                <ProductUserComments />
              </div>

              {/* Section 3: Partnership */}
              <div
                className="space-y-1.5"
                ref={(el) => (sectionRefs.current.partnership = el)}
              >
                <ProductPartnership />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Layout */}
      {!isDesktop && (
        <Drawer open={true} onOpenChange={() => router.back()}>
          <DrawerContent className="z-100! h-[96%]!" overlayClassName="z-100">
            <h2 className="font-extralight text-primary text-base lg:text-lg mt-4 mb-4 px-[10px]">
              <span className="font-bold">گوشی موبایل</span> آیفون 15 پرو مکس
            </h2>
            <div className="flex flex-col h-full">
              {/* Content Area */}
              <div className="flex-1 overflow-y-auto scroll-hidden">
                <div className="space-y-1">
                  {activeSection === "details" && <ProductMain />}
                  {activeSection === "specsAndComments" && (
                    <Tabs defaultValue="specs" className="bg-gray-200">
                      <TabsList
                        dir="rtl"
                        className="w-full max-w-[540px] flex items-center gap-1 px-[10px]! mt-2"
                      >
                        <TabsTrigger
                          value="specs"
                          className="bg-white rounded-md! flex-1 shadow-none! text-gray-600 data-[state=active]:text-primary font-bold! h-[48px]"
                        >
                          مشخصات
                        </TabsTrigger>
                        <TabsTrigger
                          value="reviews"
                          className="bg-white rounded-md! flex-1 shadow-none! text-gray-600 data-[state=active]:text-primary font-bold! h-[48px]"
                        >
                          نقد و بررسی
                        </TabsTrigger>
                      </TabsList>
                      <TabsContent value="specs" dir="rtl">
                        <ProductSpecifications
                          setShowComments={setShowComments}
                        />
                      </TabsContent>
                      <TabsContent value="reviews" dir="rtl">
                        <ProductReviews setShowComments={setShowComments} />
                      </TabsContent>
                    </Tabs>
                  )}
                  {activeSection === "partnership" && <ProductPartnership />}
                </div>
              </div>

              {/* Fixed Bottom Navigation */}
              <div className="bg-white -mx-[10px] px-[10px]">
                <ProductNavigation
                  activeSection={activeSection}
                  setActiveSection={setActiveSection}
                  onGoBack={handleGoBack}
                />
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      )}

      {!isDesktop && (
        <Drawer open={showComments} onOpenChange={() => setShowComments(false)}>
          <DrawerContent
            className="z-100! h-[96%]! bg-gray-200!"
            overlayClassName="z-100 lg:hidden"
          >
            <ProductUserComments />
          </DrawerContent>
        </Drawer>
      )}

      {/* Search Box */}
      <SearchBox
        isOpen={searchBoxOpen}
        onClose={() => setSearchBoxOpen(false)}
      />
    </>
  );
}

export default ProductSingle;
