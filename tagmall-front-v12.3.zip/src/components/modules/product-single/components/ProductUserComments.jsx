"use client";

import { useState, useEffect, useRef } from "react";
import { SupportIcon, HeartIcon, CloseSquareIcon } from "@/icons";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import MessageContextMenu from "@/components/ui/MessageContextMenu";

export default function ProductUserComments() {
  const [likedMessages, setLikedMessages] = useState({});
  const [isOpen, setIsOpen] = useState(true);
  const [contextMenuOpen, setContextMenuOpen] = useState(false);
  const [activeMessageId, setActiveMessageId] = useState(null);
  const [activeTriggerElement, setActiveTriggerElement] = useState(null);
  const [showCommentInput, setShowCommentInput] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [userComments, setUserComments] = useState([]);
  const [replyInputs, setReplyInputs] = useState({}); // {messageId: {show: true, text: ''}}
  const [activeReplyId, setActiveReplyId] = useState(null); // ID of message being replied to

  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const hasOverflow = !isDesktop;

  const menuRef = useRef(null);
  const triggerRefs = useRef({});
  const inputRef = useRef(null);
  const activeReplyInputRef = useRef(null);

  const toggleLike = (id) => {
    setLikedMessages((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleOpenMenu = (e, messageId) => {
    e.preventDefault();
    e.stopPropagation();

    if (contextMenuOpen && activeMessageId === messageId) {
      handleCloseMenu();
      return;
    }

    setContextMenuOpen(true);
    setActiveMessageId(messageId);
    setActiveTriggerElement(triggerRefs.current[messageId]);
  };

  const handleCloseMenu = () => {
    setContextMenuOpen(false);
    setActiveMessageId(null);
    setActiveTriggerElement(null);
  };

  const handleReply = (messageId) => {
    console.log("Reply to:", messageId);
    // اینجا می‌توانید منطق پاسخ دادن را پیاده‌سازی کنید
  };

  const handleDelete = (messageId) => {
    console.log("Delete:", messageId);
    // اینجا می‌توانید منطق حذف را پیاده‌سازی کنید
  };

  const handleReport = (messageId) => {
    console.log("Report:", messageId);
    // اینجا می‌توانید منطق گزارش را پیاده‌سازی کنید
  };

  const handleSubmitComment = () => {
    if (!newComment.trim()) return;

    const now = new Date();
    const timestamp = now.getTime();
    const newCommentObj = {
      id: `user-${timestamp}`,
      user: "کاربر",
      message: newComment,
      date: now.toLocaleDateString("fa-IR", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
      likes: 0,
      isUserComment: true,
    };

    setUserComments((prev) => [newCommentObj, ...prev]);
    setNewComment("");
    setShowCommentInput(false);
  };

  const handleSubmitReply = (messageId) => {
    const replyText = replyInputs[messageId]?.text;
    if (!replyText?.trim()) return;

    // Find the message being replied to
    const replyToMessage = [
      ...userComments,
      ...qaBoxes.flatMap((box) => box.messages),
    ].find((msg) => msg.id === messageId);

    const now = new Date();
    const timestamp = now.getTime();
    const newReplyObj = {
      id: `reply-${timestamp}`,
      user: "کاربر",
      message: replyText,
      date: now.toLocaleDateString("fa-IR", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
      likes: 0,
      isUserComment: true,
      replyTo: messageId,
      replyToText: replyToMessage?.message || "",
    };

    // Find which chat box this message belongs to
    const chatBoxIndex = qaBoxes.findIndex((box) =>
      box.messages.some((msg) => msg.id === messageId),
    );

    if (chatBoxIndex !== -1) {
      // Add reply directly to the qaBoxes messages array
      const updatedQaBoxes = [...qaBoxes];
      updatedQaBoxes[chatBoxIndex].messages.push(newReplyObj);
      setQaBoxes(updatedQaBoxes);
    } else {
      // It's a reply to a user comment
      setUserComments((prev) => [...prev, newReplyObj]);
    }

    setReplyInputs((prev) => ({
      ...prev,
      [messageId]: { show: false, text: "" },
    }));
    setActiveReplyId(null);
  };

  const handleOpenCommentInput = () => {
    setShowCommentInput(true);
    // Focus on input after it's rendered
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };

  const handleReplyToMessage = (messageId) => {
    setReplyInputs((prev) => ({
      ...prev,
      [messageId]: { show: true, text: prev[messageId]?.text || "" },
    }));
    setActiveReplyId(messageId);
    setTimeout(() => {
      activeReplyInputRef.current?.focus();
      // On desktop, scroll to the reply input element
      if (isDesktop && activeReplyInputRef.current) {
        activeReplyInputRef.current.scrollIntoView({
          behavior: "smooth",
          block: "nearest",
        });
      }
    }, 100);
  };

  const handleCancelComment = () => {
    setShowCommentInput(false);
    setNewComment("");
  };

  const handleCancelReply = (messageId) => {
    setReplyInputs((prev) => ({
      ...prev,
      [messageId]: { show: false, text: "" },
    }));
    setActiveReplyId(null);
  };

  const handleReplyTextChange = (messageId, text) => {
    setReplyInputs((prev) => ({
      ...prev,
      [messageId]: { ...prev[messageId], text },
    }));
  };

  const scrollToReplyTarget = (messageId) => {
    const element = triggerRefs.current[messageId];
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        contextMenuOpen &&
        menuRef.current &&
        !menuRef.current.contains(e.target)
      ) {
        handleCloseMenu();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [contextMenuOpen]);

  const [qaBoxes, setQaBoxes] = useState([
    {
      id: 1,
      messages: [
        {
          id: "q-1",
          user: "علی محمدی",
          message:
            "آیا این محصول گارانتی دارد؟ می‌خواستم بدونم شرایط گارانتی چطوریه؟",
          date: "1 مهر 1404",
          likes: 10,
          isUserMessage: false,
        },
        {
          id: "a-1",
          user: "فروشنده",
          message: "بله، این محصول دارای گارانتی 18 ماهه می‌باشد.",
          date: "2 مهر 1404",
          likes: 5,
          isUserMessage: false,
        },
      ],
    },
    {
      id: 2,
      messages: [
        {
          id: "q-2",
          user: "سارا احمدی",
          message: "زمان ارسال چقدر طول می‌کشه؟",
          date: "3 مهر 1404",
          likes: 8,
          isUserMessage: false,
        },
        {
          id: "a-2",
          user: "فروشنده",
          message:
            "ارسال به تهران 1 تا 2 روز کاری و شهرستان 3 تا 5 روز کاری می‌باشد.",
          date: "3 مهر 1404",
          likes: 3,
          isUserMessage: false,
        },
      ],
    },
    {
      id: 3,
      messages: [
        {
          id: "q-3",
          user: "رضا کریمی",
          message: "کیفیت ساخت خوبه؟ ارزش خرید داره؟",
          date: "5 مهر 1404",
          likes: 15,
          isUserMessage: false,
        },
        {
          id: "a-3",
          user: "فروشنده",
          message: "بله، کیفیت عالی و متریال درجه یک استفاده شده.",
          date: "5 مهر 1404",
          likes: 7,
          isUserMessage: false,
        },
      ],
    },
    {
      id: 4,
      messages: [
        {
          id: "q-4",
          user: "مینا رضایی",
          message: "آیا امکان پرداخت در محل وجود دارد؟",
          date: "7 مهر 1404",
          likes: 12,
          isUserMessage: false,
        },
        {
          id: "a-4",
          user: "فروشنده",
          message: "بله، پرداخت در محل برای تهران و کرج فعال است.",
          date: "7 مهر 1404",
          likes: 4,
          isUserMessage: false,
        },
      ],
    },
    {
      id: 5,
      messages: [
        {
          id: "q-5",
          user: "حسین نوری",
          message: "رنگ‌های دیگه موجوده؟",
          date: "10 مهر 1404",
          likes: 6,
          isUserMessage: false,
        },
        {
          id: "a-5",
          user: "فروشنده",
          message: "در حال حاضر فقط رنگ مشکی و سفید موجود است.",
          date: "10 مهر 1404",
          likes: 2,
          isUserMessage: false,
        },
      ],
    },
    {
      id: 6,
      messages: [
        {
          id: "q-6",
          user: "فاطمه حسینی",
          message: "با این قیمت چرا انقدر گرونه؟ قیمت مناسب‌تری نداره؟",
          date: "12 مهر 1404",
          likes: 20,
          isUserMessage: false,
        },
        {
          id: "a-6",
          user: "فروشنده",
          message:
            "قیمت متناسب با کیفیت و برند محصول است. در حال حاضر تخفیف ویژه داریم.",
          date: "12 مهر 1404",
          likes: 9,
          isUserMessage: false,
        },
      ],
    },
  ]);

  return (
    <div
      className={`lg:bg-white lg:rounded-b-lg lg:py-[10px] lg:px-[100px] ${
        isOpen ? "lg:pt-[50px]" : "lg:py-[50px]"
      }`}
    >
      {/* Context menu overlay */}
      {contextMenuOpen && (
        <div
          className="fixed inset-0 bg-gray-200/20 backdrop-blur-sm z-998"
          onClick={handleCloseMenu}
        />
      )}

      <Accordion
        type="single"
        collapsible
        defaultValue="comments"
        onValueChange={(value) => setIsOpen(value === "comments")}
      >
        <AccordionItem value="comments">
          <AccordionTrigger className="hidden lg:flex justify-between text-primary text-[16px] lg:text-[20px] font-semibold hover:no-underline font-iransans">
            پرسش و پاسخ و دیدگاه کاربران
          </AccordionTrigger>
          <AccordionContent className="mt-4 flex flex-col h-screen lg:h-auto relative">
            <div
              className={`flex flex-col lg:flex-row items-center gap-[6px] pb-36 lg:pb-0 ${
                hasOverflow ? "overflow-y-auto" : ""
              } scroll-hidden lg:overflow-x-auto`}
            >
              {/* Guide Box */}
              <div className="flex gap-[6px] shrink-0 mb-12">
                <div className="flex flex-col justify-between h-auto">
                  <div className="flex items-end gap-2">
                    <div className="border-2 border-white lg:border-primary/20 rounded-t-lg rounded-br-lg px-2 py-[2px] max-w-[175px]">
                      <p className="text-xs font-iransans">
                        <span className="font-bold">راهنما:</span> سوالات خود را
                        در مورد محصول بپرسید
                      </p>
                      <p className="text-xs text-center text-gray-400 mt-2">
                        1 مهر 1404
                      </p>
                    </div>
                    <div className="border-2 border-white lg:border-gray-200 rounded-lg p-[10px]">
                      <SupportIcon size={20} />
                    </div>
                  </div>

                  {/* Comment Input Box */}
                  {showCommentInput ? (
                    isDesktop ? (
                      <div className="bg-white rounded-lg p-3">
                        <textarea
                          ref={inputRef}
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          placeholder="نظر یا پرسش خود را بنویسید..."
                          className="w-full min-h-[80px] p-2 border-2 border-gray-200 rounded-lg resize-none outline-none focus:border-primary text-xs font-iransans"
                        />
                        <div className="flex items-center justify-end gap-2 mt-2">
                          <button
                            onClick={handleCancelComment}
                            className="px-4 py-2 text-xs font-iransans text-gray-400"
                          >
                            انصراف
                          </button>
                          <button
                            onClick={handleSubmitComment}
                            disabled={!newComment.trim()}
                            className="px-4 py-2 text-xs font-iransans text-primary disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            ارسال
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="fixed bottom-4 right-[10px] left-[10px] z-20">
                        <div className="relative rounded-t-md rounded-bl-md bg-gray-200 overflow-hidden border-2 border-white">
                          <input
                            ref={inputRef}
                            type="text"
                            placeholder="نظر یا پرسش ..."
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            className="font-iransans placeholder:text-gray-400 text-gray-600 h-14 pr-2 pl-14 w-full outline-none bg-gray-200"
                          />
                          {newComment.trim().length > 0 ? (
                            <button
                              onClick={handleSubmitComment}
                              className="absolute left-2 bottom-1/2 translate-y-1/2 font-iransans text-primary cursor-pointer"
                            >
                              ارسال
                            </button>
                          ) : (
                            <button
                              onClick={handleCancelComment}
                              className="absolute left-2 bottom-1/2 translate-y-1/2 font-iransans text-gray-400 cursor-pointer"
                            >
                              انصراف
                            </button>
                          )}
                        </div>
                      </div>
                    )
                  ) : (
                    <button
                      onClick={handleOpenCommentInput}
                      className="font-iransans fixed lg:static bottom-4 right-[10px] left-[10px] rounded-lg py-4 bg-white text-primary text-center z-20"
                    >
                      ثبت دیدگاه یا پرسش
                    </button>
                  )}
                </div>
                <div className="hidden lg:block w-[2px] h-[200px] bg-gray-200" />
              </div>

              {/* User Comments */}
              {userComments.map((comment, index) => (
                <div
                  key={comment.id}
                  className="flex items-start gap-[6px] shrink-0 mb-4 lg:mb-12 w-full lg:w-auto border-b-2 border-white pb-4 lg:pb-0 lg:border-0"
                >
                  <div className="flex flex-col gap-2 w-full lg:w-auto lg:max-h-[208px] scroll-hidden lg:overflow-y-auto relative">
                    {/* User Comment - Always on the right side */}
                    <div className="flex items-center justify-end lg:justify-normal gap-3 lg:gap-[50px]">
                      <div className="flex flex-col items-center gap-1">
                        <button onClick={() => toggleLike(comment.id)}>
                          <HeartIcon
                            size={20}
                            color={
                              likedMessages[comment.id]
                                ? "var(--error-color-medium)"
                                : "var(--gray-color-400)"
                            }
                          />
                        </button>
                        <span
                          className={`text-xs ${
                            likedMessages[comment.id]
                              ? "text-error-medium"
                              : "text-gray-400"
                          }`}
                        >
                          {comment.likes}
                        </span>
                      </div>
                      <div className="flex flex-col gap-2">
                        <div
                          ref={(el) => (triggerRefs.current[comment.id] = el)}
                          className={`relative border-2 border-gray-400 bg-gray-200 rounded-t-lg rounded-br-lg px-2 py-[2px] max-w-[175px] cursor-context-menu ${
                            contextMenuOpen && activeMessageId === comment.id
                              ? "z-999"
                              : ""
                          }`}
                          onClick={(e) => handleOpenMenu(e, comment.id)}
                          onContextMenu={(e) => handleOpenMenu(e, comment.id)}
                        >
                          <p className="text-xs font-iransans">
                            <span className="font-bold">{comment.user}:</span>{" "}
                            {comment.message}
                          </p>
                          <p className="text-xs text-center text-gray-400 mt-2">
                            {comment.date}
                          </p>
                        </div>
                        <button
                          onClick={() => handleReplyToMessage(comment.id)}
                          className="font-iransans text-xs text-primary text-center"
                        >
                          پاسخ
                        </button>
                      </div>
                    </div>

                    {/* Reply Input for this comment - Desktop only, inside scrollable container */}
                    {isDesktop &&
                      replyInputs[comment.id]?.show &&
                      activeReplyId === comment.id && (
                        <div className="flex items-center justify-start gap-3 lg:gap-[50px] mt-2">
                          <div className="flex flex-col gap-2 items-center w-full max-w-[175px]">
                            <div className="w-full bg-white rounded-lg p-2 border-2 border-gray-200">
                              <div className="bg-gray-100 border-r-4 border-gray-600 py-1 px-2 rounded-md mb-2">
                                <span className="font-iransans text-gray-600 text-xs">
                                  در حال پاسخ به نظر کاربر
                                </span>
                              </div>
                              <textarea
                                ref={activeReplyInputRef}
                                value={replyInputs[comment.id]?.text || ""}
                                onChange={(e) =>
                                  handleReplyTextChange(
                                    comment.id,
                                    e.target.value,
                                  )
                                }
                                placeholder="پاسخ خود را بنویسید..."
                                className="w-full min-h-[60px] text-xs font-iransans resize-none outline-none"
                              />
                              <div className="flex items-center justify-end gap-2 mt-1">
                                <button
                                  onClick={() => handleCancelReply(comment.id)}
                                  className="px-2 py-1 text-xs font-iransans text-gray-400"
                                >
                                  انصراف
                                </button>
                                <button
                                  onClick={() => handleSubmitReply(comment.id)}
                                  disabled={
                                    !replyInputs[comment.id]?.text?.trim()
                                  }
                                  className="px-2 py-1 text-xs font-iransans text-primary disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  ارسال
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                  </div>
                  {(index < userComments.length - 1 || qaBoxes.length > 0) && (
                    <div className="w-[2px] h-[200px] bg-gray-200" />
                  )}
                </div>
              ))}

              {/* Q&A Boxes */}
              {qaBoxes.map((box, boxIndex) => {
                const allMessages = box.messages;

                return (
                  <div
                    key={box.id}
                    className="flex items-start gap-[6px] shrink-0 mb-4 lg:mb-12 w-full lg:w-auto border-b-2 border-white pb-4 lg:pb-0 lg:border-0"
                  >
                    <div className="flex flex-col gap-2 w-full lg:w-auto lg:max-h-[208px] scroll-hidden lg:overflow-y-auto relative">
                      {allMessages.map((msg) => {
                        const isQuestion = msg.id.startsWith("q-");
                        const isUserMsg = msg.isUserComment;
                        const isRightSide = isQuestion || isUserMsg;

                        return (
                          <div key={msg.id}>
                            {/* Message */}
                            <div
                              className={`flex items-center justify-between gap-4`}
                            >
                              {isRightSide && (
                                <div className="flex flex-col items-center gap-1">
                                  <button onClick={() => toggleLike(msg.id)}>
                                    <HeartIcon
                                      size={20}
                                      color={
                                        likedMessages[msg.id]
                                          ? "var(--error-color-medium)"
                                          : "var(--gray-color-400)"
                                      }
                                    />
                                  </button>
                                  <span
                                    className={`text-xs ${
                                      likedMessages[msg.id]
                                        ? "text-error-medium"
                                        : "text-gray-400"
                                    }`}
                                  >
                                    {msg.likes}
                                  </span>
                                </div>
                              )}

                              <div className="flex flex-col gap-2">
                                <div
                                  ref={(el) =>
                                    (triggerRefs.current[msg.id] = el)
                                  }
                                  className={`relative border-2 ${
                                    isUserMsg
                                      ? "border-gray-400 bg-gray-200"
                                      : isRightSide
                                        ? "border-gray-400 lg:border-gray-200"
                                        : "border-gray-300"
                                  } ${
                                    isRightSide
                                      ? "rounded-t-lg rounded-br-lg"
                                      : "rounded-t-lg rounded-bl-lg"
                                  } px-2 py-[2px] max-w-[175px] cursor-context-menu ${
                                    contextMenuOpen &&
                                    activeMessageId === msg.id
                                      ? "z-999"
                                      : ""
                                  }`}
                                  onClick={(e) => handleOpenMenu(e, msg.id)}
                                  onContextMenu={(e) =>
                                    handleOpenMenu(e, msg.id)
                                  }
                                >
                                  {msg.replyTo && msg.replyToText && (
                                    <div className="bg-white border-r-2 border-gray-600 py-1 px-2 mb-2 rounded-md">
                                      <span className="text-xs text-gray-600 font-iransans line-clamp-1">
                                        {msg.replyToText}
                                      </span>
                                    </div>
                                  )}
                                  <p className="text-xs font-iransans">
                                    <span className="font-bold">
                                      {msg.user}:
                                    </span>{" "}
                                    {msg.message}
                                  </p>
                                  <p className="text-xs text-center text-gray-400 mt-2">
                                    {msg.date}
                                  </p>
                                </div>
                                <button
                                  onClick={() => handleReplyToMessage(msg.id)}
                                  className="font-iransans text-xs text-primary text-center"
                                >
                                  پاسخ
                                </button>
                              </div>

                              {!isRightSide && (
                                <div className="flex flex-col items-center gap-1">
                                  <button onClick={() => toggleLike(msg.id)}>
                                    <HeartIcon
                                      size={20}
                                      color={
                                        likedMessages[msg.id]
                                          ? "var(--error-color-medium)"
                                          : "var(--gray-color-400)"
                                      }
                                    />
                                  </button>
                                  <span
                                    className={`text-xs ${
                                      likedMessages[msg.id]
                                        ? "text-error-medium"
                                        : "text-gray-400"
                                    }`}
                                  >
                                    {msg.likes}
                                  </span>
                                </div>
                              )}
                            </div>

                            {/* Reply Input for this message - Desktop only, inside scrollable container */}
                            {isDesktop &&
                              replyInputs[msg.id]?.show &&
                              activeReplyId === msg.id && (
                                <div className="flex items-center justify-start gap-3 lg:gap-[50px] mt-2">
                                  <div className="flex flex-col gap-2 items-center w-full max-w-[175px]">
                                    <div className="w-full bg-white rounded-lg p-2 border-2 border-gray-200">
                                      <div className="bg-gray-100 border-r-4 border-gray-600 py-1 px-2 rounded-md mb-2">
                                        <span className="font-iransans text-gray-600 text-xs line-clamp-1">
                                          {msg.message}
                                        </span>
                                      </div>
                                      <textarea
                                        ref={activeReplyInputRef}
                                        value={replyInputs[msg.id]?.text || ""}
                                        onChange={(e) =>
                                          handleReplyTextChange(
                                            msg.id,
                                            e.target.value,
                                          )
                                        }
                                        placeholder="پاسخ خود را بنویسید..."
                                        className="w-full min-h-[60px] text-xs font-iransans resize-none outline-none"
                                      />
                                      <div className="flex items-center justify-end gap-2 mt-1">
                                        <button
                                          onClick={() =>
                                            handleCancelReply(msg.id)
                                          }
                                          className="px-2 py-1 text-xs font-iransans text-gray-400"
                                        >
                                          انصراف
                                        </button>
                                        <button
                                          onClick={() =>
                                            handleSubmitReply(msg.id)
                                          }
                                          disabled={
                                            !replyInputs[msg.id]?.text?.trim()
                                          }
                                          className="px-2 py-1 text-xs font-iransans text-primary disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                          ارسال
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              )}
                          </div>
                        );
                      })}
                    </div>
                    {boxIndex < qaBoxes.length - 1 && (
                      <div className="w-[2px] h-[200px] bg-gray-200" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Reply Input Box - Fixed at bottom for mobile only */}
            {!isDesktop && activeReplyId && (
              <div className="fixed bottom-4 right-[10px] left-[10px] z-30">
                <div className="relative rounded-t-md rounded-bl-md bg-gray-200 overflow-hidden border-2 border-white">
                  <div
                    onClick={() => scrollToReplyTarget(activeReplyId)}
                    className="bg-white border-r-4 border-gray-600 py-2.5 pl-1 pr-2 rounded-md mx-2 mt-1 flex items-center justify-between cursor-pointer"
                  >
                    <span className="font-iransans text-gray-600 text-xs max-w-[80%] whitespace-nowrap overflow-hidden text-ellipsis">
                      {(() => {
                        // Find the message being replied to
                        const replyToMessage = [
                          ...userComments,
                          ...qaBoxes.flatMap((box) => box.messages),
                        ].find((msg) => msg.id === activeReplyId);
                        return replyToMessage?.message || "";
                      })()}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCancelReply(activeReplyId);
                      }}
                    >
                      <CloseSquareIcon size={20} />
                    </button>
                  </div>
                  <input
                    ref={activeReplyInputRef}
                    type="text"
                    placeholder="پاسخ ..."
                    value={replyInputs[activeReplyId]?.text || ""}
                    onChange={(e) =>
                      handleReplyTextChange(activeReplyId, e.target.value)
                    }
                    className="font-iransans placeholder:text-gray-400 text-gray-600 h-14 pr-2 pl-14 w-full outline-none bg-gray-200"
                  />
                  {replyInputs[activeReplyId]?.text?.trim().length > 0 ? (
                    <button
                      onClick={() => handleSubmitReply(activeReplyId)}
                      className="absolute left-2 bottom-4 font-iransans text-primary cursor-pointer"
                    >
                      ارسال
                    </button>
                  ) : (
                    <button
                      onClick={() => handleCancelReply(activeReplyId)}
                      className="absolute left-2 bottom-4 font-iransans text-gray-400 cursor-pointer"
                    >
                      انصراف
                    </button>
                  )}
                </div>
              </div>
            )}
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Context Menus - Rendered via Portal */}
      {contextMenuOpen && activeMessageId && activeTriggerElement && (
        <MessageContextMenu
          isOpen={true}
          onReply={() => handleReply(activeMessageId)}
          onDelete={() => handleDelete(activeMessageId)}
          onReport={() => handleReport(activeMessageId)}
          onClose={handleCloseMenu}
          position={activeMessageId.startsWith("q-") ? "right" : "left"}
          triggerRef={{ current: activeTriggerElement }}
        />
      )}
    </div>
  );
}
