"use client";

import { ReplyIcon, Trash2Icon } from "lucide-react";
import { HintIcon } from "@/icons";
import { createPortal } from "react-dom";
import { useEffect, useState, useRef } from "react";

export default function MessageContextMenu({
  isOpen,
  onReply,
  onDelete,
  onReport,
  onClose,
  position = "right", // "right" or "left"
  triggerRef, // ref to the element that triggered the menu
}) {
  const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 });
  const [isReady, setIsReady] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (isOpen && triggerRef?.current) {
      const triggerRect = triggerRef.current.getBoundingClientRect();
      const menuHeight = 150; // تقریبی ارتفاع منو
      const menuWidth = 150;

      let top = triggerRect.bottom + 5;
      let left =
        position === "right" ? triggerRect.right - menuWidth : triggerRect.left;

      // بررسی اینکه آیا منو از پایین صفحه خارج می‌شود
      if (top + menuHeight > window.innerHeight) {
        top = triggerRect.top - menuHeight - 5;
      }

      // بررسی اینکه آیا منو از راست یا چپ صفحه خارج می‌شود
      if (left < 0) {
        left = 10;
      } else if (left + menuWidth > window.innerWidth) {
        left = window.innerWidth - menuWidth - 10;
      }

      setMenuPosition({ top, left });
      // کمی تاخیر برای اینکه موقعیت اول set شود، بعد انیمیشن شروع شود
      requestAnimationFrame(() => {
        setIsReady(true);
      });
    } else {
      setIsReady(false);
    }
  }, [isOpen, triggerRef, position]);

  if (!isOpen) return null;

  const menuContent = (
    <div
      ref={menuRef}
      style={{
        position: "fixed",
        top: `${menuPosition.top}px`,
        left: `${menuPosition.left}px`,
        zIndex: 1000,
      }}
      className={`bg-white text-gray-800 border-0 rounded-md shadow-xl min-w-[150px] overflow-hidden p-1 transition-opacity duration-200 ${
        isReady ? "opacity-100" : "opacity-0"
      }`}
    >
      {onReply && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            onReply();
            onClose();
          }}
          className="flex items-center justify-between text-xs lg:text-base text-gray-700 px-2 py-3 cursor-pointer hover:bg-gray-100 rounded-sm transition-colors select-none"
        >
          <ReplyIcon size={20} />
          پاسخ
        </div>
      )}

      {onDelete && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
            onClose();
          }}
          className="flex items-center justify-between text-xs lg:text-base text-error-medium px-2 py-3 lg:py-2 cursor-pointer hover:bg-error-light rounded-sm transition-colors select-none"
        >
          <Trash2Icon size={20} />
          حذف
        </div>
      )}

      {onReport && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            onReport();
            onClose();
          }}
          className="flex items-center justify-between text-xs lg:text-base text-error-medium px-2 py-3 lg:py-2 cursor-pointer hover:bg-error-light rounded-sm transition-colors select-none"
        >
          <HintIcon size={20} />
          گزارش
        </div>
      )}
    </div>
  );

  return typeof window !== "undefined"
    ? createPortal(menuContent, document.body)
    : null;
}
