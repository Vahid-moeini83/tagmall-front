"use client";

import { useState } from "react";
import { SearchBox, SearchInput } from "@/components/ui/search";
import MainNavigation from "@/components/layout/navigation-menu/MainNavigation";
import CartItems from "./CartItems";
import OrderSummary from "./OrderSummary";
import OrderItems from "./OrderItems";
import { DragHandler } from "@/components/ui/drag-handler";
import { StrokeArrowLeftIcon } from "@/icons";
import usePublicStore from "@/app/store/publicStore";
import { useRouter } from "next/navigation";

function CartPageContent() {
  const router = useRouter();

  const [isOrderItemsOpen, setIsOrderItemsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [searchValue, setSearchValue] = useState("");

  const searchBoxOpen = usePublicStore((s) => s.searchBoxOpen);
  const setSearchBoxOpen = usePublicStore((s) => s.setSearchBoxOpen);
  const setDefaultSearchValue = usePublicStore((s) => s.setSearchValue);

  const handleNextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleSearchInputClick = () => {
    setDefaultSearchValue(searchValue);
    setSearchBoxOpen(true);
  };

  const handleGoBack = () => {
    router.back();
  };

  return (
    <>
      {/* Mobile Layout */}
      <div className="relative flex lg:hidden h-screen bg-white flex-col">
        <div className="absolute top-2 right-1/2 translate-x-1/2">
          <DragHandler />
        </div>
        {/* Main Content */}
        <div className="flex-1 overflow-y-auto px-6 pt-10 select-none">
          {/* Steps */}
          <div className="flex items-center justify-center mb-8">
            <div
              className={`rounded-md text-sm w-full h-10 flex items-center justify-center bg-gray-200 ${currentStep === 1 ? "text-primary font-bold" : currentStep > 1 ? "text-gray-600" : "text-gray-400"}`}
            >
              سبد خرید
            </div>
            <div className="w-30 h-[3px] bg-gray-200" />
            <div
              className={`rounded-md text-sm w-full h-10 flex items-center justify-center bg-gray-200 ${currentStep === 2 ? "text-primary font-bold" : currentStep > 2 ? "text-gray-600" : "text-gray-400"}`}
            >
              صورت حساب
            </div>
            <div className="w-30 h-[3px] bg-gray-200" />
            <div
              className={`rounded-md text-sm w-full h-10 flex items-center justify-center bg-gray-200  ${currentStep === 3 ? "text-primary font-bold" : "text-gray-400"}`}
            >
              تحویل سفارش
            </div>
          </div>

          {/* Content based on step */}
          {currentStep === 1 && (
            <CartItems handleNextStep={handleNextStep} isMobile={true} />
          )}

          {currentStep === 2 && (
            <OrderSummary
              isOrderItemsOpen={isOrderItemsOpen}
              setIsOrderItemsOpen={setIsOrderItemsOpen}
              handleNextStep={handleNextStep}
              isMobile={true}
            />
          )}

          {currentStep === 3 && <OrderItems isMobile={true} />}
        </div>

        {/* Main Navigation */}
        <MainNavigation isHomePage={false} />
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:flex h-screen bg-gray-200 px-10 pt-[25px] pb-[5px] flex-col">
        <div className="flex flex-col gap-[25px] flex-1 min-h-0">
          {/* Top Section - Search Input */}
          <div className="flex items-center gap-4">
            <div
              onClick={() => handleGoBack()}
              className="flex items-center justify-center w-12 h-12 rounded-md bg-white cursor-pointer"
            >
              <StrokeArrowLeftIcon className="rotate-180" />
            </div>

            <div
              onClick={handleSearchInputClick}
              className="flex-1 cursor-pointer"
            >
              <SearchInput
                value=""
                onChange={() => {}}
                placeholder="برند، کالا، لوازم جانبی، قطعات"
                showSearchIcon={false}
                readOnly
                bgColor="bg-white"
              />
            </div>
          </div>

          {/* Main Content */}
          <div className="relative rounded-lg overflow-y-auto flex-1 min-h-0">
            {/* Main Navigation */}
            <div className="fixed right-[50px] bottom-[55px]">
              <MainNavigation isHomePage={false} />
            </div>

            {/* Content */}
            <div className="space-y-2 bg-gray-200">
              {/* First White Box - Cart Items */}
              <div className="bg-white rounded-t-lg p-16">
                <CartItems isMobile={false} />
              </div>

              {/* Second White Box - Order Summary */}
              <div className="bg-white rounded-b-lg p-16">
                <OrderSummary
                  isOrderItemsOpen={isOrderItemsOpen}
                  setIsOrderItemsOpen={setIsOrderItemsOpen}
                  isMobile={false}
                />
              </div>

              {/* Third White Box - Order Items (Conditional) */}
              {isOrderItemsOpen && (
                <div className="bg-white rounded-lg p-16">
                  <OrderItems isMobile={false} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Search Box */}
      <SearchBox
        isOpen={searchBoxOpen}
        onClose={() => setSearchBoxOpen(false)}
      />
    </>
  );
}

export default CartPageContent;
