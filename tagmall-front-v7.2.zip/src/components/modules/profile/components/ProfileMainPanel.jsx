import { DragHandler } from "@/components/ui/drag-handler";
import {
  ArrowRightIcon,
  ChevronLeftIcon,
  ExternalLinkIcon,
  PanelIcon,
  PlusIcon,
} from "@/icons";
import { formatPrice } from "@/lib/client/utils";
import Image from "next/image";
import Link from "next/link";

function ProfileMainPanel({
  setIsWalletOpen,
  setIsEditingProfile,
  setIsProfileOpen,
}) {
  return (
    <div className="h-full flex flex-col justify-between px-6 pb-6 pt-10">
      <div className="absolute top-2 right-1/2 translate-x-1/2">
        <DragHandler
          hasCloseEvent={true}
          onClose={() => setIsProfileOpen(false)}
        />
      </div>
      <div>
        {/* Wallet section */}
        <div className="relative w-full h-[120px] lg:w-full lg:max-w-[480px] lg:h-[200px] lg:mx-auto mb-6">
          <Image
            src="/assets/images/wallet-bg.svg"
            fill
            alt="wallet background"
            className="object-cover rounded-lg"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-linear-to-br from-primary via-primary/70 to-primary/50 rounded-lg">
            <span className="text-sm lg:text-base font-semibold text-white">
              کیف پول اعتباری
            </span>
            <span className="text-sm lg:text-base text-white">
              موجودی <span className="font-bold">{formatPrice(1000000)}</span>{" "}
              تومان
            </span>
          </div>
          <button
            onClick={() => setIsWalletOpen(true)}
            className="absolute left-4 top-1/2 -translate-y-1/2 hover:opacity-80 transition-opacity cursor-pointer"
          >
            <PlusIcon size={24} className="text-white" />
          </button>
        </div>
        {/* Seller panel section */}
        <div className="border-t-2 border-gray-200 py-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3 lg:gap-4">
              <PanelIcon size={24} className="text-gray-800" />
              <span className="text-gray-600 font-semibold cursor-pointer">
                پنل فروشندگان
              </span>
            </div>
            <button className="hover:opacity-80 transition-opacity">
              <ArrowRightIcon size={20} className="-rotate-45" />
            </button>
          </div>
          <p className="font-iransans font-bold lg:font-normal text-xs lg:text-base text-gray-600 pr-10 leading-7 lg:leading-10">
            با ثبت محصولات و بهره مند از خدمات ما ، بازدید و فروش بیش تر و تجربه
            بی نظیری برای مشتریان خود فراهم کنید
          </p>
        </div>
        {/* Partnership section */}
        <div className="border-t-2 border-gray-200 py-4">
          <Link
            href="/profile/partnership"
            className="flex items-center justify-between mb-2"
          >
            <div className="flex items-center gap-4">
              <ExternalLinkIcon size={20} className="text-gray-800" />
              <span className="text-gray-600 font-semibold cursor-pointer">
                مشارکت در فروش
              </span>
            </div>
            <button className="hover:opacity-80 transition-opacity">
              <ChevronLeftIcon size={20} />
            </button>
          </Link>
          <p className="font-iransans font-bold lg:font-normal text-xs lg:text-sm text-gray-600 pr-10 leading-7 lg:leading-10">
            با به اشتراک گذاری لینک فروش محصولات ، به ازای فروش هر کالا از
            مزایای فروش کالا بهره مند شوید .
          </p>
        </div>
      </div>
      {/* Edit profile button */}
      <div className="mt-2 text-center">
        <button
          onClick={() => setIsEditingProfile(true)}
          className="bg-primary w-full h-12 rounded-md text-white hover:opacity-80 transition-opacity cursor-pointer"
        >
          ویرایش مشخصات
        </button>
      </div>
    </div>
  );
}

export default ProfileMainPanel;
