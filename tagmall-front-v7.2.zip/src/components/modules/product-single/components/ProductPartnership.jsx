"use client";

import { useState } from "react";
import Image from "next/image";
import { DownloadIcon, CopyIcon, HintIcon, ImageIcon } from "@/icons";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { PartnershipHintDialog } from "@/components/ui/dialog";

export default function ProductPartnership() {
  const [showLink, setShowLink] = useState(false);
  const [isHintBoxOpen, setIsHintBoxOpen] = useState(false);

  const partnershipTexts = [
    "با به اشتراک گذاری لینک فروش محصولات ، یک  درصد  از  فروش   هر   کالا را بهره مند شوید .",
    "لینک مشارکت در فروش هر کالا برای شما اختصاصی می باشد .",
    "بررسی بازدهی لینک های به اشتراک گذاشته شده :",
    "با بررسی بازدهی لینک های به اشتراک گذاشته شده ؛ عملکرد بهتر و سود بیش ترکسب کنید .",
    "محاسبه و پرداخت سود مشارکت در فروش : ",
    "با توجه به امکان مرجوع شدن کالا توسط خریدار سود مشارکت در فروش پس  ازپایان فرصت مرجوع شدن کالا به حساب شما واریز می شود .",
  ];

  const affiliateLink = "tagmall.ir/tagmallaffliate/contract01";

  return (
    <div className="lg:bg-white lg:rounded-lg pb-16 lg:p-16">
      <Accordion type="single" collapsible defaultValue="partnership">
        <AccordionItem value="partnership">
          <AccordionTrigger className="hidden lg:flex text-primary text-base lg:text-xl font-semibold hover:no-underline justify-between">
            مشارکت در فروش
          </AccordionTrigger>
          <AccordionContent className="lg:mt-8">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Image Section */}
              <div className="w-full lg:w-1/2">
                <div className="relative w-full h-[360px]">
                  <Image
                    src="/assets/images/fallback/phone.png"
                    fill
                    alt="Partnership"
                    className="object-contain"
                  />
                </div>
                <div className="lg:hidden flex items-center justify-end pl-2 mt-3">
                  <ImageIcon />
                </div>
              </div>

              {/* Content */}
              <div className="w-full lg:w-1/2 flex flex-col">
                {/* Texts */}
                <div className="hidden lg:block space-y-0 mb-6">
                  {partnershipTexts.map((text, index) => (
                    <p
                      key={index}
                      className="text-gray-600 text-xs/6 lg:text-base/12 mb-2! lg:mb-3!"
                    >
                      {text}
                    </p>
                  ))}
                </div>

                {/* Button or Link Box */}
                <div className=" bg-white rounded-lg p-4">
                  <div className="flex lg:hidden items-center justify-between">
                    <span className="text-primary font-bold">
                      مشارکت در فروش
                    </span>
                    <HintIcon
                      size={20}
                      onClick={() => setIsHintBoxOpen(true)}
                    />
                  </div>
                  <div className="block lg:hidden mt-5 space-y-2">
                    <div className="text-gray-600 text-xs">
                      <span className="font-bold">گوشی موبایل </span>
                      آیفون 15 پرو
                    </div>
                    <div className="text-gray-600 text-xs">
                      <span className="font-bold">سود مشارکت در فروش </span>1
                      درصد به ازای هر کالا
                    </div>
                  </div>
                  {!showLink ? (
                    <button
                      onClick={() => setShowLink(true)}
                      className="text-primary text-lg w-full mt-5 lg:mt-0"
                    >
                      دریافت لینک مشارکت در فروش
                    </button>
                  ) : (
                    <div className="space-y-4 mt-5 lg:mt-0">
                      {/* Link Box */}
                      <div className="bg-gray-200 p-4 rounded-md flex justify-center items-center mx-auto max-w-[540px]">
                        {/* Link */}
                        <span className="text-gray-400 ml-6">
                          {affiliateLink}
                        </span>
                        {/* Copy Icon */}
                        <CopyIcon size={20} color="black" />
                        {/* Border */}
                        <div className="border-r-2 border-white h-6 mx-[14px]" />
                        {/* Download Icon */}
                        <DownloadIcon size={20} color="black" />
                      </div>

                      {/* Share Button */}
                      <div className="text-center">
                        <button className="text-primary text-lg cursor-pointer">
                          اشتراک گذاری
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Hint box */}
      {isHintBoxOpen && (
        <PartnershipHintDialog
          open={isHintBoxOpen}
          setIsHintBoxOpen={setIsHintBoxOpen}
        />
      )}
    </div>
  );
}
