"use client";

import { SearchInput, SearchBox } from "@/components/ui/search";
import MainNavigation from "@/components/layout/navigation-menu/MainNavigation";
import usePublicStore from "@/app/store/publicStore";
import ProductMain from "./ProductMain";
import ProductRelatedAccessories from "./ProductRelatedAccessories";
import ProductSpecifications from "./ProductSpecifications";
import ProductReviews from "./ProductReviews";
import ProductUserComments from "./ProductUserComments";
import ProductPartnership from "./ProductPartnership";
import ProductNavigation from "./ProductNavigation";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { SupportSingleChat } from "../../support";
import { useRouter } from "next/navigation";
import Image from "next/image";

function ProductSingle() {
  const router = useRouter();
  const isDesktop = useMediaQuery("(min-width: 1024px)");
  const searchBoxOpen = usePublicStore((s) => s.searchBoxOpen);
  const setSearchBoxOpen = usePublicStore((s) => s.setSearchBoxOpen);
  const [activeSection, setActiveSection] = useState("details");
  const [showComments, setShowComments] = useState(false);

  const handleSearchInputClick = () => {
    setSearchBoxOpen(true);
  };

  const handleGoBack = () => {
    router.back();
  };

  return (
    <>
      {/* Desktop Layout */}
      <div className="hidden lg:flex h-screen bg-gray-200 px-10 pt-[25px] pb-[5px] flex-col">
        <div className="flex flex-col gap-[25px] flex-1 min-h-0">
          {/* Top Section - Search Input */}
          <div className="flex items-center gap-[25px] pr-6">
            <Image
              src="/assets/images/logo/small-logo.svg"
              width={40}
              height={40}
              alt="لوگو"
              className="z-70"
            />
            <div className="flex-1">
              <SearchInput
                value=""
                onChange={() => {}}
                placeholder="برند، کالا، لوازم جانبی، قطعات"
                readOnly
                hasLogo={!isDesktop}
                bgColor="bg-white"
                className="max-w-[642px]"
              />
            </div>
          </div>

          {/* Main Content */}
          <div className="relative rounded-lg overflow-y-auto flex-1 min-h-0">
            {/* Main Navigation */}
            <div className="fixed right-[65px] bottom-[55px]">
              <ProductNavigation />
            </div>

            {/* Content */}
            <div className="space-y-1.5 bg-gray-200">
              <ProductMain />
              <ProductRelatedAccessories />
              <ProductSpecifications />
              <ProductReviews />
              <ProductUserComments />
              <ProductPartnership />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="lg:hidden flex flex-col h-screen bg-white">
        {/* Fixed Header */}
        <div className="fixed top-0 left-0 right-0 bg-white z-50 px-[10px] pt-[20px] pb-4">
          <div onClick={handleSearchInputClick} className="cursor-pointer">
            <SearchInput
              value=""
              onChange={() => {}}
              hasLogo
              placeholder="برند، کالا، لوازم جانبی، قطعات"
              showSearchIcon={false}
              readOnly
            />
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 pt-[80px] bg-gray-200">
          <div className="px-[10px] space-y-1">
            {activeSection === "details" && <ProductMain />}
            {activeSection === "specsAndComments" && (
              <Tabs defaultValue="specs">
                <TabsList
                  dir="rtl"
                  className="w-full max-w-[540px] flex items-center gap-1 px-0! mt-2"
                >
                  <TabsTrigger
                    value="specs"
                    className="bg-white rounded-md! flex-1 shadow-none! text-gray-600 data-[state=active]:text-primary font-bold! h-[48px]"
                  >
                    مشخصات
                  </TabsTrigger>
                  <TabsTrigger
                    value="reviews"
                    className="bg-white rounded-md! flex-1 shadow-none! text-gray-600 data-[state=active]:text-primary font-bold! h-[48px]"
                  >
                    نقد و بررسی
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="specs" dir="rtl">
                  <ProductSpecifications setShowComments={setShowComments} />
                </TabsContent>
                <TabsContent value="reviews" dir="rtl">
                  <ProductReviews setShowComments={setShowComments} />
                </TabsContent>
              </Tabs>
            )}
            {activeSection === "partnership" && <ProductPartnership />}
          </div>
        </div>

        {/* Fixed Bottom Navigation */}
        <ProductNavigation
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          onGoBack={handleGoBack}
        />
      </div>

      {!isDesktop && (
        <Drawer open={showComments} onOpenChange={() => setShowComments(false)}>
          <DrawerContent
            className="z-100! px-[10px] h-[96%]! bg-gray-200!"
            overlayClassName="z-100 lg:hidden"
          >
            <ProductUserComments />
          </DrawerContent>
        </Drawer>
      )}

      {/* Search Box */}
      <SearchBox
        isOpen={searchBoxOpen}
        onClose={() => setSearchBoxOpen(false)}
      />
    </>
  );
}

export default ProductSingle;
