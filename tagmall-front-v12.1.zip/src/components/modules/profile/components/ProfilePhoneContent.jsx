"use client";

import { Input } from "@/components/ui/input";
import { HintIcon } from "@/icons";
import { isValidIranianMobile } from "@/lib/client/validations";
import { useState } from "react";

function ProfilePhoneContent({ phone, setPhone, onNext }) {
  const [errors, setErrors] = useState({ phone: "" });
  const [isLoading, setIsLoading] = useState(false);

  const isFormValid = phone && isValidIranianMobile(phone);

  const handleSendOtp = () => {
    if (!phone) {
      setErrors({ ...errors, phone: "ابتدا شماره موبایل خود را وارد نمایید" });
      return;
    }

    if (!isValidIranianMobile(phone)) {
      setErrors({ ...errors, phone: "شماره موبایل معتبر نمی‌باشد" });
      return;
    }

    setIsLoading(true);
    onNext();
    setIsLoading(false);
  };

  return (
    <div className="mt-2 lg:mt-0">
      {/* Input */}
      <Input
        label="شماره تماس:"
        type="number"
        id="profile_phone"
        value={phone}
        maxLength={11}
        onChange={(e) => setPhone(e.target.value)}
        disabled={isLoading}
        className={`text-center text-gray-600 bg-gray-200 ${errors.phone ? "" : "border-0!"}`}
        error={errors.phone}
      />

      {/* Hint */}
      <div className="mt-4 mr-4 flex items-center gap-2">
        <HintIcon size={16} />
        <span className="text-sm text-gray-600">
          شماره تماس باید به نام شما باشد
        </span>
      </div>

      {/* Button */}
      <button
        onClick={handleSendOtp}
        disabled={!isFormValid || isLoading}
        className={`mt-6 w-full py-3 text-base ${
          !isFormValid || isLoading
            ? "text-gray-400 cursor-not-allowed"
            : "text-primary cursor-pointer"
        }`}
      >
        ارسال کد تایید
      </button>
    </div>
  );
}

export default ProfilePhoneContent;
