"use client";

import React, { useEffect, useState } from "react";
import Image from "next/image";
import toast from "react-hot-toast";

import { CheckIcon, LogOutIcon } from "lucide-react";

import { DragHandler } from "@/components/ui/drag-handler";
import { Input } from "@/components/ui/input";
import SpinnerLoading from "@/components/ui/loading/SpinnerLoading";
import { Skeleton } from "@/components/ui/loading";

import usePublicStore from "@/app/store/publicStore";
import {
  getUserProfile,
  updateUserProfile,
  updateUserProfileAvatar,
} from "@/lib/server/actions/profile";
import { getToken, saveUser } from "@/lib/server/cookies";
import { CustomAccordion } from "@/components/ui/accordion";
import { getBankBySheba } from "@/lib/client/banks";
import { formatSheba } from "@/lib/client/utils";
import { IranianBank } from "iranian-bank-logo-react";
import { CustomOptions } from "@/components/ui/option";
import { HintIcon, LogoutIcon, StrokeArrowLeftIcon, UserIcon } from "@/icons";
import Link from "next/link";
import {
  ProfileAddress,
  ProfileAvatar,
  ProfileBankAccount,
  ProfileEmail,
  ProfileLogout,
  ProfilePhone,
  ProfileSessions,
} from "..";
import { Checkbox } from "@/components/ui/checkbox";
import DialogWrapper from "@/components/ui/dialog";

const ProfileEditInfo = ({ setIsEditingProfile, setIsProfileOpen }) => {
  const setUserInfo = usePublicStore((state) => state.setUserInfo);

  // Basic info states
  const [fullName, setFullName] = useState();
  const [phoneNumber, setPhoneNumber] = useState();
  const [nationalCode, setNationalCode] = useState();
  const [profileImage, setProfileImage] = useState(null);
  const [profilePreview, setProfilePreview] = useState(null);

  // Loading states
  const [isLoading, setIsLoading] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  // Accordion state
  const [expanded, setExpanded] = useState([
    // "contact",
    // "contact-phone",
    // "contact-email",
    // "address",
    // "bank",
  ]);
  const toggleExpand = (id) => {
    setExpanded((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  // Option selections
  const [selectedPhoneOption, setSelectedPhoneOption] = useState(null);
  const [selectedEmailOption, setSelectedEmailOption] = useState(null);
  const [selectedAddressOption, setSelectedAddressOption] = useState(null);
  const [selectedBankOption, setSelectedBankOption] = useState(null);

  // Lists
  const [phoneList, setPhoneList] = useState([
    { id: 1, label: "09121234567" },
    { id: 2, label: "09354321223" },
  ]);
  const [emailList, setEmailList] = useState([
    { id: 1, label: "example@mail.com" },
    { id: 2, label: "user@gmail.com" },
  ]);
  const [addressList, setAddressList] = useState([
    {
      id: 1,
      label: "تهران، سعادت آباد، بلوار ۲۴ متری",
      extra: [{ label: "کد پستی", value: "1234567890" }],
    },
    {
      id: 2,
      label: "تهران، جردن، خیابان دیدار",
      extra: [{ label: "کد پستی", value: "0098456217" }],
    },
  ]);
  const [bankList, setBankList] = useState([
    {
      id: 1,
      label: "بانک: ملت",
      sheba: "IR490120010000008030057531",
    },
  ]);

  // Modal or Drawers
  const [isAvatarOpen, setIsAvatarOpen] = useState(false);
  const [isLogoutOpen, setIsLogoutOpen] = useState(false);
  const [isPhoneOpen, setIsPhoneOpen] = useState(false);
  const [isEmailOpen, setIsEmailOpen] = useState(false);
  const [isAddressOpen, setIsAddressOpen] = useState(false);
  const [activeAddressAuth, setAddressActiveAuth] = useState(false);
  const [isAddressHintOpen, setIsAddressHintOpen] = useState(false);
  const [isBankOpen, setIsBankOpen] = useState(false);
  const [isSessionsOpen, setIsSessionsOpen] = useState(false);
  const [selectedPhoneForSessions, setSelectedPhoneForSessions] = useState("");
  const [isSessionsHintOpen, setIsSessionsHintOpen] = useState(false);

  // Handle image upload and update to server
  const handleImageChange = async (e) => {
    if (!e.target.files.length) return;

    const file = e.target.files[0];
    const maxSize = 3 * 1024 * 1024;
    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];

    if (!allowedTypes.includes(file.type)) {
      toast.error("فرمت تصویر باید jpg، png یا webp باشد");
      return;
    }

    if (file.size > maxSize) {
      toast.error("حجم فایل باید حداکثر ۳ مگابایت باشد");
      return;
    }

    const imageUrl = URL.createObjectURL(file);

    setProfileImage(file);
    setProfilePreview(imageUrl);

    // آپدیت state گلوبال
    setUserInfo((prev) => ({
      ...prev,
      avatar: imageUrl,
    }));

    await uploadAvatar(file);
  };

  // Upload avatar to server
  const uploadAvatar = async (file) => {
    const token = await getToken();
    const formData = new FormData();
    formData.append("avatar", file);

    setIsUpdating(true);
    const { updateProfileRes } = await updateUserProfileAvatar(token, formData);

    if (updateProfileRes) {
      console.log("RES: ", updateProfileRes);
      toast.success("تصویر پروفایل با موفقیت بروزرسانی شد");
      setUserInfo(updateProfileRes.data.user);
      await saveUser(JSON.stringify(updateProfileRes.data.user));
      setProfilePreview(updateProfileRes.data.user.avatar);
    } else {
      toast.error("خطا در بروزرسانی تصویر پروفایل");
    }

    setIsUpdating(false);
  };

  // Remove avatar from server
  const removeAvatar = async () => {
    const token = await getToken();
    const formData = new FormData();
    formData.append("delete_avatar", "1");

    setIsUpdating(true);
    const { updateProfileRes } = await updateUserProfileAvatar(token, formData);

    if (updateProfileRes) {
      toast.success("تصویر پروفایل با موفقیت حذف شد");
      setUserInfo(updateProfileRes.data.user);
      await saveUser(JSON.stringify(updateProfileRes.data.user));
      setProfileImage(null);
      setProfilePreview(null);
    } else {
      toast.error("خطا در حذف تصویر پروفایل");
    }

    setIsUpdating(false);
  };

  // Fetch profile data
  const getUserData = async () => {
    const token = await getToken();
    setIsLoading(true);

    const { userProfileRes } = await getUserProfile(token);

    if (userProfileRes) {
      const user = userProfileRes.data.user;
      setUserInfo(user);

      setFullName(`${user.name} ${user.family}`);
      setNationalCode(user.national_code);
      setPhoneNumber(user.mobile);
      setProfilePreview(user.avatar);
    }

    setIsLoading(false);
  };

  useEffect(() => {
    getUserData();
  }, []);

  // Update profile submit
  const handleProfileSubmit = async (e) => {
    e.preventDefault();

    const token = await getToken();
    const formData = new FormData();

    if (profileImage instanceof File) {
      formData.append("avatar", profileImage);
    }

    setIsUpdating(true);
    const { updateProfileRes } = await updateUserProfileAvatar(token, formData);

    if (updateProfileRes) {
      toast.success("پروفایل با موفقیت بروزرسانی شد");
      setUserInfo(updateProfileRes.data.user);
      await saveUser(JSON.stringify(updateProfileRes.data.user));
    } else {
      toast.error("خطا در بروزرسانی پروفایل");
    }

    setIsUpdating(false);
    setIsEditingProfile(false);
  };

  return (
    <>
      <div className="h-full overflow-y-auto scroll-hidden select-none flex flex-col relative">
        {/* Header */}
        <div className="flex items-center justify-between px-[10px] lg:px-[50px] lg:pt-[50px]">
          <div className="flex items-center gap-2">
            <div className="relative group">
              {isLoading ? (
                <Skeleton className="w-[50px] h-[50px] rounded-md" />
              ) : (
                <div
                  className={`relative w-[50px] h-[50px] rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center ${profilePreview ? "bg-white" : "bg-gray-200"}`}
                  onClick={() => setIsAvatarOpen(true)}
                >
                  {profilePreview ? (
                    <Image
                      src={profilePreview}
                      fill
                      alt="پروفایل"
                      className="object-cover"
                    />
                  ) : (
                    <UserIcon size={20} />
                  )}
                </div>
              )}
            </div>

            <h1 className="text-gray-600 text-base">
              {fullName || "اسم کاربر"}
            </h1>
          </div>

          <LogoutIcon
            onClick={() => setIsLogoutOpen(true)}
            className="text-error-medium ml-4 cursor-pointer"
            size={20}
          />
        </div>

        {/* Scrollable content */}
        <div>
          {/* Section 1: National code */}
          <div className="py-3 px-[10px] lg:px-[50px] lg:pb-[50px]">
            <div className="relative">
              <Input
                label="شناسه ملی:"
                type="number"
                id="m_nationalCode"
                value={nationalCode}
                onChange={(e) => setNationalCode(e.target.value)}
                disabled={isLoading}
                readOnly
                className="text-center text-gray-600 bg-gray-200 border-0!"
              />
              <CheckIcon
                className="text-success-medium absolute top-1/2 translate-y-1/2 left-4"
                size={16}
              />
            </div>
            <div className="flex items-start gap-4 pr-4">
              <HintIcon size={24} className="mt-3" />
              <p className="text-gray-600 leading-12 text-justify">
                با{" "}
                <Link href="#" className="text-primary font-bold">
                  احراز هویت
                </Link>{" "}
                نشست های فعال را مدیریت کنید و از خدمات کیف پول اعتباری بهره مند
                شوید
              </p>
            </div>
          </div>

          <div className="w-full h-[4px] bg-gray-200" />

          {/* Section 2: Contact information */}
          <div className="px-[10px] lg:px-[50px] lg:py-[50px]">
            <CustomAccordion
              id="contact"
              expandedItems={expanded}
              onToggle={toggleExpand}
              triggerClassName="lg:pt-0!"
              iconClassName="left-[18px]"
              customLabel={
                <span className="text-primary font-bold">
                  چگونه با شما در ارتباط باشیم؟
                </span>
              }
            >
              {/* Phone */}
              <CustomAccordion
                id="contact-phone"
                expandedItems={expanded}
                onToggle={toggleExpand}
                label="شماره تماس:"
                iconClassName="left-[18px]"
                labelClassName="text-gray-600!"
              >
                <CustomOptions
                  type="radio"
                  hasBorder={false}
                  value={selectedPhoneOption}
                  onChange={setSelectedPhoneOption}
                  bottomButtonText="دسترسی به شماره تماس دیگری دارید؟"
                  buttonOnClick={() => setIsPhoneOpen(true)}
                  onItemClick={(item) => {
                    setSelectedPhoneForSessions(item.label);
                    setIsSessionsOpen(true);
                  }}
                  options={phoneList}
                  centerLabel={true}
                  newItemId={2}
                  containerClassName="border-2! border-error-medium"
                />
              </CustomAccordion>

              {/* Divider between phone and email when both are closed */}
              {!expanded.includes("contact-phone") && (
                <div className="w-full h-[2px] bg-gray-200" />
              )}

              {/* Email */}
              <CustomAccordion
                id="contact-email"
                expandedItems={expanded}
                onToggle={toggleExpand}
                label="پست الکترونیک:"
                iconClassName="left-[18px]"
                labelClassName="text-gray-600!"
              >
                <CustomOptions
                  type="radio"
                  value={selectedEmailOption}
                  onChange={setSelectedEmailOption}
                  bottomButtonText="دسترسی به پست الکترونیک دیگری دارید؟"
                  buttonOnClick={() => setIsEmailOpen(true)}
                  options={emailList}
                  centerLabel={true}
                  containerClassName="mb-[10px]"
                />
              </CustomAccordion>
            </CustomAccordion>
          </div>

          <div className="w-full h-[4px] bg-gray-200" />

          {/* Section 3: Addresses */}
          <div className="px-[10px] lg:px-[50px] lg:py-[50px]">
            <CustomAccordion
              id="address"
              expandedItems={expanded}
              onToggle={toggleExpand}
              triggerClassName="lg:pt-0!"
              iconClassName="left-[18px]"
              customLabel={
                <span className="text-primary font-bold">
                  سفارشات شما به کجا ارسال شود؟
                </span>
              }
            >
              <CustomAccordion
                id="order-address"
                expandedItems={expanded}
                onToggle={toggleExpand}
                label="آدرس:"
                alwaysOpen
                iconClassName="hidden"
                labelClassName="text-gray-600!"
              >
                <CustomOptions
                  type="radio"
                  value={selectedAddressOption}
                  onChange={setSelectedAddressOption}
                  bottomButtonText="سفارشات به آدرس دیگری ارسال شود؟"
                  buttonOnClick={() => setIsAddressOpen(true)}
                  options={addressList}
                />
              </CustomAccordion>
              <div className="flex items-start gap-2 pr-4 pb-3 pt-4">
                <Checkbox
                  checked={activeAddressAuth}
                  onChange={() => setAddressActiveAuth(!activeAddressAuth)}
                  hasBorder={false}
                  className="bg-gray-200!"
                />
                <p className="text-justify">
                  با احراز کد پستی با اطمینان از خدمات ما بهره مند شوید
                </p>
              </div>
            </CustomAccordion>
          </div>

          <div className="w-full h-[4px] bg-gray-200" />

          {/* Section 4: Bank info */}
          <div className="px-[10px] lg:px-[50px] lg:py-[50px]">
            <CustomAccordion
              id="bank"
              expandedItems={expanded}
              onToggle={toggleExpand}
              triggerClassName="lg:pt-0!"
              iconClassName="left-[18px]"
              customLabel={
                <span className="text-primary font-bold">
                  واریز به کدام حساب بانکی شما انجام شود؟
                </span>
              }
              containerClassName="pb-0!"
            >
              <CustomAccordion
                id="contact-email"
                expandedItems={expanded}
                onToggle={toggleExpand}
                alwaysOpen
                label="شماره شبا:"
                iconClassName="hidden"
                labelClassName="text-gray-600!"
                containerClassName="pb-0!"
              >
                <CustomOptions
                  type="radio"
                  value={selectedBankOption}
                  onChange={setSelectedBankOption}
                  bottomButtonText="واریز به حساب دیگری انجام شود؟"
                  buttonOnClick={() => setIsBankOpen(true)}
                  options={bankList}
                  containerClassName="pb-0!"
                  renderLabel={(item) => {
                    const bankInfo = getBankBySheba(item.sheba);
                    const formattedSheba = formatSheba(item.sheba);

                    return (
                      <div className="relative w-full flex justify-center">
                        <span className="pl-10">{formattedSheba}</span>
                        {bankInfo?.icon && (
                          <div className="absolute -left-1 top-1/2 -translate-y-1/2">
                            <IranianBank name={bankInfo.icon} size={24} />
                          </div>
                        )}
                      </div>
                    );
                  }}
                />
              </CustomAccordion>
            </CustomAccordion>
          </div>
        </div>
      </div>

      {/* Profile avatar */}
      <ProfileAvatar
        isOpen={isAvatarOpen}
        setIsOpen={setIsAvatarOpen}
        isUpdating={isUpdating}
        user={{
          name: fullName?.split(" ")[0],
          family: fullName?.split(" ")[1],
          avatar: profilePreview,
        }}
        onUpdateAvatar={(e) => handleImageChange(e)}
        onRemoveAvatar={removeAvatar}
      />

      {/* Profile logout */}
      <ProfileLogout
        isOpen={isLogoutOpen}
        setIsOpen={setIsLogoutOpen}
        user={{
          name: fullName?.split(" ")[0],
          family: fullName?.split(" ")[1],
          avatar: profilePreview,
        }}
        onLogout={() => {
          setIsEditingProfile(false);
          setIsProfileOpen(false);
        }}
      />

      {/* Profile phone */}
      <ProfilePhone
        isOpen={isPhoneOpen}
        setIsOpen={setIsPhoneOpen}
        onVerifyOtp={(result) => {
          // اضافه کردن شماره جدید به لیست
          const newPhone = typeof result === "string" ? result : result?.phone;
          if (newPhone) {
            const newId = Math.max(...phoneList.map((p) => p.id), 0) + 1;
            setPhoneList([...phoneList, { id: newId, label: newPhone }]);
          }
          setIsPhoneOpen(false);
        }}
      />

      {/* Profile email */}
      <ProfileEmail
        isOpen={isEmailOpen}
        setIsOpen={setIsEmailOpen}
        onVerifyOtp={(result) => {
          // اضافه کردن ایمیل جدید به لیست
          const newEmail = typeof result === "string" ? result : result?.email;
          if (newEmail) {
            const newId = Math.max(...emailList.map((e) => e.id), 0) + 1;
            setEmailList([...emailList, { id: newId, label: newEmail }]);
          }
          setIsEmailOpen(false);
        }}
      />

      {/* Profile address */}
      <ProfileAddress
        isOpen={isAddressOpen}
        setIsOpen={setIsAddressOpen}
        activeAddressAuth={activeAddressAuth}
        onSubmit={(result) => {
          // اضافه کردن آدرس جدید به لیست
          if (result && result.address) {
            const newId = Math.max(...addressList.map((a) => a.id), 0) + 1;
            setAddressList([
              ...addressList,
              {
                id: newId,
                label: result.address,
                extra: [{ label: "کد پستی", value: result.postalCode || "" }],
              },
            ]);
          }
          setIsAddressOpen(false);
        }}
      />

      {/* Address hint box */}
      <DialogWrapper
        isOpen={isAddressHintOpen}
        onClose={() => setIsAddressHintOpen(false)}
      >
        <p className="text-center">احراز کد پستی توسط اداره پست انجام می‌شود</p>
      </DialogWrapper>

      {/* Profile bank account */}
      <ProfileBankAccount
        isOpen={isBankOpen}
        setIsOpen={setIsBankOpen}
        onSubmit={(result) => {
          // اضافه کردن حساب بانکی جدید به لیست
          if (result && result.bankName && result.sheba) {
            const newId = Math.max(...bankList.map((b) => b.id), 0) + 1;

            setBankList([
              ...bankList,
              {
                id: newId,
                label: `بانک: ${result.bankName}`,
                sheba: result.sheba,
              },
            ]);
          }
          setIsBankOpen(false);
        }}
      />

      {/* Profile sessions */}
      <ProfileSessions
        isOpen={isSessionsOpen}
        setIsOpen={setIsSessionsOpen}
        phone={selectedPhoneForSessions}
        onVerifyOtp={() => setIsSessionsOpen(false)}
        setIsSessionsHintOpen={setIsSessionsHintOpen}
      />

      {/* Sessions hint modal */}
      <DialogWrapper
        isOpen={isSessionsHintOpen}
        onClose={() => setIsSessionsHintOpen(false)}
        className="z-9999"
      >
        <p className="text-center">متن تستی جهت نمایش به کاربر</p>
      </DialogWrapper>
    </>
  );
};

export default ProfileEditInfo;
