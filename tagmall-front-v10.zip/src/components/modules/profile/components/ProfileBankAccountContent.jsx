"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { HintIcon } from "@/icons";
import { toEnglishNumber } from "@/lib/client/utils";

function ProfileBankAccountContent({ onSubmit }) {
  const [bank, setBank] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [sheba, setSheba] = useState("");
  const [cardNumber, setCardNumber] = useState("");

  const formatCardNumber = (value) => {
    // حذف همه کاراکترهای غیر عددی
    const rawValue = value.replace(/[^\d۰-۹]/g, "");
    const englishValue = toEnglishNumber(rawValue);

    // محدود کردن به 16 رقم
    const limited = englishValue.slice(0, 16);

    // اضافه کردن dash بعد از هر 4 رقم
    const formatted = limited.match(/.{1,4}/g)?.join("-") || limited;

    return formatted;
  };

  const handleCardNumberChange = (e) => {
    const formatted = formatCardNumber(e.target.value);
    setCardNumber(formatted);
  };

  const handleSubmit = () => {
    // حذف dash و فاصله از شماره کارت برای ارسال
    const cleanCardNumber = cardNumber ? cardNumber.replace(/[-\s]/g, "") : "";

    onSubmit({
      bankName: bank,
      accountNumber: toEnglishNumber(accountNumber),
      sheba: sheba,
      cardNumber: cleanCardNumber,
    });
  };

  return (
    <div>
      <div className="flex flex-col gap-3">
        <span className="text-gray-800 text-base">حساب بانکی:</span>
        <div className="rounded-lg bg-gray-200 overflow-hidden">
          <Input
            placeholder="نام بانک"
            value={bank}
            onChange={(e) => setBank(e.target.value)}
            className="text-center border-0! h-[50px] border-b-2! border-white rounded-none placeholder:text-gray-400"
          />
          <Input
            placeholder="شماره حساب"
            numeric={true}
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            className="text-center border-0! h-[50px] border-b-2! border-white rounded-none placeholder:text-gray-400"
          />
          <Input
            placeholder="شماره شبا"
            value={sheba}
            onChange={(e) => setSheba(e.target.value)}
            className="text-center border-0! h-[50px] border-b-2! border-white rounded-none placeholder:text-gray-400"
          />
          <Input
            placeholder="شماره کارت"
            value={cardNumber}
            onChange={handleCardNumberChange}
            className="text-center border-0! h-[50px] placeholder:text-gray-400"
            dir="ltr"
          />
        </div>
      </div>

      {/* Hint text */}
      <div className="flex items-center gap-2 text-gray-600 mt-4 mr-4">
        <HintIcon size={16} />
        حساب بانکی باید به نام شما باشد
      </div>

      {/* Submit button */}
      <button
        onClick={handleSubmit}
        className="w-full mt-7 pb-4 text-primary text-base cursor-pointer"
      >
        افزودن حساب بانکی
      </button>
    </div>
  );
}

export default ProfileBankAccountContent;
