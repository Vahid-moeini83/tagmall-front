"use client";

import { Input } from "@/components/ui/input";
import { HintIcon } from "@/icons";
import { isValidIranianMobile } from "@/lib/client/validations";
import { useState } from "react";

function ProfilePhoneContent({ phone, setPhone, onNext }) {
  const [errors, setErrors] = useState({ phone: "" });

  const handleSendOtp = () => {
    if (!phone) {
      setErrors({ ...errors, phone: "ابتدا شماره موبایل خود را وارد نمایید" });
      return;
    }

    if (!isValidIranianMobile(phone)) {
      setErrors({ ...errors, phone: "شماره موبایل معتبر نمی‌باشد" });
      return;
    }

    onNext();
  };

  return (
    <div>
      {/* Input */}
      <Input
        label="شماره تماس:"
        type="number"
        id="profile_phone"
        value={phone}
        maxLength={11}
        onChange={(e) => setPhone(e.target.value)}
        className={`text-center text-gray-600 bg-gray-200 ${errors.phone ? "" : "border-0!"}`}
        error={errors.phone}
      />

      {/* Hint */}
      <div className="mt-4 flex items-center gap-2 text-gray-600">
        <HintIcon className="text-gray-600 w-4 h-4" />
        <span className="text-sm">شماره تماس باید به نام شما باشد</span>
      </div>

      {/* Button */}
      <button
        onClick={handleSendOtp}
        className="mt-6 w-full py-3 text-primary text-base cursor-pointer"
      >
        ارسال کد تایید
      </button>
    </div>
  );
}

export default ProfilePhoneContent;
