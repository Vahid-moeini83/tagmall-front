"use client";

import { useState, useEffect } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { CustomOptions } from "@/components/ui/option";
import { HintIcon } from "@/icons";

function ProfileSessionsContent({
  sessions,
  phone,
  selectedSessions,
  setSelectedSessions,
  onNext,
  onBlockSessions,
  setOtpExpire,
  setIsSessionsHintOpen,
}) {
  const [selectAll, setSelectAll] = useState(false);

  const activeSessions = sessions.filter((s) => s.isActive);

  // همگام‌سازی selectAll با selectedSessions
  useEffect(() => {
    if (activeSessions.length > 0) {
      const allActiveSelected = activeSessions.every((s) =>
        selectedSessions.includes(s.id),
      );
      setSelectAll(allActiveSelected);
    }
  }, [selectedSessions, activeSessions]);

  const handleSelect = (id) => {
    const item = sessions.find((s) => s.id === id);
    if (!item?.isActive) return;

    let updated = [...selectedSessions];

    if (updated.includes(id)) {
      updated = updated.filter((x) => x !== id);
    } else {
      updated.push(id);
    }

    setSelectedSessions(updated);
  };

  const handleSelectAll = () => {
    // همیشه همه نشست‌های فعال رو انتخاب کن
    setSelectedSessions(activeSessions.map((s) => s.id));
    setSelectAll(true);
  };

  const handleBlockClick = async () => {
    onNext();
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <span>نشست های فعال:</span>
        <HintIcon
          size={20}
          className="cursor-pointer ml-4"
          onClick={() => setIsSessionsHintOpen(true)}
        />
      </div>
      <CustomOptions
        type="checkbox"
        value={selectedSessions}
        onChange={handleSelect}
        options={sessions.map((s) => ({
          id: s.id,
          label: s.label,
          isActive: s.isActive,
          statusText: s.isActive ? "فعال" : "مسدود",
          statusClass: s.isActive ? "text-success-medium" : "text-error-medium",
        }))}
        renderLabel={(item) => (
          <div className="flex items-center justify-between ">
            <span className="text-gray-600">{item.label}</span>
            <span className={`${item.statusClass}`}>{item.statusText}</span>
          </div>
        )}
      />

      {/* select all */}
      <div
        className="flex items-center pr-4 gap-2 text-gray-700 text-sm cursor-pointer"
        onClick={handleSelectAll}
      >
        <Checkbox
          checked={selectAll}
          hasBorder={false}
          className="bg-gray-200!"
        />
        همه نشست‌های فعال با شماره {phone}
      </div>

      {/* block button */}
      <button
        className="text-error-medium text-center py-4 cursor-pointer"
        onClick={handleBlockClick}
      >
        دسترسی از نشست‌های فعال انتخاب شده مسدود شود؟
      </button>
    </div>
  );
}

export default ProfileSessionsContent;
