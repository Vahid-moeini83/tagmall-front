"use client";

import { OtpInput } from "@/components/ui/otp";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { HintIcon } from "@/icons";
import { formatTime } from "@/lib/client/utils";
import { useEffect, useState } from "react";

function ProfileEmailOtpContent({ email, onBack, otpExpire, onVerify }) {
  const [otp, setOtp] = useState("");
  const [timeLeft, setTimeLeft] = useState(otpExpire);
  const [isResendActive, setIsResendActive] = useState(false);

  const isDesktop = useMediaQuery("(min-width: 1024px)");

  useEffect(() => {
    if (timeLeft <= 0) {
      setIsResendActive(true);
      return;
    }
    const id = setInterval(() => setTimeLeft((p) => p - 1), 1000);
    return () => clearInterval(id);
  }, [timeLeft]);

  useEffect(() => {
    if (otp.length === 5) onVerify({ email, otp });
  }, [otp]);

  return (
    <div>
      {/* Otp Input */}
      <OtpInput
        value={otp}
        setValue={setOtp}
        onBack={!isDesktop && onBack}
        className="bg-gray-200! border-0! mt-1"
      />

      {/* Hint */}
      <div className="mt-4 flex items-start gap-2 mr-4">
        <HintIcon size={16} />
        <p className="text-gray-600">
          کد تایید به {email} ارسال {isResendActive ? "می‌شود" : "شده است"}
        </p>
      </div>

      {/* Resend Button */}
      <button
        disabled={!isResendActive}
        className={`mt-6 pb-4 w-full cursor-pointer text-base ${
          isResendActive ? "text-primary" : "text-gray-400 cursor-not-allowed"
        }`}
      >
        {isResendActive ? (
          "ارسال مجدد کد تایید"
        ) : (
          <>
            ارسال مجدد کد تایید تا{" "}
            <span className="text-error-medium">{formatTime(timeLeft)}</span>{" "}
            دیگر
          </>
        )}
      </button>
    </div>
  );
}

export default ProfileEmailOtpContent;
