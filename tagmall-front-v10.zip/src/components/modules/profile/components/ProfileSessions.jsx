"use client";

import { useState } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { ProfileSessionsContent, ProfileSessionsOtpContent } from "..";

// دیتای تستی نشست‌ها برای هر شماره تلفن
const sessionsData = {
  "09121234567": [
    {
      id: 1,
      label: "ورود به حساب کاربری در ساعت 12:00 تاریخ 1404/05/21",
      isActive: true,
    },
    {
      id: 2,
      label: "ورود به حساب کاربری در ساعت 15:30 تاریخ 1404/05/20",
      isActive: true,
    },
    {
      id: 3,
      label: "ورود به حساب کاربری در ساعت 09:10 تاریخ 1404/05/19",
      isActive: false, // مسدود
    },
  ],
  "09354321223": [
    {
      id: 4,
      label: "ورود به حساب کاربری در ساعت 18:45 تاریخ 1404/05/22",
      isActive: true,
    },
    {
      id: 5,
      label: "ورود به حساب کاربری در ساعت 10:20 تاریخ 1404/05/21",
      isActive: true,
    },
    {
      id: 6,
      label: "ورود به حساب کاربری در ساعت 22:00 تاریخ 1404/05/18",
      isActive: false, // مسدود
    },
    {
      id: 7,
      label: "ورود به حساب کاربری در ساعت 14:30 تاریخ 1404/05/17",
      isActive: false, // مسدود
    },
  ],
};

function ProfileSessions({
  isOpen,
  setIsOpen,
  phone = "09121234567",
  onVerifyOtp,
  setIsSessionsHintOpen,
}) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const [step, setStep] = useState(1);
  const [selectedSessions, setSelectedSessions] = useState([]);
  const [otpExpire, setOtpExpire] = useState(10);

  // دریافت نشست‌های مربوط به شماره تلفن
  const sessions = sessionsData[phone] || [];

  const close = () => {
    setIsOpen(false);
    setStep(1);
    setSelectedSessions([]);
  };

  const onBlockSessions = async (ids) => {
    console.log("blocked sessions:", ids);

    // شبیه‌سازی API
    return {
      otpExpireTime: 10,
    };
  };

  const renderStep = () => {
    if (step === 1)
      return (
        <ProfileSessionsContent
          sessions={sessions}
          phone={phone}
          selectedSessions={selectedSessions}
          setSelectedSessions={setSelectedSessions}
          onNext={() => setStep(2)}
          onBlockSessions={onBlockSessions}
          setOtpExpire={setOtpExpire}
          setIsSessionsHintOpen={setIsSessionsHintOpen}
        />
      );

    return (
      <ProfileSessionsOtpContent
        phone={phone}
        otpExpire={otpExpire}
        onVerify={onVerifyOtp}
        onBack={() => setStep(1)}
      />
    );
  };

  return isDesktop ? (
    <DialogWrapper hasOutsideClose isOpen={isOpen} onClose={close}>
      {renderStep()}
    </DialogWrapper>
  ) : (
    <Drawer open={isOpen} onOpenChange={close}>
      <DrawerContent className="z-100! px-[10px]" overlayClassName="z-100">
        {renderStep()}
      </DrawerContent>
    </Drawer>
  );
}

export default ProfileSessions;
