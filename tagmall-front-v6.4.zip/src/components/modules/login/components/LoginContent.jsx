"use client";

import { useState } from "react";
import { LoginEnterPhone, LoginOtp, LoginUserRegisteration } from "..";
import Image from "next/image";
import { ArrowRightIcon, HintIcon } from "@/icons";

function LoginContent() {
  const [currentStep, setCurrentStep] = useState(1);

  const handleNextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <>
      {/* Desktop layout */}
      <div className="hidden lg:block bg-gray-100 h-screen py-10 px-12 xl:px-50">
        {/* Main wrapper */}
        <div className="rounded-lg overflow-hidden h-full shadow-lg flex">
          {/* Content */}
          <div className="bg-white w-1/2 py-16 px-16">
            {currentStep === 1 && (
              <div className="h-full flex flex-col justify-between">
                <div>
                  {/* Title */}
                  <div className="flex flex-col lg:gap-2">
                    <h1 className="text-xl lg:text-2xl font-bold">
                      ورود یا ثبت‌نام
                    </h1>
                    <span className="text-gray-600 text-sm lg:text-base">
                      لطفا شماره موبایل خود را وارد نمایید.
                    </span>
                  </div>
                  {/* Main content */}
                  <div className="mt-10">
                    <div className="flex flex-col gap-1">
                      <label htmlFor="phone" className="lg:text-lg">
                        شماره موبایل
                      </label>
                      <input
                        type="text"
                        name="phone"
                        id="phone"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="outline-none border-2 border-gray-300 h-12 rounded-md px-2"
                      />
                    </div>
                    <div className="flex items-center gap-2 mt-4">
                      <HintIcon size={16} className="text-gray-600" />
                      <span className="font-bold text-xs lg:text-sm text-gray-600">
                        شماره موبایل باید به نام شما باشد.
                      </span>
                    </div>
                  </div>
                </div>
                {/* Submit button */}
                <button
                  onClick={handleConfirm}
                  className="mt-28 bg-primary text-white rounded-md w-full h-12 flex items-center justify-center gap-2 transition-all hover:bg-primary/90 hover:gap-3 cursor-pointer"
                >
                  تایید و ادامه
                  <ArrowRightIcon size={20} className="rotate-180" />
                </button>
              </div>
            )}
            {currentStep === 2 && (
              <LoginOtp
                handleNextStep={handleNextStep}
                handlePreviousStep={handlePreviousStep}
              />
            )}
            {currentStep === 3 && <LoginUserRegisteration />}
          </div>
          {/* Background */}
          <div className="bg-primary w-1/2 flex items-center justify-center">
            <Image
              width={200}
              height={80}
              src="/assets/images/logo/white-logo.svg"
              alt="لوگوی تگ‌‌مال"
              className="mx-auto"
            />
          </div>
        </div>
      </div>

      {/* Mobile layout */}
      <div className="lg:hidden h-screen">
        {/* Fixed background */}
        <div className="fixed inset-0 bg-primary"></div>

        {/* Logo */}
        <div className="absolute top-20 left-0 right-0 flex flex-col items-center gap-1">
          <Image
            src="/assets/images/logo/white-logo.svg"
            width={160}
            height={80}
            alt="لوگو تگمال"
          />
        </div>

        {/* Content drawer */}
        <div className="fixed right-0 left-0 bottom-0 h-[70%] overflow-y-auto pt-8 pb-4 px-6 bg-white rounded-t-xl">
          {currentStep === 1 && (
            <LoginEnterPhone handleNextStep={handleNextStep} />
          )}
          {currentStep === 2 && (
            <LoginOtp
              handleNextStep={handleNextStep}
              handlePreviousStep={handlePreviousStep}
            />
          )}
          {currentStep === 3 && <LoginUserRegisteration />}
        </div>
      </div>
    </>
  );
}

export default LoginContent;
