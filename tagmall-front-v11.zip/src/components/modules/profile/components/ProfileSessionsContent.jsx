"use client";

import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { CustomOptions } from "@/components/ui/option";
import { HintIcon } from "@/icons";

function ProfileSessionsContent({
  sessions,
  phone,
  selectedSessions,
  setSelectedSessions,
  onNext,
  onBlockSessions,
  setOtpExpire,
  setIsSessionsHintOpen,
}) {
  const [selectAll, setSelectAll] = useState(false);

  // موقتی: غیر فعال کردن نشست با id=1
  const updatedSessions = sessions.map((s) =>
    s.id === 1 ? { ...s, isActive: false } : s,
  );

  const activeSessions = updatedSessions.filter((s) => s.isActive);

  const handleSelect = (id) => {
    const item = updatedSessions.find((s) => s.id === id);
    if (!item?.isActive) return; // جلوگیری از انتخاب نشست غیرفعال

    let updated = [...selectedSessions];

    if (updated.includes(id)) {
      updated = updated.filter((x) => x !== id);
    } else {
      updated.push(id);
    }

    setSelectedSessions(updated);

    // آپدیت وضعیت selectAll نسبت به انتخاب‌ها
    const allActiveIds = activeSessions.map((s) => s.id);
    const allSelected =
      allActiveIds.length > 0 &&
      allActiveIds.every((aid) => updated.includes(aid));
    setSelectAll(allSelected);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      // خاموش کردن همه انتخاب‌ها
      setSelectedSessions([]);
      setSelectAll(false);
    } else {
      // انتخاب همه نشست‌های فعال (غیر از غیرفعال‌ها مثل id=1)
      const allActiveIds = activeSessions.map((s) => s.id);
      setSelectedSessions(allActiveIds);
      setSelectAll(true);
    }
  };

  const handleDeleteClick = async () => {
    onNext();
  };

  return (
    <div className="flex flex-col gap-4 mt-3 lg:mt-0 select-none">
      <div className="flex items-center justify-between">
        <span>نشست های فعال:</span>
        <HintIcon
          size={20}
          className="cursor-pointer ml-4"
          onClick={() => setIsSessionsHintOpen(true)}
        />
      </div>

      <CustomOptions
        type="checkbox"
        value={selectedSessions}
        onChange={handleSelect}
        options={updatedSessions.map((s) => ({
          id: s.id,
          label: s.label,
          isActive: s.isActive,
        }))}
        renderLabel={(item) => (
          <div
            className={`flex items-center gap-1 ${
              item.isActive === false ? "text-gray-400" : "text-gray-600"
            }`}
          >
            <span className="font-bold">ورود به حساب کاربری</span> در{" "}
            {item.label}
          </div>
        )}
      />

      {/* انتخاب همه */}
      <div className="flex items-center pr-4 gap-2 text-gray-700 text-sm cursor-pointer">
        <Checkbox
          checked={selectAll}
          hasBorder={false}
          onClick={handleSelectAll}
          className="bg-gray-200!"
        />
        همه نشست‌های فعال با شماره {phone}
      </div>

      {/* دکمه حذف */}
      <button
        disabled={selectedSessions.length === 0}
        className={`text-center py-4 ${
          selectedSessions.length > 0
            ? "text-error-medium cursor-pointer"
            : "text-gray-400 cursor-not-allowed"
        }`}
        onClick={handleDeleteClick}
      >
        دسترسی از نشست‌های فعال انتخاب شده مسدود شود؟
      </button>
    </div>
  );
}

export default ProfileSessionsContent;
