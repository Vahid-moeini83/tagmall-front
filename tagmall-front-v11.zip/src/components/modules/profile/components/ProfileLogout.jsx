"use client";

import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import ProfileLogoutContent from "./ProfileLogoutContent";

function ProfileLogout({ isOpen, setIsOpen, user, onLogout }) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const close = () => setIsOpen(false);

  return (
    <>
      {isDesktop ? (
        <DialogWrapper hasOutsideClose isOpen={isOpen} onClose={close}>
          <ProfileLogoutContent
            user={user}
            onLogout={() => {
              onLogout();
              close();
            }}
          />
        </DialogWrapper>
      ) : (
        <Drawer open={isOpen} onOpenChange={close}>
          <DrawerContent
            className="z-100! px-[10px]"
            overlayClassName="z-100 lg:hidden"
          >
            <ProfileLogoutContent
              user={user}
              onLogout={() => {
                onLogout();
                close();
              }}
            />
          </DrawerContent>
        </Drawer>
      )}
    </>
  );
}

export default ProfileLogout;
