"use client";

import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { ProfileAddressContent } from "..";

function ProfileBankAccount({
  isOpen,
  setIsOpen,
  activeAddressAuth,
  onSubmit,
}) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const close = () => {
    setIsOpen(false);
  };

  return isDesktop ? (
    <DialogWrapper hasOutsideClose isOpen={isOpen} onClose={close}>
      <ProfileAddressContent
        activeAddressAuth={activeAddressAuth}
        onSubmit={onSubmit}
      />
    </DialogWrapper>
  ) : (
    <Drawer open={isOpen} onOpenChange={close}>
      <DrawerContent className="z-100! px-[10px]" overlayClassName="z-100">
        <ProfileAddressContent
          activeAddressAuth={activeAddressAuth}
          onSubmit={onSubmit}
        />
      </DrawerContent>
    </Drawer>
  );
}

export default ProfileBankAccount;
