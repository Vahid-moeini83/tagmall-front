"use client";

import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { HintIcon } from "@/icons";
import { toEnglishNumber } from "@/lib/client/utils";
import { getBankByCardNumber } from "@/lib/client/banks";
import { IranianBank } from "iranian-bank-logo-react";

function ProfileBankAccountContent({ onSubmit }) {
  const [accountNumber, setAccountNumber] = useState("");
  const [sheba, setSheba] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [errors, setErrors] = useState({});
  const [detectedBankName, setDetectedBankName] = useState("");
  const [detectedBankIcon, setDetectedBankIcon] = useState("");

  // تشخیص خودکار نام بانک از روی شماره کارت
  useEffect(() => {
    const cleanCardNumber = cardNumber.replace(/[-\s]/g, "");

    if (cleanCardNumber.length >= 6) {
      const bankInfo = getBankByCardNumber(cleanCardNumber);
      if (bankInfo) {
        setDetectedBankName(bankInfo.name);
        setDetectedBankIcon(bankInfo.icon || "");
      } else {
        setDetectedBankName("");
        setDetectedBankIcon("");
      }
    } else {
      setDetectedBankName("");
      setDetectedBankIcon("");
    }
  }, [cardNumber]);

  const formatCardNumber = (value) => {
    // حذف همه کاراکترهای غیر عددی
    const rawValue = value.replace(/[^\d۰-۹]/g, "");
    const englishValue = toEnglishNumber(rawValue);

    // محدود کردن به 16 رقم
    const limited = englishValue.slice(0, 16);

    // اضافه کردن dash بعد از هر 4 رقم
    const formatted = limited.match(/.{1,4}/g)?.join("-") || limited;

    return formatted;
  };

  const handleCardNumberChange = (e) => {
    const formatted = formatCardNumber(e.target.value);
    setCardNumber(formatted);
  };

  const handleSubmit = () => {
    // بررسی خالی بودن فیلدها
    const newErrors = {};

    if (!detectedBankName.trim()) {
      newErrors.bank =
        "لطفا شماره کارت معتبر وارد کنید تا نام بانک شناسایی شود";
    }
    if (!accountNumber.trim()) {
      newErrors.accountNumber = "لطفا شماره حساب را وارد کنید";
    }
    if (!sheba.trim()) {
      newErrors.sheba = "لطفا شماره شبا را وارد کنید";
    }
    if (!cardNumber.trim()) {
      newErrors.cardNumber = "لطفا شماره کارت را وارد کنید";
    }

    // اگر خطایی وجود داشت، آن‌ها را نمایش بده و ادامه نده
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // پاک کردن خطاها
    setErrors({});

    // حذف dash و فاصله از شماره کارت برای ارسال
    const cleanCardNumber = cardNumber ? cardNumber.replace(/[-\s]/g, "") : "";

    onSubmit({
      bankName: detectedBankName,
      accountNumber: toEnglishNumber(accountNumber),
      sheba: sheba,
      cardNumber: cleanCardNumber,
    });
  };

  return (
    <div className="mt-2 lg:mt-0">
      <div className="flex flex-col gap-3">
        <span className="text-gray-800 text-base">حساب بانکی:</span>
        <div className="rounded-lg bg-gray-200 overflow-hidden">
          <div className="relative">
            <Input
              placeholder="نام بانک"
              value={detectedBankName}
              readOnly
              className="text-center border-0! h-[50px] border-b-2! border-white rounded-none placeholder:text-gray-400 bg-gray-100 cursor-not-allowed"
            />
            {detectedBankIcon && (
              <div
                className={`absolute left-4 ${errors.bank ? "top-2" : "top-1/2 -translate-y-1/2"}`}
              >
                <IranianBank name={detectedBankIcon} size={32} />
              </div>
            )}
            {errors.bank && (
              <div className="bg-error-light px-4 py-2 border-b-2 border-white">
                <p className="text-xs text-center text-error-medium">
                  {errors.bank}
                </p>
              </div>
            )}
          </div>

          <div>
            <Input
              placeholder="شماره حساب"
              numeric={true}
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              className="text-center border-0! h-[50px] border-b-2! border-white rounded-none placeholder:text-gray-400"
            />
            {errors.accountNumber && (
              <div className="bg-error-light px-4 py-2 border-b-2 border-white">
                <p className="text-xs text-center text-error-medium">
                  {errors.accountNumber}
                </p>
              </div>
            )}
          </div>

          <div>
            <Input
              placeholder="شماره شبا"
              value={sheba}
              onChange={(e) => setSheba(e.target.value)}
              className="text-center border-0! h-[50px] border-b-2! border-white rounded-none placeholder:text-gray-400"
            />
            {errors.sheba && (
              <div className="bg-error-light px-4 py-2 border-b-2 border-white">
                <p className="text-xs text-center text-error-medium">
                  {errors.sheba}
                </p>
              </div>
            )}
          </div>

          <div>
            <Input
              placeholder="شماره کارت"
              value={cardNumber}
              onChange={handleCardNumberChange}
              className="text-center border-0! h-[50px] placeholder:text-gray-400"
              dir="ltr"
            />
            {errors.cardNumber && (
              <div className="bg-error-light px-4 py-2">
                <p className="text-xs text-center text-error-medium">
                  {errors.cardNumber}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Hint text */}
      <div className="flex items-center gap-2 text-gray-600 mt-4 mr-4">
        <HintIcon size={16} />
        حساب بانکی باید به نام شما باشد
      </div>

      {/* Submit button */}
      <button
        onClick={handleSubmit}
        className="w-full mt-7 pb-4 text-primary text-base cursor-pointer"
      >
        افزودن حساب بانکی
      </button>
    </div>
  );
}

export default ProfileBankAccountContent;
