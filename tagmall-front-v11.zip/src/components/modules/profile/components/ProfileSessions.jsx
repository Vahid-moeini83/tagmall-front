"use client";

import { useState } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import DialogWrapper from "@/components/ui/dialog";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { ProfileSessionsContent, ProfileSessionsOtpContent } from "..";

// دیتای تستی نشست‌ها برای هر شماره تلفن
const sessionsData = {
  "09121234567": [
    {
      id: 1,
      label: "12:00 1404/05/21",
      isActive: true,
    },
    {
      id: 2,
      label: "15:30 1404/05/20",
      isActive: true,
    },
    {
      id: 3,
      label: "09:10 1404/05/19",
      isActive: true,
    },
  ],
  "09354321223": [
    {
      id: 4,
      label: "18:45 1404/05/22",
      isActive: true,
    },
    {
      id: 5,
      label: "10:20 1404/05/21",
      isActive: true,
    },
    {
      id: 6,
      label: "22:00 1404/05/18",
      isActive: true,
    },
    {
      id: 7,
      label: "14:30 1404/05/17",
      isActive: true,
    },
  ],
};

function ProfileSessions({
  isOpen,
  setIsOpen,
  phone = "09121234567",
  onVerifyOtp,
  setIsSessionsHintOpen,
}) {
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const [step, setStep] = useState(1);
  const [selectedSessions, setSelectedSessions] = useState([]);
  const [otpExpire, setOtpExpire] = useState(10);

  // دریافت نشست‌های مربوط به شماره تلفن
  const sessions = sessionsData[phone] || [];

  const close = () => {
    setIsOpen(false);
    setStep(1);
    setSelectedSessions([]);
  };

  const onBlockSessions = async (ids) => {
    console.log("deleted sessions:", ids);

    // شبیه‌سازی API
    return {
      otpExpireTime: 10,
    };
  };

  const renderStep = () => {
    if (step === 1)
      return (
        <ProfileSessionsContent
          sessions={sessions}
          phone={phone}
          selectedSessions={selectedSessions}
          setSelectedSessions={setSelectedSessions}
          onNext={() => setStep(2)}
          onBlockSessions={onBlockSessions}
          setOtpExpire={setOtpExpire}
          setIsSessionsHintOpen={setIsSessionsHintOpen}
        />
      );

    return (
      <ProfileSessionsOtpContent
        phone={phone}
        otpExpire={otpExpire}
        onVerify={onVerifyOtp}
        onBack={() => setStep(1)}
      />
    );
  };

  return isDesktop ? (
    <DialogWrapper hasOutsideClose isOpen={isOpen} onClose={close}>
      {renderStep()}
    </DialogWrapper>
  ) : (
    <Drawer open={isOpen} onOpenChange={close}>
      <DrawerContent className="z-100! px-[10px]" overlayClassName="z-100">
        {renderStep()}
      </DrawerContent>
    </Drawer>
  );
}

export default ProfileSessions;
